<?php
/**
 * FelixeWeb Hub — native Elementor pages
 *
 * Pages rebuilt with real Elementor containers and widgets (meta _fw_native = 1) get:
 * - the shared site design (assets/site/native.css + native.js),
 * - the body class "fwn",
 * - the shared header and footer, placed with [fw_part name="header"] / [fw_part name="footer"].
 * Header and footer are Elementor templates; their IDs live in the option fwcrm_native_parts.
 */
if (!defined('ABSPATH')) exit;

function fwcrm_is_native($id = 0) {
    $id = $id ?: get_queried_object_id();
    return $id && get_post_meta($id, '_fw_native', true);
}

add_filter('body_class', function ($c) {
    if (is_singular() && fwcrm_is_native()) $c[] = 'fwn';
    return $c;
});

add_action('wp_enqueue_scripts', function () {
    if (!is_singular() || !fwcrm_is_native()) return;
    $css = FWCRM_DIR . 'assets/site/native.css';
    $js = FWCRM_DIR . 'assets/site/native.js';
    wp_enqueue_style('fw-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400&display=swap', array(), null);
    $deps = wp_style_is('elementor-frontend', 'registered') ? array('elementor-frontend') : array();
    wp_enqueue_style('fw-native', FWCRM_URL . 'assets/site/native.css', $deps, FWCRM_VERSION . '.' . (file_exists($css) ? filemtime($css) : 0));
    wp_enqueue_script('fw-native', FWCRM_URL . 'assets/site/native.js', array(), FWCRM_VERSION . '.' . (file_exists($js) ? filemtime($js) : 0), true);
}, 30);

add_filter('wp_resource_hints', function ($urls, $type) {
    if ($type === 'preconnect' && is_singular() && fwcrm_is_native()) {
        $urls[] = 'https://fonts.googleapis.com';
        $urls[] = array('href' => 'https://fonts.gstatic.com', 'crossorigin');
    }
    return $urls;
}, 10, 2);

/** [fw_part name="header"] renders the shared Elementor template for that part. */
add_shortcode('fw_part', function ($atts) {
    $a = shortcode_atts(array('name' => ''), $atts);
    $ids = (array) get_option('fwcrm_native_parts', array());
    $id = isset($ids[$a['name']]) ? (int) $ids[$a['name']] : 0;
    if (!$id || !did_action('elementor/loaded') || get_post_status($id) !== 'publish') return '';
    static $depth = 0;
    if ($depth > 1) return '';
    $depth++;
    $html = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($id, true);
    $depth--;
    return '<div class="fw-part fw-part-' . esc_attr($a['name']) . '">' . $html . '</div>';
});

/** Shared header/footer templates are only edited in Elementor; keep them out of search results and sitemaps. */
add_filter('wp_sitemaps_posts_query_args', function ($args) {
    $ids = array_values(array_filter(array_map('intval', (array) get_option('fwcrm_native_parts', array()))));
    if ($ids) $args['post__not_in'] = array_merge(isset($args['post__not_in']) ? (array) $args['post__not_in'] : array(), $ids);
    return $args;
});
