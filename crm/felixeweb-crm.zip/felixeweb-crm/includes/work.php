<?php
/**
 * "Work" layer: Today screen, tasks & promises, saved replies, video library,
 * phone alerts (ntfy / Telegram), calendar bookings, deal values, quick search, installable app.
 */
if (!defined('ABSPATH')) exit;

/* =========================================================
 * Settings defaults for this module
 * ======================================================= */

function fwcrm_w_opt($k) { return fwcrm_opt($k); }

/* =========================================================
 * Tasks & promises
 * ======================================================= */

function fwcrm_task_types() {
    return array('promise' => 'Promise', 'call' => 'Call', 'todo' => 'To-do');
}

function fwcrm_task_add($cid, $type, $title, $due = null, $email_id = 0) {
    global $wpdb;
    $wpdb->insert(fwcrm_t('tasks'), array(
        'contact_id' => (int) $cid,
        'type' => $type,
        'title' => wp_html_excerpt($title, 250, ''),
        'due' => $due,
        'email_id' => (int) $email_id,
        'created' => fwcrm_now(),
    ));
    $id = (int) $wpdb->insert_id;
    if ($cid) fwcrm_event($cid, 'task', array('title' => $title, 'type' => $type));
    return $id;
}

function fwcrm_task_done($id, $done = 1) {
    global $wpdb;
    return $wpdb->update(fwcrm_t('tasks'), array('done' => $done ? 1 : 0, 'done_at' => $done ? fwcrm_now() : null), array('id' => (int) $id));
}

function fwcrm_open_tasks($cid = 0, $limit = 200) {
    global $wpdb;
    $T = 'fwcrm_t';
    $w = $cid ? $wpdb->prepare(' AND t.contact_id = %d', $cid) : '';
    return $wpdb->get_results("SELECT t.*, c.company, c.first_name, c.last_name, c.email, c.stage FROM {$T('tasks')} t LEFT JOIN {$T('contacts')} c ON c.id = t.contact_id WHERE t.done = 0 $w ORDER BY (t.due IS NULL), t.due ASC, t.id ASC LIMIT " . (int) $limit);
}

/** What did Felix offer last? Used to word the promise. */
function fwcrm_last_offer($cid, $before_ts = null) {
    global $wpdb;
    $sql = "SELECT body, subject FROM " . fwcrm_t('emails') . " WHERE contact_id = %d AND direction = 'out' AND status = 'sent'";
    $args = array($cid);
    if ($before_ts) { $sql .= " AND sent_at <= %s"; $args[] = date('Y-m-d H:i:s', $before_ts); }
    $sql .= " ORDER BY sent_at DESC LIMIT 1";
    $o = $wpdb->get_row($wpdb->prepare($sql, $args));
    if (!$o) return '';
    $t = strtolower($o->body . ' ' . $o->subject);
    if (strpos($t, 'video') !== false) return 'video';
    if (preg_match('/\bcall\b|zoom|meet|calendar|slot/', $t)) return 'call';
    return '';
}

/** A lead said yes / asked something: create a promise so it can't be forgotten. */
function fwcrm_detect_promise($contact, $text, $email_id, $ts) {
    if (!$contact || in_array($contact->stage, array('won', 'lost'), true)) return 0;
    global $wpdb;
    $open = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " WHERE contact_id = %d AND done = 0 AND type IN ('promise','call')", $contact->id));
    if ($open) return 0;
    $t = trim(preg_replace('/\s+/', ' ', (string) $text));
    $head = mb_substr($t, 0, 500);
    if ($head === '') return 0;
    if (preg_match('/^\s*(no\b|nope|not interested|unsubscribe|remove me|stop\b)/i', $head) || preg_match('/\b(not (looking|interested)|no thanks|no thank you|please remove|don\'t contact)\b/i', $head)) return 0;
    $yes = preg_match('/\b(yes|yeah|yep|sure|ok(ay)?|please|interested|keen|go ahead|sounds (good|great|interesting)|would (love|like)|happy to|send (it|it over|me|the video|that)|love to see|let\'?s (do|talk|chat)|that would be great|great idea)\b/i', $head);
    $question = strpos($head, '?') !== false;
    if (!$yes && !$question) return 0;
    $offer = fwcrm_last_offer($contact->id, $ts);
    $name = fwcrm_lead_title($contact);
    if ($yes && $offer === 'video') $title = 'Send the video to ' . $name;
    elseif ($yes && $offer === 'call') $title = 'Book the call with ' . $name;
    elseif ($question) $title = 'Answer ' . $name . '\'s question';
    else $title = 'Follow up with ' . $name . ' (they said yes)';
    $hours = max(1, (int) fwcrm_w_opt('promise_hours'));
    $due = date('Y-m-d H:i:s', max($ts, current_time('timestamp') - 30 * DAY_IN_SECONDS) + $hours * HOUR_IN_SECONDS);
    return fwcrm_task_add($contact->id, 'promise', $title, $due, $email_id);
}

add_action('fwcrm_reply_received', function ($contact, $m, $email_id, $type, $first_run) {
    if ($type !== 'replies' && $type !== 'inbound') return;
    fwcrm_detect_promise($contact, $m['text'], $email_id, $m['ts']);
    if (!$first_run && fwcrm_w_opt('push_reply')) {
        fwcrm_push('💬 ' . fwcrm_lead_title($contact) . ' replied', wp_html_excerpt(trim(preg_replace('/\s+/', ' ', $m['text'])), 220, '…'), fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $contact->id)), 'speech_balloon');
    }
}, 10, 5);

/** Anything sent to a lead closes their open promises. */
add_action('fwcrm_sent_to_contact', function ($cid, $ts, $text) {
    global $wpdb;
    $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('tasks') . " SET done = 1, done_at = %s WHERE contact_id = %d AND done = 0 AND type = 'promise' AND created <= %s", fwcrm_now(), $cid, date('Y-m-d H:i:s', $ts + 60)));
}, 10, 3);

/** Close promises already answered (e.g. mail imported later from Gmail). */
function fwcrm_tasks_autocomplete() {
    global $wpdb;
    $T = 'fwcrm_t';
    return $wpdb->query($wpdb->prepare("UPDATE {$T('tasks')} t JOIN {$T('emails')} src ON src.id = t.email_id SET t.done = 1, t.done_at = %s
        WHERE t.done = 0 AND t.type = 'promise' AND EXISTS (SELECT 1 FROM {$T('emails')} o WHERE o.contact_id = t.contact_id AND o.direction = 'out' AND o.status = 'sent' AND o.source <> 'sheet' AND o.sent_at > src.sent_at)", fwcrm_now()));
}

/** One-time scan of unanswered replies → promises. */
function fwcrm_tasks_backfill() {
    global $wpdb;
    $n = 0;
    $rows = $wpdb->get_results("SELECT * FROM " . fwcrm_t('emails') . " WHERE direction = 'in' AND kind = 'reply' AND handled = 0 ORDER BY sent_at ASC");
    foreach ($rows as $e) {
        $c = fwcrm_get_contact($e->contact_id);
        if ($c && fwcrm_detect_promise($c, fwcrm_clean_text((string) ($e->body ?: $e->snippet)), $e->id, strtotime($e->sent_at))) $n++;
    }
    return $n;
}

add_action('admin_init', function () {
    if (get_option('fwcrm_tasks_backfilled') || !fwcrm_is_crm_screen()) return;
    update_option('fwcrm_tasks_backfilled', 1, false);
    fwcrm_tasks_backfill();
});

/** Overdue alerts, run every tick. */
function fwcrm_tasks_tick() {
    global $wpdb;
    if (!fwcrm_w_opt('push_tasks')) return;
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . fwcrm_t('tasks') . " WHERE done = 0 AND alerted = 0 AND due IS NOT NULL AND due <= %s LIMIT 10", fwcrm_now()));
    foreach ($rows as $t) {
        $wpdb->update(fwcrm_t('tasks'), array('alerted' => 1), array('id' => $t->id));
        fwcrm_push('⏰ ' . ($t->type === 'call' ? 'Call now: ' : 'Overdue: ') . $t->title, 'Due ' . fwcrm_time_ago($t->due) . '. Open the chat to do it now.', $t->contact_id ? fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $t->contact_id)) : fwcrm_admin_url('fwcrm'), 'alarm_clock');
    }
}
add_action('fwcrm_tick', function () {
    if (function_exists('fwcrm_is_site_mode') && fwcrm_is_site_mode()) return;
    fwcrm_tasks_autocomplete();
    fwcrm_tasks_tick();
}, 20);

/* =========================================================
 * Phone alerts
 * ======================================================= */

function fwcrm_push($title, $message, $url = '', $tag = '') {
    $sent = false;
    if (fwcrm_w_opt('push_ntfy') && fwcrm_w_opt('ntfy_topic')) {
        $r = wp_remote_post('https://ntfy.sh/', array('timeout' => 8, 'headers' => array('Content-Type' => 'application/json'), 'body' => wp_json_encode(array_filter(array(
            'topic' => fwcrm_w_opt('ntfy_topic'), 'title' => $title, 'message' => $message ?: ' ', 'click' => $url, 'tags' => $tag ? array($tag) : null, 'priority' => 4,
        )))));
        $sent = !is_wp_error($r) && wp_remote_retrieve_response_code($r) < 300;
        if (!$sent) fwcrm_log('Phone alert (ntfy) failed: ' . (is_wp_error($r) ? $r->get_error_message() : wp_remote_retrieve_response_code($r)));
    }
    $tok = fwcrm_decrypt(fwcrm_w_opt('tg_token'));
    if ($tok && fwcrm_w_opt('tg_chat')) {
        $r = wp_remote_post('https://api.telegram.org/bot' . $tok . '/sendMessage', array('timeout' => 8, 'body' => array(
            'chat_id' => fwcrm_w_opt('tg_chat'), 'text' => $title . "\n" . $message . ($url ? "\n\n" . $url : ''), 'disable_web_page_preview' => 'true',
        )));
        $ok = !is_wp_error($r) && wp_remote_retrieve_response_code($r) < 300;
        if (!$ok) fwcrm_log('Phone alert (Telegram) failed: ' . (is_wp_error($r) ? $r->get_error_message() : wp_remote_retrieve_body($r)));
        $sent = $sent || $ok;
    }
    return $sent;
}

/* =========================================================
 * Saved replies & video library
 * ======================================================= */

function fwcrm_default_snippets() {
    return array(
        array('id' => 's1', 'title' => 'Send the video', 'body' => "Hi {{first_name|there}},\n\nHere's the short video I mentioned, about 90 seconds, showing how this would work on {{company|your store}}:\n{{video}}\n\nIf it looks useful, pick a time here and I'll map it out for your store: {{booking_link}}"),
        array('id' => 's2', 'title' => 'Offer a quick call', 'body' => "Hi {{first_name|there}},\n\nThanks for getting back to me. The easiest way is a quick 15-minute call where I share my screen and walk through it for {{company|your store}}. Pick any time that suits you: {{booking_link}}"),
        array('id' => 's3', 'title' => 'Did you see the video?', 'body' => "Hi {{first_name|there}},\n\nJust checking the video came through. Happy to answer any questions, or we can go through it together on a quick call: {{booking_link}}"),
        array('id' => 's4', 'title' => 'Answer: how long it takes', 'body' => "Hi {{first_name|there}},\n\nGood question. A fix like this usually takes 3–5 days once we agree the details. I'll confirm the exact scope and price after a quick look at your setup: {{booking_link}}"),
        array('id' => 's5', 'title' => 'No problem, thanks', 'body' => "Hi {{first_name|there}},\n\nNo problem at all, thanks for letting me know. If anything changes with {{company|your store}}, I'm happy to help."),
    );
}

function fwcrm_snippets() {
    $s = get_option('fwcrm_snippets', null);
    return is_array($s) ? $s : fwcrm_default_snippets();
}

function fwcrm_videos() {
    $v = get_option('fwcrm_videos', array());
    return is_array($v) ? $v : array();
}

/** Videos titled "For <Store>: …" are made for one store; others are general. */
function fwcrm_video_store($v) {
    return preg_match('/^for\s+(.+?)\s*[:·\-–]/iu', $v['title'], $m) ? trim($m[1]) : '';
}
function fwcrm_pick_video($c) {
    $general = '';
    foreach (fwcrm_videos() as $v) {
        $store = fwcrm_video_store($v);
        if ($store === '') { if ($general === '') $general = $v['id']; continue; }
        if ($c && !empty($c->company) && stripos($c->company, $store) !== false) return $v['id'];
    }
    return $general;
}

function fwcrm_video_link($vid, $contact = null) {
    $args = array('fwv' => $vid);
    if ($contact && !empty($contact->token)) $args['fw'] = $contact->token;
    return add_query_arg($args, home_url('/'));
}

/** Merge a saved reply for one lead (also fills {{video}}, {{video:ID}}, {{booking_link}}, {{problem}}). */
function fwcrm_fill_snippet($body, $c) {
    $first_vid = fwcrm_pick_video($c);
    $body = preg_replace_callback('/\{\{\s*video(?::([a-z0-9]+))?\s*\}\}/i', function ($m) use ($c, $first_vid) {
        $id = !empty($m[1]) ? $m[1] : $first_vid;
        return $id ? fwcrm_video_link($id, $c) : '[no video for this store yet: pick one with 🎬 Video or add a general one in Replies]';
    }, $body);
    $body = str_replace(array('{{booking_link}}', '{{ booking_link }}'), fwcrm_w_opt('booking_url'), $body);
    $prob = $c ? fwcrm_first_problem($c, 160) : '';
    $body = preg_replace('/\{\{\s*problem\s*(?:\|([^}]*))?\}\}/i', $prob !== '' ? lcfirst($prob) : '$1', $body);
    return fwcrm_merge($body, $c);
}

/** Composer toolbar for a lead's chat. */
function fwcrm_composer_tools($c) {
    $snips = array();
    foreach (fwcrm_snippets() as $s) $snips[] = array('t' => $s['title'], 'b' => fwcrm_fill_snippet($s['body'], $c));
    $vids = array();
    foreach (fwcrm_videos() as $v) {
        $store = fwcrm_video_store($v);
        $mine = $store === '' || (!empty($c->company) && stripos($c->company, $store) !== false);
        $vids[] = array('t' => $v['title'] . ($mine ? '' : '  (made for another store)'), 'u' => fwcrm_video_link($v['id'], $c), 'm' => $mine ? 1 : 0);
    }
    usort($vids, function ($a, $b) { return $b['m'] - $a['m']; });
    $out = '<div class="fw-tools" data-snips="' . esc_attr(wp_json_encode($snips)) . '" data-vids="' . esc_attr(wp_json_encode($vids)) . '" data-book="' . esc_attr(fwcrm_w_opt('booking_url')) . '">';
    $out .= '<button type="button" class="fw-tool" data-tool="snip">⚡ Saved reply</button>';
    $out .= '<button type="button" class="fw-tool" data-tool="video">🎬 Video' . (!$vids ? ' <em>(none yet)</em>' : '') . '</button>';
    $out .= '<button type="button" class="fw-tool" data-tool="book">📅 Booking link</button>';
    $out .= '<a class="fw-tool ghost" href="' . esc_url(fwcrm_admin_url('fwcrm-replies')) . '">Edit…</a>';
    $out .= '<div class="fw-tool-menu" hidden></div></div>';
    return $out;
}

/* Video watch page: /?fwv=ID&fw=TOKEN */
add_action('template_redirect', function () {
    if (empty($_GET['fwv'])) return;
    $vid = preg_replace('/[^a-z0-9]/', '', strtolower($_GET['fwv']));
    $video = null;
    foreach (fwcrm_videos() as $v) if ($v['id'] === $vid) $video = $v;
    if (!$video) return;
    $contact = null;
    if (!empty($_GET['fw'])) $contact = fwcrm_get_contact_by_token(preg_replace('/[^a-z0-9]/', '', $_GET['fw']));
    if ($contact && !current_user_can('manage_options')) {
        $key = 'fwcrm_vw_' . $contact->id . '_' . $vid;
        if (!get_transient($key)) {
            set_transient($key, 1, 6 * HOUR_IN_SECONDS);
            fwcrm_event($contact->id, 'video_view', array('video' => $video['title']));
            fwcrm_add_score($contact->id, 15);
            fwcrm_update_contact($contact->id, array('last_visit' => fwcrm_now()));
            if (fwcrm_w_opt('push_hot')) fwcrm_push('🎬 ' . fwcrm_lead_title($contact) . ' is watching your video', $video['title'] . ' · now is a good time to follow up.', fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $contact->id)), 'movie_camera');
        }
    }
    $url = $video['url'];
    $embed = '';
    if (preg_match('#\.(mp4|mov|webm|m4v)(\?|$)#i', $url)) {
        $embed = '<video src="' . esc_url($url) . '" controls playsinline preload="metadata"' . (!empty($video['poster']) ? ' poster="' . esc_url($video['poster']) . '"' : '') . '></video>';
    } elseif (preg_match('#(?:youtu\.be/|youtube\.com/(?:watch\?v=|shorts/|embed/))([A-Za-z0-9_-]{6,})#', $url, $m)) {
        $embed = '<iframe src="https://www.youtube.com/embed/' . esc_attr($m[1]) . '?rel=0" allowfullscreen allow="autoplay; encrypted-media"></iframe>';
    } elseif (preg_match('#loom\.com/(?:share|embed)/([a-f0-9]+)#', $url, $m)) {
        $embed = '<iframe src="https://www.loom.com/embed/' . esc_attr($m[1]) . '" allowfullscreen></iframe>';
    } elseif (preg_match('#vimeo\.com/(\d+)#', $url, $m)) {
        $embed = '<iframe src="https://player.vimeo.com/video/' . esc_attr($m[1]) . '" allowfullscreen></iframe>';
    } else {
        wp_redirect(esc_url_raw($url));
        exit;
    }
    $vt = trim(preg_replace('/^for\s+.+?\s*[:·\-–]\s*/iu', '', $video['title'])) ?: $video['title'];
    $vt = mb_strtoupper(mb_substr($vt, 0, 1)) . mb_substr($vt, 1);
    $hi = $contact && $contact->first_name ? 'Hi ' . $contact->first_name . ', here\'s your video' : 'Your video from FelixeWeb';
    $for = $contact && $contact->company ? ' for ' . $contact->company : '';
    nocache_headers();
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . esc_html($vt) . ' · FelixeWeb</title><link rel="preconnect" href="https://fonts.gstatic.com"><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;800&display=swap" rel="stylesheet"><style>
*{box-sizing:border-box}body{margin:0;background:#0A0A0A;color:#F3EEE4;font-family:Montserrat,system-ui,sans-serif;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:28px 18px}
.top{width:100%;max-width:920px;display:flex;align-items:center;gap:10px;margin-bottom:26px}.mk{width:34px;height:34px;border:2px solid #B08A2E;border-radius:9px;display:grid;place-items:center;font-weight:800;font-size:13px}.mk b{color:#B08A2E}.wd{letter-spacing:.22em;font-size:12px;font-weight:600}.wd b{color:#B08A2E}
h1{font-size:clamp(24px,4vw,40px);line-height:1.05;letter-spacing:-.02em;margin:0 0 8px;max-width:920px;width:100%}p.s{color:#bfb7a8;margin:0 0 22px;max-width:920px;width:100%;font-size:15px}
.v{width:100%;max-width:920px;aspect-ratio:16/9;background:#141414;border:1px solid #2a2722;border-radius:16px;overflow:hidden}.v video,.v iframe{width:100%;height:100%;border:0;display:block;background:#000}
.cta{margin-top:26px;display:flex;gap:12px;flex-wrap:wrap;justify-content:center}.b{display:inline-block;padding:15px 26px;border-radius:12px;font-weight:700;text-decoration:none;font-size:15px}.g{background:#B08A2E;color:#0A0A0A}.o{border:1px solid #3a352c;color:#F3EEE4}
small{margin-top:30px;color:#7d776c;font-size:12px}</style></head><body>';
    echo '<div class="top"><span class="mk">F<b>W</b></span><span class="wd">FELIXE<b>WEB</b></span></div>';
    echo '<h1>' . esc_html($hi) . '</h1><p class="s">' . esc_html($vt . $for) . '. Built by FelixeWeb, stores that sell, live in 7–10 days.</p>';
    echo '<div class="v">' . $embed . '</div>';
    echo '<div class="cta"><a class="b g" href="' . esc_url(fwcrm_w_opt('booking_url')) . '" target="_blank" rel="noopener">Book a 30-minute call</a><a class="b o" href="' . esc_url(fwcrm_opt('website_url') ?: home_url('/')) . '">See more work</a></div>';
    echo '<small>Questions? Just reply to my email.</small></body></html>';
    exit;
});

/* =========================================================
 * Calendar bookings (Google Calendar emails) → Call booked
 * ======================================================= */

function fwcrm_maybe_booking($m, $msg, $first_run) {
    $from = implode(',', $m['from']);
    $raw = $msg['header'] . "\n" . $msg['body'];
    $is_cal = strpos($from, 'calendar-notification@google.com') !== false
        || stripos($raw, 'BEGIN:VCALENDAR') !== false
        || preg_match('/^(invitation|updated invitation|new event|appointment booked|new appointment|booked|accepted)\s*:/i', $m['subject']);
    if (!$is_cal) return false;
    if (preg_match('/^(declined|canceled|cancelled|invitation canceled)/i', $m['subject'])) return true;
    $contact = null;
    foreach (fwcrm_addresses($raw) as $addr) {
        if (fwcrm_ignored_address($addr) || preg_match('/@(google\.com|calendar\.google\.com|gmail\.com\.invalid)$/', $addr)) continue;
        $contact = fwcrm_get_contact_by_email($addr);
        if ($contact) break;
    }
    if (!$contact) return true;
    $start = null;
    if (preg_match('/DTSTART(?:;TZID=([^:;]+))?[^:]*:(\d{8}T\d{4,6})(Z?)/', str_replace("\r\n ", '', $raw), $mm)) {
        try {
            $tz = $mm[3] === 'Z' ? new DateTimeZone('UTC') : new DateTimeZone($mm[1] ?: wp_timezone_string());
            $dt = new DateTime(substr($mm[2], 0, 13) . (strlen($mm[2]) > 13 ? substr($mm[2], 13) : ''), $tz);
            $dt->setTimezone(wp_timezone());
            $start = $dt->format('Y-m-d H:i:s');
        } catch (\Exception $e) { $start = null; }
    }
    if (!$start && preg_match('/@\s*([^()\n]+?)\s*-\s*\d/', $m['subject'], $mm)) {
        $ts = strtotime(trim($mm[1]));
        if ($ts) $start = date('Y-m-d H:i:s', $ts);
    }
    global $wpdb;
    $exists = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " WHERE contact_id = %d AND type = 'call' AND done = 0", $contact->id));
    if (!in_array($contact->stage, array('proposal', 'won', 'lost'), true)) fwcrm_update_contact($contact->id, array('stage' => 'call'));
    if (!$exists && (!$start || strtotime($start) > current_time('timestamp') - DAY_IN_SECONDS)) {
        fwcrm_task_add($contact->id, 'call', 'Call with ' . fwcrm_lead_title($contact), $start);
        fwcrm_event($contact->id, 'booked', array('at' => $start));
        // Booking answers any open promise.
        $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('tasks') . " SET done = 1, done_at = %s WHERE contact_id = %d AND done = 0 AND type = 'promise'", fwcrm_now(), $contact->id));
        if (!$first_run) fwcrm_push('📅 ' . fwcrm_lead_title($contact) . ' booked a call', $start ? date_i18n('l j M, H:i', strtotime($start)) : 'Check your calendar', fwcrm_admin_url('fwcrm-contacts', array('view' => $contact->id)), 'calendar');
    }
    return true;
}

/* =========================================================
 * Deal values
 * ======================================================= */

function fwcrm_money($v) {
    $v = (float) $v;
    return '$' . number_format($v, $v == floor($v) ? 0 : 2);
}

/* =========================================================
 * Today screen
 * ======================================================= */

function fwcrm_page_today() {
    global $wpdb;
    $T = 'fwcrm_t';
    $now = current_time('timestamp');
    $tasks = fwcrm_open_tasks(0, 100);
    $over = $soon = $later = array();
    foreach ($tasks as $t) {
        $due = $t->due ? strtotime($t->due) : null;
        if ($due !== null && $due <= $now) $over[] = $t;
        elseif ($due === null || $due <= strtotime('tomorrow 23:59', $now)) $soon[] = $t;
        else $later[] = $t;
    }
    $task_cids = array_map('intval', wp_list_pluck($tasks, 'contact_id'));
    $replies = $wpdb->get_results("SELECT e.*, c.company, c.first_name, c.last_name, c.email, c.stage FROM {$T('emails')} e JOIN {$T('contacts')} c ON c.id = e.contact_id WHERE e.direction = 'in' AND e.kind = 'reply' AND e.handled = 0 ORDER BY e.sent_at ASC LIMIT 50");
    $seen = array();
    $replies = array_values(array_filter($replies, function ($r) use (&$seen) { if (isset($seen[$r->contact_id])) return false; $seen[$r->contact_id] = 1; return true; }));
    $d2 = date('Y-m-d H:i:s', $now - 2 * DAY_IN_SECONDS);
    $hot = $wpdb->get_results($wpdb->prepare("SELECT c.*, (SELECT type FROM {$T('events')} ev WHERE ev.contact_id = c.id AND ev.type IN ('open','click','visit','cta_click','video_view') ORDER BY ev.id DESC LIMIT 1) last_sig, (SELECT created FROM {$T('events')} ev WHERE ev.contact_id = c.id AND ev.type IN ('open','click','visit','cta_click','video_view') ORDER BY ev.id DESC LIMIT 1) last_sig_at FROM {$T('contacts')} c WHERE c.stage NOT IN ('won','lost') AND (c.last_open >= %s OR c.last_click >= %s OR c.last_visit >= %s) AND (c.last_reply IS NULL OR c.last_reply < GREATEST(COALESCE(c.last_open,'1970-01-01'), COALESCE(c.last_click,'1970-01-01'), COALESCE(c.last_visit,'1970-01-01'))) ORDER BY GREATEST(COALESCE(c.last_open,'1970-01-01'), COALESCE(c.last_click,'1970-01-01'), COALESCE(c.last_visit,'1970-01-01')) DESC LIMIT 12", $d2, $d2, $d2));
    $due = fwcrm_followups_due(30);
    $count = count($over) + count($soon) + count($replies) + count($hot);
    $hour = (int) date('G', $now);
    $greet = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
    $sub = $count ? sprintf('%d thing%s need%s you. Start at the top.', $count, $count === 1 ? '' : 's', $count === 1 ? 's' : '') : 'All clear. Nothing waiting on you right now.';
    fwcrm_header($greet . ', Felix', $sub, '<button class="fw-btn" data-fw-ajax="fwcrm_sync_now">↻ Check mail</button><button class="fw-btn gold" data-fw-open="task">+ Task</button>');

    echo '<div class="fw-today">';
    // Promises & tasks
    echo '<section class="fw-tsec"><div class="fw-tsec-h"><h2>Promises &amp; calls</h2><span class="fw-dim">' . count($over) . ' overdue · ' . count($soon) . ' today/tomorrow</span></div>';
    if (!$over && !$soon && !$later) echo '<div class="fw-tempty">No promises open. When a lead says “yes, send it” a task appears here automatically.</div>';
    foreach (array_merge($over, $soon, $later) as $t) echo fwcrm_task_row($t, $now);
    echo '</section>';

    // Replies
    echo '<section class="fw-tsec"><div class="fw-tsec-h"><h2>Replies waiting</h2><span class="fw-dim">oldest first</span></div>';
    if (!$replies) echo '<div class="fw-tempty">No replies waiting. Nice.</div>';
    foreach ($replies as $r) {
        $age = $now - strtotime($r->sent_at);
        $cls = $age > DAY_IN_SECONDS ? ' late' : '';
        echo '<a class="fw-trow' . $cls . '" href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', array('tab' => 'waiting', 'c' => $r->contact_id))) . '"><span class="fw-ticon">💬</span><div class="fw-tmain"><b>' . esc_html(fwcrm_lead_title($r)) . '</b><p>' . esc_html(wp_html_excerpt(preg_replace('/\s+/', ' ', fwcrm_clean_text((string) ($r->body ?: $r->snippet))), 140, '…')) . '</p></div><span class="fw-twhen">' . esc_html(fwcrm_time_ago($r->sent_at)) . '</span><span class="fw-btn sm gold">Reply</span></a>';
    }
    echo '</section>';

    // Hot leads
    echo '<section class="fw-tsec"><div class="fw-tsec-h"><h2>Hot right now</h2><span class="fw-dim">opened, clicked, visited or watched in the last 48h</span></div>';
    if (!$hot) echo '<div class="fw-tempty">No one is warm right now. Video links you send from the CRM are tracked, so watchers show up here.</div>';
    $sig = array('open' => 'opened your email', 'click' => 'clicked your link', 'visit' => 'is on your website', 'cta_click' => 'clicked a button on your site', 'video_view' => 'watched your video');
    foreach ($hot as $c) {
        echo '<a class="fw-trow" href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $c->id))) . '"><span class="fw-ticon">🔥</span><div class="fw-tmain"><b>' . esc_html(fwcrm_lead_title($c)) . '</b><p>' . esc_html(isset($sig[$c->last_sig]) ? $sig[$c->last_sig] : 'was active') . ' · ' . esc_html(fwcrm_time_ago($c->last_sig_at)) . '</p></div>' . fwcrm_stage_pill($c->stage) . '<span class="fw-btn sm">Follow up</span></a>';
    }
    echo '</section>';

    // Follow-ups due
    echo '<section class="fw-tsec"><div class="fw-tsec-h"><h2>Follow-ups due</h2><span class="fw-dim">the scout sends these automatically each morning</span></div>';
    if (!$due) echo '<div class="fw-tempty">Nothing due.</div>';
    foreach (array_slice($due, 0, 10) as $c) {
        echo '<a class="fw-trow" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><span class="fw-ticon">↻</span><div class="fw-tmain"><b>' . esc_html(fwcrm_lead_title($c)) . '</b><p>' . esc_html(fwcrm_first_problem($c, 100) ?: $c->email) . '</p></div><span class="fw-twhen">' . esc_html(fwcrm_time_ago($c->next_followup)) . '</span></a>';
    }
    if (count($due) > 10) echo '<a class="fw-more" href="' . esc_url(fwcrm_admin_url('fwcrm-sequences')) . '">+ ' . (count($due) - 10) . ' more</a>';
    echo '</section></div>';
    echo fwcrm_task_modal();
    fwcrm_footer();
}

function fwcrm_task_row($t, $now = null) {
    $now = $now ?: current_time('timestamp');
    $due = $t->due ? strtotime($t->due) : null;
    $late = $due !== null && $due <= $now;
    $icon = $t->type === 'call' ? '📞' : ($t->type === 'promise' ? '🤝' : '✓');
    $when = $due ? ($late ? 'overdue · ' . fwcrm_time_ago($t->due) : date_i18n('D j M, H:i', $due)) : 'no date';
    $link = $t->contact_id ? fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $t->contact_id)) : '';
    $o = '<div class="fw-trow task' . ($late ? ' late' : '') . '"><button class="fw-tcheck" data-fw-ajax="fwcrm_task_done" data-id="' . (int) $t->id . '" title="Mark done"></button><span class="fw-ticon">' . $icon . '</span><div class="fw-tmain"><b>' . esc_html($t->title) . '</b><p>' . (!empty($t->assigned_to) && function_exists('fwcrm_member_avatar') && get_userdata($t->assigned_to) ? '<span class="fw-who">' . fwcrm_member_avatar($t->assigned_to) . esc_html(get_userdata($t->assigned_to)->display_name) . '</span> · ' : '') . esc_html($when) . (!empty($t->company) || !empty($t->email) ? ' · ' . esc_html(fwcrm_lead_title($t)) : '') . '</p></div>';
    if ($link) $o .= '<a class="fw-btn sm ' . ($late ? 'gold' : '') . '" href="' . esc_url($link) . '">Open chat</a>';
    return $o . '</div>';
}

function fwcrm_task_modal($cid = 0) {
    $o = '<dialog class="fw-dialog" id="fw-task-dlg">' . fwcrm_post_form_open('fwcrm_add_task') . '<input type="hidden" name="contact_id" value="' . (int) $cid . '"><h3>New task</h3>';
    $o .= '<label class="fw-f"><span>What needs doing?</span><input name="title" required placeholder="e.g. Send the video to NobelPepLab"></label>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Due</span><input type="datetime-local" name="due" value="' . esc_attr(date('Y-m-d\TH:i', current_time('timestamp') + 2 * HOUR_IN_SECONDS)) . '"></label><label class="fw-f"><span>Type</span><select name="type">';
    foreach (fwcrm_task_types() as $k => $l) $o .= '<option value="' . esc_attr($k) . '"' . selected($k, $cid ? 'promise' : 'todo', false) . '>' . esc_html($l) . '</option>';
    $o .= '</select></label></div><div class="fw-btnrow"><button type="button" class="fw-btn ghost" data-fw-close>Cancel</button><button class="fw-btn gold">Add task</button></div></form></dialog>';
    return $o;
}

add_action('admin_post_fwcrm_add_task', function () {
    fwcrm_guard('fwcrm_add_task');
    $p = wp_unslash($_POST);
    $cid = (int) $p['contact_id'];
    $due = !empty($p['due']) ? date('Y-m-d H:i:s', strtotime(sanitize_text_field($p['due']))) : null;
    $type = isset(fwcrm_task_types()[$p['type']]) ? $p['type'] : 'todo';
    fwcrm_task_add($cid, $type, sanitize_text_field($p['title']), $due);
    fwcrm_back($cid ? 'fwcrm-contacts' : 'fwcrm', $cid ? array('view' => $cid) : array(), 'Task added.');
});

/* =========================================================
 * Replies & videos page
 * ======================================================= */

function fwcrm_page_replies() {
    fwcrm_header('Replies & videos', 'Saved replies fill in each lead\'s name, business and problem. Videos get a tracked watch page, so you see who watched.', '');
    $snips = fwcrm_snippets();
    echo '<div class="fw-grid2"><div class="fw-card">' . fwcrm_post_form_open('fwcrm_save_snippets') . '<div class="fw-card-h"><h3>Saved replies</h3><button class="fw-btn sm gold">Save all</button></div>';
    echo '<p class="fw-dim">Use <code>{{first_name|there}}</code>, <code>{{company|your store}}</code>, <code>{{problem}}</code>, <code>{{video}}</code> (your first video) or <code>{{video:ID}}</code>, and <code>{{booking_link}}</code>. Your signature is added when sending.</p><div class="fw-snips">';
    foreach (array_merge($snips, array(array('id' => '', 'title' => '', 'body' => ''))) as $i => $s) {
        echo '<div class="fw-snip' . ($s['id'] === '' ? ' new' : '') . '"><input type="hidden" name="snips[' . $i . '][id]" value="' . esc_attr($s['id']) . '"><input name="snips[' . $i . '][title]" value="' . esc_attr($s['title']) . '" placeholder="' . ($s['id'] === '' ? '+ New saved reply title' : 'Title') . '"><textarea name="snips[' . $i . '][body]" rows="5" placeholder="Reply text…">' . esc_textarea($s['body']) . '</textarea>' . ($s['id'] !== '' ? '<label class="fw-check sm"><input type="checkbox" name="snips[' . $i . '][del]" value="1"> Delete</label>' : '') . '</div>';
    }
    echo '</div><div class="fw-btnrow"><button class="fw-btn gold">Save all</button></div></form></div>';

    echo '<div><div class="fw-card"><h3>Video library</h3><p class="fw-dim">Upload your 90-second walkthroughs once (MP4 or MOV), or paste a YouTube / Loom / Vimeo link. Each lead gets their own tracked link, and you get an alert when they watch. Start a title with <b>For Store Name:</b> when a video was made for one store; it is then only suggested for that lead. Other videos count as general.</p>';
    echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="fwcrm_add_video">' . wp_nonce_field('fwcrm_fwcrm_add_video', '_fwnonce', true, false);
    echo '<label class="fw-f"><span>Title</span><input name="title" required placeholder="e.g. Manual-payment checkout walkthrough"></label><label class="fw-f"><span>Upload a video file</span><input type="file" name="file" accept="video/*"></label><label class="fw-f"><span>…or paste a video link</span><input name="url" placeholder="https://www.loom.com/share/…"></label><div class="fw-btnrow"><span class="fw-dim">Max upload size on your hosting: ' . esc_html(size_format(wp_max_upload_size())) . '</span><button class="fw-btn gold">Add video</button></div></form></div>';
    $vids = fwcrm_videos();
    echo '<div class="fw-card"><h3>Your videos</h3>';
    if (!$vids) echo '<div class="fw-empty">No videos yet.</div>';
    global $wpdb;
    foreach ($vids as $v) {
        $views = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('events') . " WHERE type = 'video_view' AND meta LIKE %s", '%' . $wpdb->esc_like('"' . $v['title'] . '"') . '%'));
        echo '<div class="fw-vid"><div><b>' . esc_html($v['title']) . '</b><small>ID <code>' . esc_html($v['id']) . '</code> · ' . $views . ' lead view' . ($views === 1 ? '' : 's') . ' · <a href="' . esc_url(fwcrm_video_link($v['id'])) . '" target="_blank">preview ↗</a></small></div>' . fwcrm_post_form_open('fwcrm_del_video', 'onsubmit="return confirm(\'Remove this video from the library?\')"') . '<input type="hidden" name="id" value="' . esc_attr($v['id']) . '"><button class="fw-link danger">Remove</button></form></div>';
    }
    echo '</div></div></div>';
    fwcrm_footer();
}

add_action('admin_post_fwcrm_save_snippets', function () {
    fwcrm_guard('fwcrm_save_snippets');
    $out = array();
    foreach ((array) (isset($_POST['snips']) ? wp_unslash($_POST['snips']) : array()) as $s) {
        $title = sanitize_text_field(isset($s['title']) ? $s['title'] : '');
        $body = sanitize_textarea_field(isset($s['body']) ? $s['body'] : '');
        if (!empty($s['del']) || ($title === '' && $body === '')) continue;
        $out[] = array('id' => !empty($s['id']) ? sanitize_key($s['id']) : 's' . strtolower(wp_generate_password(5, false, false)), 'title' => $title ?: wp_html_excerpt($body, 30, '…'), 'body' => $body);
    }
    update_option('fwcrm_snippets', $out, false);
    fwcrm_back('fwcrm-replies', array(), 'Saved replies updated.');
});

add_action('admin_post_fwcrm_add_video', function () {
    fwcrm_guard('fwcrm_add_video');
    $title = sanitize_text_field(wp_unslash($_POST['title']));
    $url = esc_url_raw(wp_unslash(isset($_POST['url']) ? $_POST['url'] : ''));
    if (!empty($_FILES['file']['name'])) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $att = media_handle_upload('file', 0, array('post_title' => $title));
        if (is_wp_error($att)) fwcrm_back('fwcrm-replies', array(), 'Upload failed: ' . $att->get_error_message(), true);
        $url = wp_get_attachment_url($att);
    }
    if (!$url) fwcrm_back('fwcrm-replies', array(), 'Choose a video file or paste a link.', true);
    $v = fwcrm_videos();
    $v[] = array('id' => strtolower(wp_generate_password(6, false, false)), 'title' => $title, 'url' => $url);
    update_option('fwcrm_videos', $v, false);
    fwcrm_back('fwcrm-replies', array(), 'Video added.');
});

add_action('admin_post_fwcrm_del_video', function () {
    fwcrm_guard('fwcrm_del_video');
    $id = sanitize_key($_POST['id']);
    update_option('fwcrm_videos', array_values(array_filter(fwcrm_videos(), function ($v) use ($id) { return $v['id'] !== $id; })), false);
    fwcrm_back('fwcrm-replies', array(), 'Video removed.');
});

/* =========================================================
 * AJAX: tasks, search, push test, deal value
 * ======================================================= */

add_action('wp_ajax_fwcrm_work', function () {
    if (!current_user_can('manage_options') || !check_ajax_referer('fwcrm', 'nonce', false)) wp_send_json_error('Not allowed');
    global $wpdb;
    $do = sanitize_key($_POST['do']);
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
    switch ($do) {
        case 'search':
            $q = trim(sanitize_text_field(wp_unslash($_POST['q'])));
            if ($q === '') wp_send_json_success(array('items' => array()));
            $like = '%' . $wpdb->esc_like($q) . '%';
            $rows = $wpdb->get_results($wpdb->prepare("SELECT id, company, first_name, last_name, email, stage, country, website FROM " . fwcrm_t('contacts') . " WHERE company LIKE %s OR email LIKE %s OR first_name LIKE %s OR last_name LIKE %s OR website LIKE %s OR country LIKE %s ORDER BY (company LIKE %s) DESC, COALESCE(last_reply, last_contacted, created) DESC LIMIT 8", $like, $like, $like, $like, $like, $like, $wpdb->esc_like($q) . '%'));
            $st = fwcrm_stages();
            $items = array();
            foreach ($rows as $r) $items[] = array('t' => fwcrm_lead_title($r), 's' => trim($r->email . ($r->country ? ' · ' . $r->country : '')), 'st' => isset($st[$r->stage]) ? $st[$r->stage] : $r->stage, 'u' => fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $r->id)), 'l' => fwcrm_admin_url('fwcrm-contacts', array('view' => $r->id)));
            wp_send_json_success(array('items' => $items));
        case 'push_test':
            $ok = fwcrm_push('✅ FelixeWeb Hub alerts work', 'You will get replies, overdue promises, video views and bookings here.', fwcrm_admin_url('fwcrm'), 'white_check_mark');
            $ok ? wp_send_json_success(array('msg' => 'Test alert sent. Check your phone.')) : wp_send_json_error('No alert went out. Turn on ntfy (with a topic) or add your Telegram bot token and chat ID, then save.');
        case 'deal':
            $v = max(0, (float) preg_replace('/[^0-9.]/', '', wp_unslash($_POST['v'])));
            fwcrm_update_contact($id, array('deal_value' => $v));
            wp_send_json_success(array('msg' => 'Deal value saved: ' . fwcrm_money($v)));
    }
    wp_send_json_error('Unknown action');
});

/** Hook into the main fwcrm ajax router for one-click task buttons. */
add_action('wp_ajax_fwcrm', function () {
    if (!isset($_POST['do']) || !in_array($_POST['do'], array('fwcrm_task_done', 'fwcrm_task_undo'), true)) return;
    if (!current_user_can('manage_options') || !check_ajax_referer('fwcrm', 'nonce', false)) wp_send_json_error('Not allowed');
    fwcrm_task_done((int) $_POST['id'], $_POST['do'] === 'fwcrm_task_done');
    wp_send_json_success(array('msg' => 'Done ✓', 'remove' => 1));
}, 1);


/* =========================================================
 * Installable app (PWA)
 * ======================================================= */

add_action('admin_head', function () {
    if (!fwcrm_is_crm_screen()) return;
    echo '<link rel="manifest" href="' . esc_url(admin_url('admin-ajax.php?action=fwcrm_manifest')) . '"><meta name="theme-color" content="#0A0A0A"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="FW Hub"><link rel="apple-touch-icon" href="' . esc_url(FWCRM_URL . 'assets/icon-192.png') . '">';
});

function fwcrm_manifest() {
    header('Content-Type: application/manifest+json');
    echo wp_json_encode(array(
        'name' => 'FelixeWeb Hub', 'short_name' => 'FW Hub', 'id' => '/fwcrm-hub',
        'start_url' => admin_url('admin.php?page=fwcrm'), 'scope' => admin_url('/'),
        'display' => 'standalone', 'background_color' => '#0A0A0A', 'theme_color' => '#0A0A0A',
        'icons' => array(
            array('src' => FWCRM_URL . 'assets/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'),
            array('src' => FWCRM_URL . 'assets/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'),
        ),
        'shortcuts' => array(
            array('name' => 'Inbox', 'url' => admin_url('admin.php?page=fwcrm-inbox')),
            array('name' => 'Pipeline', 'url' => admin_url('admin.php?page=fwcrm-pipeline')),
        ),
    ));
    exit;
}
add_action('wp_ajax_fwcrm_manifest', 'fwcrm_manifest');
add_action('wp_ajax_nopriv_fwcrm_manifest', 'fwcrm_manifest');

function fwcrm_sw() {
    header('Content-Type: application/javascript; charset=utf-8');
    header('Service-Worker-Allowed: ' . wp_parse_url(admin_url('/'), PHP_URL_PATH));
    header('Cache-Control: no-cache');
    echo "self.addEventListener('install',function(e){self.skipWaiting();});self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});self.addEventListener('fetch',function(e){if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(function(){return new Response('<!doctype html><meta name=viewport content=\"width=device-width\"><body style=\"background:#0A0A0A;color:#F3EEE4;font-family:system-ui;display:grid;place-items:center;height:100vh;margin:0\"><div style=text-align:center><h2>You are offline</h2><p>The Hub will load again when you are back online.</p></div>',{headers:{'Content-Type':'text/html'}});}));}});";
    exit;
}
add_action('wp_ajax_fwcrm_sw', 'fwcrm_sw');
add_action('wp_ajax_nopriv_fwcrm_sw', 'fwcrm_sw');

/** Bottom navigation for phones + search dialog, printed once per CRM screen. */
add_action('admin_footer', function () {
    if (!fwcrm_is_crm_screen() || (function_exists('fwcrm_is_site_mode') && fwcrm_is_site_mode()) || (function_exists('fwcrm_is_member') && fwcrm_is_member())) return;
    global $wpdb;
    $waiting = (int) $wpdb->get_var("SELECT COUNT(DISTINCT contact_id) FROM " . fwcrm_t('emails') . " WHERE direction='in' AND kind='reply' AND handled=0");
    $over = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " WHERE done = 0 AND due IS NOT NULL AND due <= %s", fwcrm_now()));
    $cur = sanitize_key($_GET['page']);
    $items = array(
        'fwcrm' => array('Today', '<path d="M4 6h16M4 12h16M4 18h10"/>', $over),
        'fwcrm-inbox' => array('Inbox', '<path d="M4 5h16v11H8l-4 4z"/>', $waiting),
        'fwcrm-contacts' => array('Leads', '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5M16 4.5a3.5 3.5 0 010 7M18 14.8c2 .7 3.2 2.5 3.6 5.2"/>', 0),
        'fwcrm-pipeline' => array('Pipeline', '<rect x="3" y="4" width="5" height="16" rx="1.5"/><rect x="10" y="4" width="5" height="11" rx="1.5"/><rect x="17" y="4" width="4" height="7" rx="1.5"/>', 0),
    );
    echo '<nav class="fw-bnav">';
    foreach ($items as $slug => $it) echo '<a class="' . ($slug === $cur ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url($slug)) . '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $it[1] . '</svg>' . esc_html($it[0]) . ($it[2] ? '<i>' . (int) $it[2] . '</i>' : '') . '</a>';
    $more_on = in_array($cur, array('fwcrm-projects', 'fwcrm-team', 'fwcrm-sequences', 'fwcrm-replies', 'fwcrm-visitors', 'fwcrm-social', 'fwcrm-stats', 'fwcrm-settings', 'fwcrm-ai'), true);
    echo '<button type="button" class="' . ($more_on ? 'on' : '') . '" data-fw-open="more"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>More</button></nav>';
    $more = array(
        'fwcrm-projects' => array('Projects', '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M8 6V4h8v2"/>'),
        'fwcrm-team' => array('Team', '<circle cx="9" cy="8" r="3.5"/><circle cx="17" cy="9" r="2.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5M16 14.5c2.6 0 4.6 1.8 5.3 5.5"/>'),
        'fwcrm-sequences' => array('Follow-ups', '<path d="M4 12a8 8 0 0114-5.3M20 12a8 8 0 01-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/>'),
        'fwcrm-replies' => array('Replies & videos', '<rect x="3" y="5" width="13" height="14" rx="2"/><path d="M16 10l5-3v10l-5-3"/>'),
        'fwcrm-visitors' => array('Website', '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>'),
        'fwcrm-social' => array('Social', '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.6M8.2 13.2l7.6 4.6"/>'),
        'fwcrm-stats' => array('Stats', '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
        'fwcrm-settings' => array('Settings', '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>'),
    );
    if (fwcrm_ai_key() !== '') $more['fwcrm-ai'] = array('My AI', '<path d="M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/>');
    echo '<dialog class="fw-sheet" id="fw-more-dlg"><div class="fw-sheet-grip"></div><div class="fw-sheet-grid">';
    foreach ($more as $slug => $m) echo '<a class="' . ($slug === $cur ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url($slug)) . '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $m[1] . '</svg>' . esc_html($m[0]) . '</a>';
    echo '<a href="' . esc_url(admin_url()) . '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M5 9l3.5 9L12 10l3.5 8L19 9"/></svg>WordPress</a>';
    echo '</div><button type="button" class="fw-btn fw-sheet-close" data-fw-close>Close</button></dialog>';
    echo '<dialog class="fw-dialog fw-search" id="fw-search"><div class="fw-search-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/></svg><input type="search" placeholder="Search leads by business, name, email, website or country…" autocomplete="off"><kbd>esc</kbd></div><div class="fw-search-res"></div><div class="fw-search-go">';
    foreach (array('fwcrm' => 'Today', 'fwcrm-inbox' => 'Inbox', 'fwcrm-contacts' => 'Leads', 'fwcrm-pipeline' => 'Pipeline', 'fwcrm-projects' => 'Projects', 'fwcrm-team' => 'Team', 'fwcrm-replies' => 'Replies & videos', 'fwcrm-stats' => 'Stats', 'fwcrm-settings' => 'Settings') as $s => $l) echo '<a href="' . esc_url(fwcrm_admin_url($s)) . '">' . esc_html($l) . '</a>';
    echo '</div></dialog>';
});
