<?php
if (!defined('ABSPATH')) exit;

/** Is now inside the sending window (site timezone)? */
function fwcrm_in_window() {
    $now = current_time('timestamp');
    $dow = (int) date('N', $now); // 1 = Mon
    $days = array_map('intval', (array) fwcrm_opt('workdays', array(1, 2, 3, 4, 5)));
    if (!in_array($dow, $days, true)) return false;
    $h = (int) date('G', $now);
    return $h >= (int) fwcrm_opt('window_start', 9) && $h < (int) fwcrm_opt('window_end', 18);
}

/** Next moment inside the window at or after $ts, with a little random jitter so sends look human. */
function fwcrm_next_window_time($ts) {
    $days = array_map('intval', (array) fwcrm_opt('workdays', array(1, 2, 3, 4, 5)));
    if (!$days) $days = array(1, 2, 3, 4, 5);
    $start = (int) fwcrm_opt('window_start', 9);
    $end = (int) fwcrm_opt('window_end', 18);
    for ($i = 0; $i < 14; $i++) {
        $dow = (int) date('N', $ts);
        $h = (int) date('G', $ts);
        if (in_array($dow, $days, true)) {
            if ($h < $start) return strtotime(date('Y-m-d', $ts) . sprintf(' %02d:%02d:00', $start, wp_rand(0, 50)));
            if ($h < $end) return $ts;
        }
        $ts = strtotime(date('Y-m-d', $ts) . ' 00:00:00 +1 day');
    }
    return $ts;
}

function fwcrm_strip_re($s) {
    return trim(preg_replace('/^((re|fw|fwd|aw|sv)\s*:\s*)+/i', '', (string) $s));
}

/** Send due follow-ups, respecting the daily cap, sending window and spacing. */
function fwcrm_run_automations($force = false) {
    global $wpdb;
    if (!fwcrm_mailbox_ready()) return 0;
    if (!$force && !fwcrm_in_window()) return 0;
    $cap = (int) fwcrm_opt('daily_cap', 30);
    $left = $cap - fwcrm_sent_today();
    if ($left <= 0) return 0;
    $gap = max(0, (int) fwcrm_opt('min_gap_minutes', 4)) * 60;
    $last = (int) get_option('fwcrm_last_send_ts', 0);
    if (!$force && $last && (time() - $last) < $gap) return 0;

    $limit = $force ? min($left, 10) : 1;
    $due = $wpdb->get_results($wpdb->prepare(
        "SELECT e.* FROM " . fwcrm_t('enrollments') . " e JOIN " . fwcrm_t('sequences') . " s ON s.id = e.sequence_id
         WHERE e.status = 'active' AND s.active = 1 AND e.next_run <= %s ORDER BY e.next_run ASC LIMIT %d",
        fwcrm_now(), $limit
    ));
    $sent = 0;
    foreach ($due as $en) {
        if (fwcrm_process_enrollment($en)) {
            $sent++;
            update_option('fwcrm_last_send_ts', time(), false);
        }
    }
    return $sent;
}

function fwcrm_process_enrollment($en) {
    global $wpdb;
    $c = fwcrm_get_contact($en->contact_id);
    $seq = fwcrm_get_sequence($en->sequence_id);
    $upd = function ($data) use ($wpdb, $en) {
        $data['updated'] = fwcrm_now();
        $wpdb->update(fwcrm_t('enrollments'), $data, array('id' => $en->id));
    };
    if (!$c || !$seq) { $upd(array('status' => 'stopped')); return false; }
    if ($c->unsubscribed) { $upd(array('status' => 'unsubscribed')); return false; }
    if ($c->bounced) { $upd(array('status' => 'bounced')); return false; }
    if ($c->last_reply && strtotime($c->last_reply) >= strtotime($en->created) - DAY_IN_SECONDS) {
        $upd(array('status' => 'replied'));
        fwcrm_update_contact($c->id, array('next_followup' => null));
        return false;
    }
    if (in_array($c->stage, array('won', 'lost', 'call', 'proposal'), true)) { $upd(array('status' => 'stopped')); return false; }

    $steps = $seq->steps_arr;
    $i = (int) $en->current_step;
    if (!isset($steps[$i])) {
        $upd(array('status' => 'completed'));
        fwcrm_update_contact($c->id, array('next_followup' => null));
        fwcrm_event($c->id, 'sequence_done', array('sequence' => $seq->name));
        return false;
    }
    $step = $steps[$i];
    $subject = trim((string) $step['subject']);
    // A step with its own subject starts a fresh thread; an empty subject replies in the same thread.
    $in_reply = $subject === '' ? $en->thread_message_id : '';
    $refs = '';
    if ($in_reply) {
        $root = $wpdb->get_var($wpdb->prepare("SELECT thread_root FROM " . fwcrm_t('emails') . " WHERE message_id = %s LIMIT 1", $in_reply));
        if ($root && $root !== $in_reply) $refs = $root;
        if ($subject === '') $subject = 'Re: ' . fwcrm_strip_re($en->thread_subject ? $en->thread_subject : 'Quick question');
    } elseif ($subject === '') {
        $subject = 'Quick question about {{company|your website}}';
    }

    $res = fwcrm_send_email($c->id, array(
        'subject' => $subject,
        'body' => $step['body'],
        'sequence_id' => $seq->id,
        'step' => $i + 1,
        'in_reply_to' => $in_reply,
        'references' => $refs,
        'kind' => 'followup',
    ));
    if (is_wp_error($res)) {
        // Retry later today; give up after the address is marked bad.
        $upd(array('next_run' => date('Y-m-d H:i:s', current_time('timestamp') + 2 * HOUR_IN_SECONDS)));
        return false;
    }
    $email = $wpdb->get_row($wpdb->prepare("SELECT message_id, subject FROM " . fwcrm_t('emails') . " WHERE id = %d", $res));
    $next_i = $i + 1;
    $data = array(
        'current_step' => $next_i,
        'thread_message_id' => $email->message_id,
        'thread_subject' => ($in_reply && $en->thread_subject) ? $en->thread_subject : fwcrm_strip_re($email->subject),
    );
    if (isset($steps[$next_i])) {
        $delay = max(0.04, (float) $steps[$next_i]['delay_days']);
        $next = fwcrm_next_window_time(current_time('timestamp') + (int) round($delay * DAY_IN_SECONDS) + wp_rand(-1800, 1800));
        $data['next_run'] = date('Y-m-d H:i:s', $next);
        fwcrm_update_contact($c->id, array('next_followup' => $data['next_run']));
    } else {
        $data['status'] = 'completed';
        $data['next_run'] = null;
        fwcrm_update_contact($c->id, array('next_followup' => null));
        fwcrm_event($c->id, 'sequence_done', array('sequence' => $seq->name));
    }
    $upd($data);
    return true;
}

/** Leads whose follow-up is due and who are not in an automatic sequence. */
function fwcrm_followups_due($limit = 50) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT c.* FROM " . fwcrm_t('contacts') . " c
         WHERE c.next_followup IS NOT NULL AND c.next_followup <= %s AND c.unsubscribed = 0 AND c.bounced = 0
         AND c.stage NOT IN ('won','lost')
         AND NOT EXISTS (SELECT 1 FROM " . fwcrm_t('enrollments') . " e WHERE e.contact_id = c.id AND e.status = 'active')
         ORDER BY c.next_followup ASC LIMIT %d",
        date('Y-m-d 23:59:59', current_time('timestamp')), $limit
    ));
}
