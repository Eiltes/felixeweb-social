<?php
/**
 * Growth layer: "What gets replies" insights + one-tap updates from GitHub.
 */
if (!defined('ABSPATH')) exit;

/* =========================================================
 * Insights
 * ======================================================= */

function fwcrm_problem_buckets() {
    return array(
        'payments' => array('Payments & checkout', '/pay|checkout|crypto|zelle|venmo|cash ?app|bank|payid|paypal|card|invoice|wallet|usdc|bitcoin|\$0\.00/i'),
        'coa'      => array('COA & lab results', '/\bcoa\b|certificate|lab result|purity|third.?party|test(ing|ed)? (data|report)|janoshik/i'),
        'broken'   => array('Broken pages & bugs', '/broken|404|loading|placeholder|template|lorem|error|empty|wrong|dead|not working|goes nowhere|blank|expired|countdown|missing price/i'),
        'trust'    => array('Trust & legal pages', '/terms|privacy|refund|shipping (page|policy)|age.?gate|research.?use|disclaimer|policy|about page|contact (page|details)/i'),
        'security' => array('Security, SEO & domain', '/hack|spam|casino|https|ssl|seo|page title|meta|subdomain|myshopify|wixsite|verification tag/i'),
        'ordering' => array('Ordering by DM / WhatsApp', '/whatsapp|telegram|instagram dm|\bdm\b|text (us|to order)|message (us|to order)/i'),
    );
}

function fwcrm_bucket_of($problem) {
    $p = (string) $problem;
    if (trim($p) === '') return 'other';
    $first = preg_split('/;\s+|\n/', $p)[0];
    foreach (fwcrm_problem_buckets() as $k => $b) if (preg_match($b[1], $first)) return $k;
    return 'other';
}

function fwcrm_norm_country($c) {
    $c = trim($c);
    $u = strtoupper($c);
    $us = array('AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY','DC');
    $us_names = '/^(alabama|alaska|arizona|arkansas|california|colorado|connecticut|delaware|florida|georgia|hawaii|idaho|illinois|indiana|iowa|kansas|kentucky|louisiana|maine|maryland|massachusetts|michigan|minnesota|mississippi|missouri|montana|nebraska|nevada|new hampshire|new jersey|new mexico|new york|north carolina|north dakota|ohio|oklahoma|oregon|pennsylvania|rhode island|south carolina|south dakota|tennessee|texas|utah|vermont|virginia|washington|west virginia|wisconsin|wyoming)$/i';
    if (in_array($u, array('US', 'USA', 'U.S.', 'U.S.A.', 'UNITED STATES', 'UNITED STATES OF AMERICA'), true) || in_array($u, $us, true) || preg_match($us_names, $c)) return 'USA';
    if (in_array($u, array('UK', 'U.K.', 'UNITED KINGDOM', 'ENGLAND', 'SCOTLAND', 'WALES', 'GB', 'GREAT BRITAIN', 'NORTHERN IRELAND'), true)) return 'UK';
    if (in_array($u, array('AU', 'AUSTRALIA', 'NSW', 'VIC', 'QLD', 'WA', 'SA', 'TAS', 'ACT', 'NT'), true)) return 'Australia';
    if (in_array($u, array('NZ', 'NEW ZEALAND'), true)) return 'New Zealand';
    if (in_array($u, array('IE', 'IRELAND'), true)) return 'Ireland';
    if (in_array($u, array('CA', 'CANADA'), true)) return 'Canada';
    return $c;
}

function fwcrm_insights() {
    global $wpdb;
    $T = 'fwcrm_t';
    $rows = $wpdb->get_results("SELECT id, problems, country, stage, last_reply, last_contacted, notes, bounced FROM {$T('contacts')} WHERE last_contacted IS NOT NULL");
    $subj = array();
    foreach ($wpdb->get_results("SELECT contact_id, subject FROM {$T('emails')} WHERE direction = 'out' AND kind = 'email' AND subject NOT LIKE 'Re:%' AND subject <> '' ORDER BY sent_at ASC") as $e) if (!isset($subj[$e->contact_id])) $subj[$e->contact_id] = strtolower(trim($e->subject));
    $by = array('problem' => array(), 'country' => array(), 'run' => array(), 'subject' => array());
    $good = array('call', 'proposal', 'won');
    foreach ($rows as $r) {
        if ($r->bounced) continue;
        $replied = !empty($r->last_reply) ? 1 : 0;
        $warm = $replied && $r->stage !== 'lost' ? 1 : 0;
        $won = in_array($r->stage, $good, true) ? 1 : 0;
        $bits = array_map('trim', explode(',', (string) $r->country));
        $country = end($bits) ?: 'Unknown';
        if (strlen($country) > 30 || preg_match('/batch|run|email|sent|draft|\d/i', $country)) $country = 'Unknown';
        $country = fwcrm_norm_country($country);
        $run = preg_match('/\b(morning|afternoon|evening)\b/i', (string) $r->notes, $m) ? ucfirst(strtolower($m[1])) . ' run' : 'Other';
        $keys = array('problem' => fwcrm_bucket_of($r->problems), 'country' => $country, 'run' => $run);
        if (isset($subj[$r->id])) {
            $s = $subj[$r->id];
            $word = preg_match('/pay|checkout|bank|crypto|zelle|payid/', $s) ? 'Payment subject' : (preg_match('/coa|lab|purity|test/', $s) ? 'COA subject' : (preg_match('/whatsapp|dm|telegram/', $s) ? 'WhatsApp / DM subject' : 'Other subject'));
            $keys['subject'] = $word;
        }
        foreach ($keys as $dim => $k) {
            if (!isset($by[$dim][$k])) $by[$dim][$k] = array('sent' => 0, 'replied' => 0, 'warm' => 0, 'won' => 0);
            $by[$dim][$k]['sent']++;
            $by[$dim][$k]['replied'] += $replied;
            $by[$dim][$k]['warm'] += $warm;
            $by[$dim][$k]['won'] += $won;
        }
    }
    foreach ($by as &$d) uasort($d, function ($a, $b) { return $b['sent'] - $a['sent']; });
    return $by;
}

function fwcrm_render_insights() {
    $by = fwcrm_insights();
    $labels = array();
    foreach (fwcrm_problem_buckets() as $k => $b) $labels[$k] = $b[0];
    $labels['other'] = 'Other / not recorded';
    $total = array_sum(wp_list_pluck($by['problem'], 'sent'));
    echo '<div class="fw-card fw-insights"><div class="fw-card-h"><h2>What gets replies</h2><span class="fw-dim">' . (int) $total . ' leads emailed · bounces left out</span></div>';
    if (!$total) { echo '<div class="fw-empty">Appears once leads have been emailed.</div></div>'; return; }
    $best = null;
    foreach ($by['problem'] as $k => $v) if ($k !== 'other' && $v['sent'] >= 8 && (!$best || $v['replied'] / $v['sent'] > $best[1])) $best = array($k, $v['replied'] / $v['sent']);
    if ($best) echo '<p class="fw-ins-tip">💡 Leads emailed about <b>' . esc_html($labels[$best[0]]) . '</b> reply most (' . round($best[1] * 100) . '%). Lean the scout toward stores with that problem.</p>';
    echo '<div class="fw-ins-grid">';
    $dims = array('problem' => 'By the problem we led with', 'country' => 'By country', 'subject' => 'By subject line', 'run' => 'By scout run');
    foreach ($dims as $dim => $title) {
        if (empty($by[$dim])) continue;
        $max = 0;
        foreach ($by[$dim] as $v) $max = max($max, $v['sent'] ? $v['replied'] / $v['sent'] : 0);
        echo '<div class="fw-ins"><h3>' . esc_html($title) . '</h3>';
        $i = 0;
        foreach ($by[$dim] as $k => $v) {
            if (++$i > 7) break;
            $rate = $v['sent'] ? $v['replied'] / $v['sent'] : 0;
            $name = $dim === 'problem' ? (isset($labels[$k]) ? $labels[$k] : $k) : $k;
            echo '<div class="fw-ins-row"><div class="fw-ins-l"><b>' . esc_html($name) . '</b><small>' . (int) $v['replied'] . ' of ' . (int) $v['sent'] . ' replied' . ($v['won'] ? ' · ' . (int) $v['won'] . ' call/won' : '') . '</small></div><div class="fw-ins-bar"><i style="width:' . ($max ? round($rate / $max * 100) : 0) . '%"></i></div><em>' . round($rate * 100) . '%</em></div>';
        }
        echo '</div>';
    }
    echo '</div><p class="fw-dim" style="margin-top:12px">Small numbers swing a lot. Trust a pattern once a row has 20+ leads.</p></div>';
}

/** Monday push: last week in one line. */
add_action('fwcrm_daily', function () {
    if ((int) current_time('N') !== 1 || !function_exists('fwcrm_push')) return;
    if (get_option('fwcrm_weekly_sent') === current_time('Y-m-d')) return;
    update_option('fwcrm_weekly_sent', current_time('Y-m-d'), false);
    global $wpdb;
    $since = date('Y-m-d H:i:s', current_time('timestamp') - 7 * DAY_IN_SECONDS);
    $sent = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction = 'out' AND status = 'sent' AND sent_at >= %s", $since));
    $rep = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction = 'in' AND kind = 'reply' AND sent_at >= %s", $since));
    $calls = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('events') . " WHERE type = 'booked' AND created >= %s", $since));
    fwcrm_push('📊 Last week', sprintf('%d emails sent · %d replies · %d calls booked. Open Stats to see what got replies.', $sent, $rep, $calls), fwcrm_admin_url('fwcrm-stats'), 'bar_chart');
});

/* =========================================================
 * Updates from GitHub (shows in WordPress → Updates)
 * ======================================================= */

define('FWCRM_UPDATE_URL', 'https://raw.githubusercontent.com/Eiltes/felixeweb-social/main/crm/version.json');
define('FWCRM_UPDATE_ALLOWED', 'https://raw.githubusercontent.com/Eiltes/felixeweb-social/');

function fwcrm_remote_version($force = false) {
    $c = get_site_transient('fwcrm_remote_version');
    if ($c !== false && !$force) return $c;
    $r = wp_remote_get(FWCRM_UPDATE_URL . '?t=' . time(), array('timeout' => 15, 'headers' => array('Cache-Control' => 'no-cache')));
    $data = (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) ? json_decode(trim(wp_remote_retrieve_body($r)), true) : null;
    update_option('fwcrm_update_last', array('at' => fwcrm_now(), 'msg' => is_wp_error($r) ? $r->get_error_message() : ('HTTP ' . wp_remote_retrieve_response_code($r) . (is_array($data) && !empty($data['version']) ? ', latest ' . $data['version'] : ', unreadable'))), false);
    if (!is_array($data) || empty($data['version']) || empty($data['zip']) || strpos($data['zip'], FWCRM_UPDATE_ALLOWED) !== 0) $data = array();
    set_site_transient('fwcrm_remote_version', $data, HOUR_IN_SECONDS);
    return $data;
}

add_filter('pre_set_site_transient_update_plugins', function ($t) {
    if (!is_object($t)) return $t;
    $v = fwcrm_remote_version(!empty($_GET['force-check']));
    $file = plugin_basename(FWCRM_FILE);
    if ($v && version_compare($v['version'], FWCRM_VERSION, '>')) {
        $t->response[$file] = (object) array('slug' => 'felixeweb-crm', 'plugin' => $file, 'new_version' => $v['version'], 'package' => $v['zip'], 'url' => 'https://felixeweb.com', 'icons' => array('1x' => FWCRM_URL . 'assets/icon-192.png'));
    } else {
        unset($t->response[$file]);
        $t->no_update[$file] = (object) array('slug' => 'felixeweb-crm', 'plugin' => $file, 'new_version' => FWCRM_VERSION, 'package' => '', 'url' => 'https://felixeweb.com');
    }
    return $t;
});

/** Refuse a package whose checksum does not match version.json. */
add_filter('upgrader_pre_download', function ($reply, $package) {
    if (strpos((string) $package, FWCRM_UPDATE_ALLOWED) !== 0) return $reply;
    $v = fwcrm_remote_version(true);
    if (empty($v['sha256']) || $v['zip'] !== $package) return new WP_Error('fwcrm_update', 'Update details changed; try again.');
    $tmp = download_url($package, 120);
    if (is_wp_error($tmp)) return $tmp;
    if (!hash_equals(strtolower($v['sha256']), hash_file('sha256', $tmp))) { @unlink($tmp); return new WP_Error('fwcrm_update', 'Update file failed its safety check, so it was not installed.'); }
    return $tmp;
}, 10, 2);

add_filter('plugins_api', function ($res, $action, $args) {
    if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== 'felixeweb-crm') return $res;
    $v = fwcrm_remote_version();
    return (object) array('name' => 'FelixeWeb Hub (CRM)', 'slug' => 'felixeweb-crm', 'version' => isset($v['version']) ? $v['version'] : FWCRM_VERSION, 'author' => 'FelixeWeb', 'sections' => array('changelog' => '<p>' . esc_html(isset($v['notes']) ? $v['notes'] : '') . '</p>'));
}, 10, 3);

function fwcrm_update_banner() {
    if (!current_user_can('update_plugins')) return '';
    $v = fwcrm_remote_version();
    if (!$v || !version_compare($v['version'], FWCRM_VERSION, '>')) return '';
    $url = wp_nonce_url(admin_url('admin-post.php?action=fwcrm_self_update'), 'fwcrm_self_update');
    return '<div class="fw-update"><span>✨ Hub update ' . esc_html($v['version']) . ' is ready' . (!empty($v['notes']) ? ': ' . esc_html(wp_html_excerpt($v['notes'], 90, '…')) : '') . '</span><a class="fw-btn sm gold" href="' . esc_url($url) . '">Install now</a></div>';
}

add_action('upgrader_process_complete', function ($up, $opts) {
    delete_site_transient('fwcrm_remote_version');
}, 10, 2);

/** One-tap install of the latest Hub (checksum-verified by upgrader_pre_download). */
add_action('admin_post_fwcrm_self_update', function () {
    if (!current_user_can('update_plugins') || !check_admin_referer('fwcrm_self_update')) wp_die('Not allowed');
    $v = fwcrm_remote_version(true);
    if (!$v || !version_compare($v['version'], FWCRM_VERSION, '>')) {
        $last = get_option('fwcrm_update_last', array());
        wp_safe_redirect(fwcrm_admin_url('fwcrm-settings', array('fwmsg' => 'You have the latest Hub (' . FWCRM_VERSION . '). Check: ' . (isset($last['msg']) ? $last['msg'] : '')))); exit;
    }
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $up = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
    $res = $up->install($v['zip'], array('overwrite_package' => true));
    $file = plugin_basename(FWCRM_FILE);
    if (!is_plugin_active($file)) activate_plugin($file, '', false, true);
    delete_site_transient('fwcrm_remote_version');
    $err = is_wp_error($res) ? $res->get_error_message() : ($res ? '' : implode(' ', (array) $up->skin->get_upgrade_messages()));
    wp_safe_redirect(fwcrm_admin_url('fwcrm-settings', $err ? array('fwmsg' => 'Update failed: ' . wp_html_excerpt($err, 200, '…'), 'fwerr' => 1) : array('fwmsg' => 'Hub updated to ' . $v['version'] . '.')));
    exit;
});

function fwcrm_update_card() {
    $v = fwcrm_remote_version(isset($_GET['fwcheck']));
    $last = get_option('fwcrm_update_last', array());
    $newer = $v && version_compare($v['version'], FWCRM_VERSION, '>');
    $o = '<div class="fw-card" id="updates"><h2>Hub updates</h2><p class="fw-dim">You have version <b>' . esc_html(FWCRM_VERSION) . '</b>. ' . ($newer ? 'Version <b>' . esc_html($v['version']) . '</b> is ready' . (!empty($v['notes']) ? ': ' . esc_html($v['notes']) : '') : 'This is the latest.') . '</p>';
    $o .= '<div class="fw-btnrow"><span class="fw-dim">' . (!empty($last['at']) ? 'Last checked ' . esc_html(fwcrm_time_ago($last['at'])) . ' (' . esc_html($last['msg']) . ')' : '') . '</span>';
    $o .= '<a class="fw-btn" href="' . esc_url(fwcrm_admin_url('fwcrm-settings', array('fwcheck' => 1))) . '#updates">Check now</a>';
    if ($newer) $o .= '<a class="fw-btn gold" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=fwcrm_self_update'), 'fwcrm_self_update')) . '">Install ' . esc_html($v['version']) . '</a>';
    return $o . '</div></div>';
}
