<?php
if (!defined('ABSPATH')) exit;

/** Table name helper. */
function fwcrm_t($name) {
    global $wpdb;
    return $wpdb->prefix . 'fwcrm_' . $name;
}

function fwcrm_defaults() {
    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    return array(
        'from_name'          => 'Felix | FelixeWeb',
        'from_email'         => 'hello@' . preg_replace('/^www\./', '', $host),
        'reply_to'           => '',
        'smtp_host'          => 'smtp.hostinger.com',
        'smtp_port'          => 465,
        'smtp_secure'        => 'ssl',
        'imap_host'          => 'imap.hostinger.com',
        'imap_port'          => 993,
        'mail_user'          => 'hello@' . preg_replace('/^www\./', '', $host),
        'mail_pass'          => '',
        'sent_folder'        => '',
        'save_to_sent'       => 1,
        'import_sent'        => 1,
        'import_days'        => 30,
        'ignore_domains'     => '',
        'daily_cap'          => 30,
        'min_gap_minutes'    => 4,
        'window_start'       => 9,
        'window_end'         => 18,
        'workdays'           => array(1, 2, 3, 4, 5),
        'followup_days'      => 3,
        'auto_enroll_seq'    => 0,
        'track_opens'        => 1,
        'track_clicks'       => 1,
        'unsub_footer'       => 0,
        'unsub_text'         => "If this isn't relevant, just reply \"no thanks\" and I won't follow up.",
        'signature'          => "Felix\nFelixeWeb · Stores that sell, live in 7–10 days\nhttps://felixeweb.com",
        'notify_email'       => get_option('admin_email'),
        'notify_reply'       => 1,
        'notify_hot_visit'   => 1,
        'daily_digest'       => 1,
        'track_visitors'     => 1,
        'track_admins'       => 0,
        'visit_retention_days' => 180,
        'hot_pages'          => "#services\n/contact\n/pricing",
        'gmail_enabled'      => 0,
        'gmail_user'         => '',
        'gmail_pass'         => '',
        'gmail_from_filter'  => 'hello@' . preg_replace('/^www\./', '', $host),
        'gmail_import_days'  => 30,
        'hub_mode'           => 'hub',
        'remote_hub_url'     => '',
        'allowed_origins'    => '',
        'windsor_key'        => '',
        'windsor_threads_id' => '',
        'windsor_instagram_id' => '',
        'schedule_url'       => '',
        'ai_key'             => '',
        'ai_model'           => 'claude-sonnet-5-5',
        'ai_about'           => fwcrm_default_about(),
        'website_url'        => 'https://felixeweb.com',
        'app_frontpage'      => 0,
        'app_mode'           => 1,
        'api_key'            => '',
    );
}

function fwcrm_default_about() {
    return "I'm Felix Ojo, founder of FelixeWeb (felixeweb.com), a solo web designer and developer based in Nigeria working with clients worldwide.\n"
        . "What I sell: WordPress & WooCommerce stores that go live in 7–10 days (from $450), business websites (from $300), research peptide stores (from $600), landing pages/redesigns (from $150), mobile & web app development (custom quote), interactive digital invitations.\n"
        . "Main niche: research peptide brands. My strongest offer is fixing payments: card processors refuse peptide sellers, so I build a manual-payment checkout (Zelle, Cash App, Venmo, PayPal, bank transfer, USDC) with copy buttons, proof-of-payment upload and orders held until confirmed. I also build COA/lab-result pages, research-use/age gates, legal pages, fast mobile product pages, and fix broken or hacked stores.\n"
        . "Proof: 50+ websites launched, 65+ reviews on Fiverr. Portfolio includes MedWell Plus, MedWell Research Labs, LABRATZ Peptides, Velvet Lenz, Citadel Labs, Lean Labs, ElevateLabs, Dermys Lab's, Peptides Por Favor, Renova Synergy, Zentrax Wellness, Zellner Peptides.\n"
        . "Booking link for calls: https://calendar.app.google/zokGimp6miS6uLni7 (30 min, Mon–Fri 2–9pm Lagos).\n"
        . "Outreach: automated cold-email scouting of peptide stores (USA, UK/EU, Australia/NZ) sent from hello@felixeweb.com, with follow-ups on day 5 and day 12. Leads who ask get a short demo video with my voice-over.\n"
        . "Social: @felixeweb on Instagram, Threads and Behance; brand is black & deep gold, Montserrat; daily post at 3pm Lagos that I approve first.\n"
        . "How I write: short, plain, friendly, about the client's problem not about me, no hype words, no exclamation marks in cold emails, never invent results or client names.";
}

function fwcrm_settings() {
    if (!isset($GLOBALS['fwcrm_settings_cache'])) {
        $saved = get_option('fwcrm_settings', array());
        $GLOBALS['fwcrm_settings_cache'] = wp_parse_args(is_array($saved) ? $saved : array(), fwcrm_defaults());
    }
    return $GLOBALS['fwcrm_settings_cache'];
}

function fwcrm_opt($key, $default = null) {
    $s = fwcrm_settings();
    return array_key_exists($key, $s) ? $s[$key] : $default;
}

function fwcrm_save_settings($new) {
    $merged = wp_parse_args($new, fwcrm_settings());
    update_option('fwcrm_settings', $merged, false);
    $GLOBALS['fwcrm_settings_cache'] = $merged;
}

/** Encrypt / decrypt the mailbox password with the site's secret keys. */
function fwcrm_key() {
    $k = (defined('AUTH_KEY') ? AUTH_KEY : '') . (defined('SECURE_AUTH_SALT') ? SECURE_AUTH_SALT : '') . 'fwcrm';
    return hash('sha256', $k, true);
}
function fwcrm_encrypt($plain) {
    if ($plain === '') return '';
    $iv = random_bytes(16);
    $c = openssl_encrypt($plain, 'aes-256-cbc', fwcrm_key(), OPENSSL_RAW_DATA, $iv);
    return 'enc:' . base64_encode($iv . $c);
}
function fwcrm_decrypt($stored) {
    if (strpos((string) $stored, 'enc:') !== 0) return (string) $stored;
    $raw = base64_decode(substr($stored, 4));
    $iv = substr($raw, 0, 16);
    $c = substr($raw, 16);
    $p = openssl_decrypt($c, 'aes-256-cbc', fwcrm_key(), OPENSSL_RAW_DATA, $iv);
    return $p === false ? '' : $p;
}
function fwcrm_mail_pass() {
    return fwcrm_decrypt(fwcrm_opt('mail_pass', ''));
}
function fwcrm_mailbox_ready() {
    return fwcrm_opt('mail_user') && fwcrm_mail_pass() !== '';
}
function fwcrm_gmail_ready() {
    return fwcrm_opt('gmail_enabled') && fwcrm_opt('gmail_user') && fwcrm_decrypt(fwcrm_opt('gmail_pass', '')) !== '';
}

/** Mailboxes to sync. 'main' = Hostinger hello@ (send + sync); 'gmail' = Gmail used by the scout tasks (sync only). */
function fwcrm_mail_accounts() {
    $out = array();
    if (fwcrm_mailbox_ready()) {
        $out[] = array('key' => 'main', 'label' => fwcrm_opt('mail_user'), 'host' => fwcrm_opt('imap_host'), 'port' => fwcrm_opt('imap_port'), 'user' => fwcrm_opt('mail_user'), 'pass' => fwcrm_mail_pass(), 'sent_folder' => fwcrm_opt('sent_folder'), 'from_filter' => '', 'create_inbound' => true, 'schedule_followups' => true, 'source' => 'webmail', 'days' => (int) fwcrm_opt('import_days', 30));
    }
    if (fwcrm_gmail_ready()) {
        $out[] = array('key' => 'gmail', 'label' => fwcrm_opt('gmail_user'), 'host' => defined('FWCRM_GMAIL_HOST') ? FWCRM_GMAIL_HOST : 'imap.gmail.com', 'port' => defined('FWCRM_GMAIL_PORT') ? FWCRM_GMAIL_PORT : 993, 'user' => fwcrm_opt('gmail_user'), 'pass' => fwcrm_decrypt(fwcrm_opt('gmail_pass')), 'sent_folder' => '', 'from_filter' => strtolower(trim(fwcrm_opt('gmail_from_filter'))), 'create_inbound' => false, 'schedule_followups' => false, 'source' => 'scout', 'days' => (int) fwcrm_opt('gmail_import_days', 30));
    }
    return $out;
}

function fwcrm_log($msg) {
    $log = get_option('fwcrm_log', array());
    if (!is_array($log)) $log = array();
    array_unshift($log, current_time('mysql') . '  ' . $msg);
    update_option('fwcrm_log', array_slice($log, 0, 80), false);
}

function fwcrm_token($len = 20) {
    return strtolower(wp_generate_password($len, false, false));
}

function fwcrm_now() {
    return current_time('mysql');
}

function fwcrm_stages() {
    return array(
        'new'        => 'New lead',
        'contacted'  => 'Contacted',
        'opened'     => 'Opened',
        'replied'    => 'Replied',
        'call'       => 'Call booked',
        'proposal'   => 'Proposal sent',
        'won'        => 'Won',
        'lost'       => 'Lost',
    );
}

/** Stage order, used so automatic updates only move a lead forward. */
function fwcrm_stage_rank($stage) {
    $order = array_keys(fwcrm_stages());
    $i = array_search($stage, $order, true);
    return $i === false ? 0 : $i;
}

function fwcrm_clean_email($e) {
    $e = strtolower(trim((string) $e));
    if (preg_match('/<([^>]+)>/', $e, $m)) $e = $m[1];
    return is_email($e) ? $e : '';
}

/** Fill {{first_name}}, {{company|your brand}} style variables. */
function fwcrm_merge($text, $contact) {
    $c = (array) $contact;
    $vars = array(
        'first_name' => isset($c['first_name']) ? $c['first_name'] : '',
        'last_name'  => isset($c['last_name']) ? $c['last_name'] : '',
        'name'       => trim((isset($c['first_name']) ? $c['first_name'] : '') . ' ' . (isset($c['last_name']) ? $c['last_name'] : '')),
        'company'    => isset($c['company']) ? $c['company'] : '',
        'website'    => isset($c['website']) ? $c['website'] : '',
        'email'      => isset($c['email']) ? $c['email'] : '',
        'sender_name'=> preg_replace('/\s*\|.*$/', '', fwcrm_opt('from_name')),
    );
    return preg_replace_callback('/\{\{\s*([a-z_]+)\s*(?:\|([^}]*))?\}\}/i', function ($m) use ($vars) {
        $k = strtolower($m[1]);
        $v = isset($vars[$k]) ? trim($vars[$k]) : '';
        return $v !== '' ? $v : (isset($m[2]) ? $m[2] : '');
    }, (string) $text);
}

function fwcrm_time_ago($mysql) {
    if (!$mysql || $mysql === '0000-00-00 00:00:00') return '—';
    $t = strtotime($mysql);
    $diff = current_time('timestamp') - $t;
    if ($diff < 0) return 'in ' . human_time_diff(current_time('timestamp'), $t);
    if ($diff < 60) return 'just now';
    return human_time_diff($t, current_time('timestamp')) . ' ago';
}

function fwcrm_contact_name($c) {
    $c = (object) $c;
    $n = trim($c->first_name . ' ' . $c->last_name);
    return $n !== '' ? $n : $c->email;
}

function fwcrm_admin_url($page, $args = array()) {
    return add_query_arg(array_merge(array('page' => $page), $args), admin_url('admin.php'));
}
