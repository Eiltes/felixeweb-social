<?php
if (!defined('ABSPATH')) exit;

/** Table name helper. */
function fwcrm_t($name) {
    global $wpdb;
    return $wpdb->prefix . 'fwcrm_' . $name;
}

function fwcrm_defaults() {
    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    return array(
        'from_name'          => 'Felix | FelixeWeb',
        'from_email'         => 'hello@' . preg_replace('/^www\./', '', $host),
        'reply_to'           => '',
        'smtp_host'          => 'smtp.hostinger.com',
        'smtp_port'          => 465,
        'smtp_secure'        => 'ssl',
        'imap_host'          => 'imap.hostinger.com',
        'imap_port'          => 993,
        'mail_user'          => 'hello@' . preg_replace('/^www\./', '', $host),
        'mail_pass'          => '',
        'sent_folder'        => '',
        'save_to_sent'       => 1,
        'import_sent'        => 1,
        'import_days'        => 30,
        'ignore_domains'     => '',
        'daily_cap'          => 30,
        'min_gap_minutes'    => 4,
        'window_start'       => 9,
        'window_end'         => 18,
        'workdays'           => array(1, 2, 3, 4, 5),
        'followup_days'      => 3,
        'auto_enroll_seq'    => 0,
        'track_opens'        => 1,
        'track_clicks'       => 1,
        'unsub_footer'       => 0,
        'unsub_text'         => "If this isn't relevant, just reply \"no thanks\" and I won't follow up.",
        'signature'          => "Felix\nFelixeWeb · Stores that sell, live in 7–10 days\nhttps://felixeweb.com",
        'notify_email'       => get_option('admin_email'),
        'notify_reply'       => 1,
        'notify_hot_visit'   => 1,
        'daily_digest'       => 1,
        'track_visitors'     => 1,
        'track_admins'       => 0,
        'visit_retention_days' => 180,
        'hot_pages'          => "#services\n/contact\n/pricing",
    );
}

function fwcrm_settings() {
    if (!isset($GLOBALS['fwcrm_settings_cache'])) {
        $saved = get_option('fwcrm_settings', array());
        $GLOBALS['fwcrm_settings_cache'] = wp_parse_args(is_array($saved) ? $saved : array(), fwcrm_defaults());
    }
    return $GLOBALS['fwcrm_settings_cache'];
}

function fwcrm_opt($key, $default = null) {
    $s = fwcrm_settings();
    return array_key_exists($key, $s) ? $s[$key] : $default;
}

function fwcrm_save_settings($new) {
    $merged = wp_parse_args($new, fwcrm_settings());
    update_option('fwcrm_settings', $merged, false);
    $GLOBALS['fwcrm_settings_cache'] = $merged;
}

/** Encrypt / decrypt the mailbox password with the site's secret keys. */
function fwcrm_key() {
    $k = (defined('AUTH_KEY') ? AUTH_KEY : '') . (defined('SECURE_AUTH_SALT') ? SECURE_AUTH_SALT : '') . 'fwcrm';
    return hash('sha256', $k, true);
}
function fwcrm_encrypt($plain) {
    if ($plain === '') return '';
    $iv = random_bytes(16);
    $c = openssl_encrypt($plain, 'aes-256-cbc', fwcrm_key(), OPENSSL_RAW_DATA, $iv);
    return 'enc:' . base64_encode($iv . $c);
}
function fwcrm_decrypt($stored) {
    if (strpos((string) $stored, 'enc:') !== 0) return (string) $stored;
    $raw = base64_decode(substr($stored, 4));
    $iv = substr($raw, 0, 16);
    $c = substr($raw, 16);
    $p = openssl_decrypt($c, 'aes-256-cbc', fwcrm_key(), OPENSSL_RAW_DATA, $iv);
    return $p === false ? '' : $p;
}
function fwcrm_mail_pass() {
    return fwcrm_decrypt(fwcrm_opt('mail_pass', ''));
}
function fwcrm_mailbox_ready() {
    return fwcrm_opt('mail_user') && fwcrm_mail_pass() !== '';
}

function fwcrm_log($msg) {
    $log = get_option('fwcrm_log', array());
    if (!is_array($log)) $log = array();
    array_unshift($log, current_time('mysql') . '  ' . $msg);
    update_option('fwcrm_log', array_slice($log, 0, 80), false);
}

function fwcrm_token($len = 20) {
    return strtolower(wp_generate_password($len, false, false));
}

function fwcrm_now() {
    return current_time('mysql');
}

function fwcrm_stages() {
    return array(
        'new'        => 'New lead',
        'contacted'  => 'Contacted',
        'opened'     => 'Opened',
        'replied'    => 'Replied',
        'call'       => 'Call booked',
        'proposal'   => 'Proposal sent',
        'won'        => 'Won',
        'lost'       => 'Lost',
    );
}

/** Stage order, used so automatic updates only move a lead forward. */
function fwcrm_stage_rank($stage) {
    $order = array_keys(fwcrm_stages());
    $i = array_search($stage, $order, true);
    return $i === false ? 0 : $i;
}

function fwcrm_clean_email($e) {
    $e = strtolower(trim((string) $e));
    if (preg_match('/<([^>]+)>/', $e, $m)) $e = $m[1];
    return is_email($e) ? $e : '';
}

/** Fill {{first_name}}, {{company|your brand}} style variables. */
function fwcrm_merge($text, $contact) {
    $c = (array) $contact;
    $vars = array(
        'first_name' => isset($c['first_name']) ? $c['first_name'] : '',
        'last_name'  => isset($c['last_name']) ? $c['last_name'] : '',
        'name'       => trim((isset($c['first_name']) ? $c['first_name'] : '') . ' ' . (isset($c['last_name']) ? $c['last_name'] : '')),
        'company'    => isset($c['company']) ? $c['company'] : '',
        'website'    => isset($c['website']) ? $c['website'] : '',
        'email'      => isset($c['email']) ? $c['email'] : '',
        'sender_name'=> preg_replace('/\s*\|.*$/', '', fwcrm_opt('from_name')),
    );
    return preg_replace_callback('/\{\{\s*([a-z_]+)\s*(?:\|([^}]*))?\}\}/i', function ($m) use ($vars) {
        $k = strtolower($m[1]);
        $v = isset($vars[$k]) ? trim($vars[$k]) : '';
        return $v !== '' ? $v : (isset($m[2]) ? $m[2] : '');
    }, (string) $text);
}

function fwcrm_time_ago($mysql) {
    if (!$mysql || $mysql === '0000-00-00 00:00:00') return '—';
    $t = strtotime($mysql);
    $diff = current_time('timestamp') - $t;
    if ($diff < 0) return 'in ' . human_time_diff(current_time('timestamp'), $t);
    if ($diff < 60) return 'just now';
    return human_time_diff($t, current_time('timestamp')) . ' ago';
}

function fwcrm_contact_name($c) {
    $c = (object) $c;
    $n = trim($c->first_name . ' ' . $c->last_name);
    return $n !== '' ? $n : $c->email;
}

function fwcrm_admin_url($page, $args = array()) {
    return add_query_arg(array_merge(array('page' => $page), $args), admin_url('admin.php'));
}
