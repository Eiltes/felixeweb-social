<?php
if (!defined('ABSPATH')) exit;

/* ---------- Windsor.ai data ---------- */

function fwcrm_windsor_get($connector, $fields, $preset = 'last_30d', $account = '') {
    $key = fwcrm_decrypt(fwcrm_opt('windsor_key', ''));
    if (!$key) return new WP_Error('fwcrm', 'Add your Windsor.ai API key in Settings');
    $args = array('api_key' => $key, 'date_preset' => $preset, 'fields' => implode(',', $fields));
    if ($account) $args['select_accounts'] = $connector . '__' . $account;
    $url = 'https://connectors.windsor.ai/' . rawurlencode($connector) . '?' . http_build_query($args);
    $res = wp_remote_get($url, array('timeout' => 60));
    if (is_wp_error($res)) return $res;
    $code = wp_remote_retrieve_response_code($res);
    $body = json_decode(wp_remote_retrieve_body($res), true);
    if ($code >= 400 || !is_array($body)) {
        $msg = is_array($body) && isset($body['error']) ? (is_string($body['error']) ? $body['error'] : wp_json_encode($body['error'])) : ('HTTP ' . $code);
        return new WP_Error('fwcrm', 'Windsor: ' . $msg);
    }
    return isset($body['data']) && is_array($body['data']) ? $body['data'] : array();
}

function fwcrm_social_status($platform, $ok, $msg = '') {
    $st = get_option('fwcrm_social_status', array());
    if (!is_array($st)) $st = array();
    $st[$platform] = array('ok' => $ok ? 1 : 0, 'msg' => $msg, 'at' => fwcrm_now());
    update_option('fwcrm_social_status', $st, false);
}

function fwcrm_store_day($platform, $day, $metrics) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare("SELECT id, metrics FROM " . fwcrm_t('social') . " WHERE platform = %s AND day = %s", $platform, $day));
    if ($row) {
        $old = json_decode($row->metrics, true) ?: array();
        $wpdb->update(fwcrm_t('social'), array('metrics' => wp_json_encode(array_merge($old, $metrics))), array('id' => $row->id));
    } else {
        $wpdb->insert(fwcrm_t('social'), array('platform' => $platform, 'day' => $day, 'metrics' => wp_json_encode($metrics)));
    }
}

function fwcrm_store_post($platform, $p) {
    global $wpdb;
    if (empty($p['post_id'])) return;
    $row = array(
        'platform' => $platform,
        'post_id' => (string) $p['post_id'],
        'posted_at' => !empty($p['posted_at']) ? date('Y-m-d H:i:s', strtotime($p['posted_at']) + (int) (get_option('gmt_offset') * HOUR_IN_SECONDS)) : null,
        'text' => isset($p['text']) ? (string) $p['text'] : '',
        'permalink' => isset($p['permalink']) ? (string) $p['permalink'] : '',
        'thumb' => isset($p['thumb']) ? (string) $p['thumb'] : '',
        'media_type' => isset($p['media_type']) ? (string) $p['media_type'] : '',
        'views' => (int) (isset($p['views']) ? $p['views'] : 0),
        'likes' => (int) (isset($p['likes']) ? $p['likes'] : 0),
        'replies' => (int) (isset($p['replies']) ? $p['replies'] : 0),
        'reposts' => (int) (isset($p['reposts']) ? $p['reposts'] : 0),
        'shares' => (int) (isset($p['shares']) ? $p['shares'] : 0),
        'updated' => fwcrm_now(),
    );
    $id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . fwcrm_t('posts') . " WHERE platform = %s AND post_id = %s", $platform, $row['post_id']));
    if ($id) $wpdb->update(fwcrm_t('posts'), $row, array('id' => $id)); else $wpdb->insert(fwcrm_t('posts'), $row);
}

/** Pull fresh numbers from Windsor (runs daily and on demand). */
function fwcrm_social_refresh() {
    $out = array();
    if (!fwcrm_decrypt(fwcrm_opt('windsor_key', ''))) return array('error' => 'No Windsor key');

    // Threads
    $tid = fwcrm_opt('windsor_threads_id');
    $prof = fwcrm_windsor_get('threads', array('date', 'profile_views', 'profile_likes', 'profile_replies', 'profile_reposts', 'profile_quotes'), 'last_30d', $tid);
    if (is_wp_error($prof)) {
        fwcrm_social_status('threads', false, $prof->get_error_message());
        $out['threads'] = $prof->get_error_message();
    } else {
        foreach ($prof as $r) {
            if (empty($r['date'])) continue;
            fwcrm_store_day('threads', $r['date'], array('views' => (int) $r['profile_views'], 'likes' => (int) $r['profile_likes'], 'replies' => (int) $r['profile_replies'], 'reposts' => (int) $r['profile_reposts']));
        }
        $f = fwcrm_windsor_get('threads', array('profile_followers_count'), 'last_1d', $tid);
        if (!is_wp_error($f) && isset($f[0]['profile_followers_count'])) fwcrm_store_day('threads', current_time('Y-m-d'), array('followers' => (int) $f[0]['profile_followers_count']));
        $posts = fwcrm_windsor_get('threads', array('post_id', 'post_timestamp', 'post_text', 'post_permalink', 'post_media_type', 'post_thumbnail_url', 'post_views', 'post_likes', 'post_replies', 'post_reposts', 'post_shares'), 'last_90d', $tid);
        if (!is_wp_error($posts)) {
            foreach ($posts as $p) fwcrm_store_post('threads', array('post_id' => $p['post_id'], 'posted_at' => $p['post_timestamp'], 'text' => $p['post_text'], 'permalink' => $p['post_permalink'], 'media_type' => $p['post_media_type'], 'thumb' => $p['post_thumbnail_url'], 'views' => $p['post_views'], 'likes' => $p['post_likes'], 'replies' => $p['post_replies'], 'reposts' => $p['post_reposts'], 'shares' => $p['post_shares']));
        }
        fwcrm_social_status('threads', true, 'Updated');
        $out['threads'] = 'ok';
    }

    // Instagram (field names per Windsor's instagram connector)
    $iid = fwcrm_opt('windsor_instagram_id');
    $ins = fwcrm_windsor_get('instagram', array('date', 'reach', 'impressions', 'profile_views', 'follower_count'), 'last_30d', $iid);
    if (is_wp_error($ins)) {
        fwcrm_social_status('instagram', false, $ins->get_error_message());
        $out['instagram'] = $ins->get_error_message();
    } else {
        foreach ($ins as $r) {
            if (empty($r['date'])) continue;
            fwcrm_store_day('instagram', $r['date'], array('reach' => (int) (isset($r['reach']) ? $r['reach'] : 0), 'views' => (int) (isset($r['impressions']) ? $r['impressions'] : 0), 'profile_views' => (int) (isset($r['profile_views']) ? $r['profile_views'] : 0), 'new_followers' => (int) (isset($r['follower_count']) ? $r['follower_count'] : 0)));
        }
        $posts = fwcrm_windsor_get('instagram', array('media_id', 'timestamp', 'media_caption', 'media_permalink', 'media_type', 'media_thumbnail_url', 'media_url', 'media_like_count', 'media_comments_count', 'media_reach'), 'last_90d', $iid);
        if (!is_wp_error($posts)) {
            foreach ($posts as $p) fwcrm_store_post('instagram', array('post_id' => isset($p['media_id']) ? $p['media_id'] : '', 'posted_at' => isset($p['timestamp']) ? $p['timestamp'] : '', 'text' => isset($p['media_caption']) ? $p['media_caption'] : '', 'permalink' => isset($p['media_permalink']) ? $p['media_permalink'] : '', 'media_type' => isset($p['media_type']) ? $p['media_type'] : '', 'thumb' => !empty($p['media_thumbnail_url']) ? $p['media_thumbnail_url'] : (isset($p['media_url']) ? $p['media_url'] : ''), 'views' => isset($p['media_reach']) ? $p['media_reach'] : 0, 'likes' => isset($p['media_like_count']) ? $p['media_like_count'] : 0, 'replies' => isset($p['media_comments_count']) ? $p['media_comments_count'] : 0));
        }
        fwcrm_social_status('instagram', true, 'Updated');
        $out['instagram'] = 'ok';
    }
    update_option('fwcrm_social_last', fwcrm_now(), false);
    return $out;
}

/** The daily-post schedule (schedule.json in the felixeweb-social GitHub repo). */
function fwcrm_post_schedule($force = false) {
    $url = fwcrm_opt('schedule_url');
    if (!$url) return array();
    $cache = get_transient('fwcrm_schedule');
    if ($cache !== false && !$force) return $cache;
    $res = wp_remote_get(add_query_arg('t', time(), $url), array('timeout' => 20));
    if (is_wp_error($res)) return array();
    $j = json_decode(wp_remote_retrieve_body($res), true);
    $posts = isset($j['posts']) && is_array($j['posts']) ? $j['posts'] : array();
    set_transient('fwcrm_schedule', $posts, HOUR_IN_SECONDS);
    return $posts;
}

function fwcrm_social_summary($platform, $days = 30) {
    global $wpdb;
    $from = date('Y-m-d', current_time('timestamp') - $days * DAY_IN_SECONDS);
    $rows = $wpdb->get_results($wpdb->prepare("SELECT day, metrics FROM " . fwcrm_t('social') . " WHERE platform = %s AND day >= %s ORDER BY day ASC", $platform, $from));
    $sum = array('views' => 0, 'likes' => 0, 'replies' => 0, 'reach' => 0, 'profile_views' => 0, 'new_followers' => 0, 'followers' => null, 'series' => array());
    foreach ($rows as $r) {
        $m = json_decode($r->metrics, true) ?: array();
        foreach (array('views', 'likes', 'replies', 'reach', 'profile_views', 'new_followers') as $k) if (isset($m[$k])) $sum[$k] += (int) $m[$k];
        if (isset($m['followers'])) $sum['followers'] = (int) $m['followers'];
        $sum['series'][$r->day] = isset($m['views']) ? (int) $m['views'] : (isset($m['reach']) ? (int) $m['reach'] : 0);
    }
    $sum['posts'] = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('posts') . " WHERE platform = %s AND posted_at >= %s", $platform, $from . ' 00:00:00'));
    return $sum;
}

/* ---------- Page ---------- */

function fwcrm_page_social() {
    global $wpdb;
    $st = get_option('fwcrm_social_status', array());
    $has_key = (bool) fwcrm_decrypt(fwcrm_opt('windsor_key', ''));
    fwcrm_header('Social', 'Your Threads and Instagram in one place, plus what is scheduled to post. Updated daily' . (get_option('fwcrm_social_last') ? ' · last ' . esc_html(fwcrm_time_ago(get_option('fwcrm_social_last'))) : '') . '.', ($has_key ? '<button class="fw-btn" data-fw-ajax="fwcrm_social_refresh">↻ Refresh now</button>' : fwcrm_btn('Connect Windsor.ai', fwcrm_admin_url('fwcrm-settings') . '#social', 'gold')));

    if (!$has_key) echo '<div class="fw-card fw-help"><h2>Connect your social accounts</h2><p class="fw-dim">Your Threads and Instagram are connected to Windsor.ai. Paste your Windsor API key in <a href="' . esc_url(fwcrm_admin_url('fwcrm-settings')) . '">Settings</a> (Windsor → account → API key) and the numbers load here.</p></div>';
    foreach (array('instagram' => 'Instagram', 'threads' => 'Threads') as $p => $label) {
        if (isset($st[$p]) && !$st[$p]['ok']) echo '<div class="fw-toast err">' . esc_html($label) . ': ' . esc_html($st[$p]['msg']) . (stripos($st[$p]['msg'], 'account') !== false || stripos($st[$p]['msg'], 'password') !== false ? ' Reconnect it at onboard.windsor.ai.' : '') . '</div>';
    }

    echo '<div class="fw-grid2">';
    foreach (array('threads' => array('Threads', 'https://www.threads.com/@felixeweb'), 'instagram' => array('Instagram', 'https://www.instagram.com/felixeweb/')) as $p => $d) {
        $s = fwcrm_social_summary($p);
        $max = max(1, $s['series'] ? max($s['series']) : 1);
        echo '<div class="fw-card"><div class="fw-card-h"><h2>' . esc_html($d[0]) . ' <a class="fw-dim" href="' . esc_url($d[1]) . '" target="_blank" rel="noopener">@felixeweb ↗</a></h2>' . (isset($st[$p]) ? '<span class="fw-pill ' . ($st[$p]['ok'] ? 'ok' : 'bad') . '"><i></i>' . ($st[$p]['ok'] ? 'Connected' : 'Needs attention') . '</span>' : '') . '</div>';
        echo '<div class="fw-minikpis"><div><b>' . ($s['followers'] !== null ? (int) $s['followers'] : '—') . '</b><span>followers</span></div><div><b>' . number_format_i18n($p === 'instagram' ? $s['reach'] : $s['views']) . '</b><span>' . ($p === 'instagram' ? 'reach' : 'views') . ' · 30d</span></div><div><b>' . number_format_i18n($s['likes']) . '</b><span>likes · 30d</span></div><div><b>' . (int) $s['posts'] . '</b><span>posts · 30d</span></div></div>';
        echo '<div class="fw-spark">';
        foreach ($s['series'] as $day => $v) echo '<i title="' . esc_attr(date_i18n('j M', strtotime($day)) . ': ' . $v) . '" style="height:' . max(3, round($v / $max * 100)) . '%"></i>';
        if (!$s['series']) echo '<div class="fw-empty sm">No data yet</div>';
        echo '</div></div>';
    }
    echo '</div>';

    // Schedule
    $sched = fwcrm_post_schedule();
    $today = current_time('Y-m-d');
    echo '<div class="fw-grid2"><div class="fw-card"><div class="fw-card-h"><h2>Post schedule</h2><span class="fw-dim">Daily post at 3:00 PM · you approve each one</span></div>';
    if (!$sched) echo '<div class="fw-empty">No schedule found. Set the schedule link in Settings.</div>';
    $upcoming = array_filter($sched, function ($x) use ($today) { return isset($x['date']) && $x['date'] >= date('Y-m-d', strtotime($today . ' -3 days')); });
    usort($upcoming, function ($a, $b) { return strcmp($a['date'], $b['date']); });
    foreach (array_slice($upcoming, 0, 10) as $x) {
        $status = isset($x['status']) ? $x['status'] : '';
        $img = !empty($x['images'][0]) ? $x['images'][0] : '';
        echo '<div class="fw-item">' . ($img ? '<img class="fw-thumb" src="' . esc_url($img) . '" alt="" loading="lazy">' : '<div class="fw-thumb"></div>') . '<div class="fw-it"><b>' . esc_html(date_i18n('D j M', strtotime($x['date']))) . ($x['date'] === $today ? ' <em>· today</em>' : '') . '</b><span>' . esc_html(isset($x['title']) ? $x['title'] : wp_html_excerpt(isset($x['caption']) ? $x['caption'] : '', 70, '…')) . '</span><small>' . esc_html(ucfirst(isset($x['type']) ? $x['type'] : '')) . (isset($x['note']) && $x['note'] ? ' · ' . esc_html($x['note']) : '') . '</small></div><span class="fw-stage s-' . ($status === 'ready' ? 'replied' : ($status === 'needs_input' ? 'opened' : 'new')) . '">' . esc_html(str_replace('_', ' ', $status)) . '</span></div>';
    }
    echo '</div>';

    // Top posts
    $top = $wpdb->get_results("SELECT * FROM " . fwcrm_t('posts') . " ORDER BY posted_at DESC LIMIT 12");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Recent posts</h2></div>';
    if (!$top) echo '<div class="fw-empty">Posts appear here after the first refresh.</div>';
    foreach ($top as $p) {
        echo '<a class="fw-item" href="' . esc_url($p->permalink ?: '#') . '" target="_blank" rel="noopener">' . ($p->thumb ? '<img class="fw-thumb" src="' . esc_url($p->thumb) . '" alt="" loading="lazy">' : '<div class="fw-thumb fw-thumb-t">' . esc_html(strtoupper(substr($p->platform, 0, 1))) . '</div>') . '<div class="fw-it"><b>' . esc_html(ucfirst($p->platform)) . ' <em>· ' . esc_html(fwcrm_time_ago($p->posted_at)) . '</em></b><small>' . esc_html(wp_html_excerpt(str_replace("\n", ' ', $p->text), 110, '…')) . '</small></div><div class="fw-pstats"><span>👁 ' . number_format_i18n($p->views) . '</span><span>♥ ' . number_format_i18n($p->likes) . '</span><span>💬 ' . number_format_i18n($p->replies) . '</span></div></a>';
    }
    echo '</div></div>';

    echo '<div class="fw-card"><h2>Other profiles</h2><div class="fw-btnrow">' . fwcrm_btn('Behance ↗', 'https://www.behance.net/felixeweb') . fwcrm_btn('Fiverr ↗', 'https://www.fiverr.com/s/odWybEX') . fwcrm_btn('Website ↗', fwcrm_opt('website_url', 'https://felixeweb.com')) . '</div></div>';
    fwcrm_footer();
}
