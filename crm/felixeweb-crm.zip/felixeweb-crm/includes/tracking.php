<?php
if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    register_rest_route('fwcrm/v1', '/o/(?P<t>[a-z0-9]+)', array('methods' => 'GET', 'callback' => 'fwcrm_rest_open', 'permission_callback' => '__return_true'));
    register_rest_route('fwcrm/v1', '/c/(?P<t>[a-z0-9]+)', array('methods' => 'GET', 'callback' => 'fwcrm_rest_click', 'permission_callback' => '__return_true'));
    register_rest_route('fwcrm/v1', '/u/(?P<t>[a-z0-9]+)', array('methods' => array('GET', 'POST'), 'callback' => 'fwcrm_rest_unsub', 'permission_callback' => '__return_true'));
    register_rest_route('fwcrm/v1', '/v', array('methods' => 'POST', 'callback' => 'fwcrm_rest_visit', 'permission_callback' => '__return_true'));
});

function fwcrm_is_bot($ua = null) {
    $ua = $ua === null ? (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '') : $ua;
    if ($ua === '') return true;
    return (bool) preg_match('/bot|crawl|spider|slurp|preview|facebookexternalhit|headless|lighthouse|pingdom|uptime|monitor|curl|wget|python|axios|go-http|scanner|proofpoint|mimecast|barracuda|bingpreview|google-read-aloud/i', $ua);
}

function fwcrm_email_by_token($t) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('emails') . " WHERE token = %s LIMIT 1", $t));
}

function fwcrm_nocache_headers() {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
}

function fwcrm_rest_open($req) {
    global $wpdb;
    $e = fwcrm_email_by_token($req['t']);
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    // Ignore our own preview and machine fetches seconds after sending.
    $too_soon = $e && (current_time('timestamp') - strtotime($e->sent_at)) < 20;
    if ($e && !$too_soon && !preg_match('/bot|spider|crawl/i', $ua)) {
        $first = !$e->first_open;
        $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('emails') . " SET opens = opens + 1, first_open = COALESCE(first_open, %s) WHERE id = %d", fwcrm_now(), $e->id));
        if ($e->contact_id) {
            fwcrm_update_contact($e->contact_id, array('last_open' => fwcrm_now()));
            if ($first) {
                fwcrm_bump_stage($e->contact_id, 'opened');
                fwcrm_add_score($e->contact_id, 3);
                fwcrm_event($e->contact_id, 'open', array('subject' => $e->subject), $e->id);
            }
        }
    }
    fwcrm_nocache_headers();
    header('Content-Type: image/gif');
    echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
    exit;
}

function fwcrm_set_contact_cookie($contact_token) {
    $secure = is_ssl();
    setcookie('fwcrm_c', $contact_token, array('expires' => time() + YEAR_IN_SECONDS, 'path' => '/', 'secure' => $secure, 'httponly' => false, 'samesite' => 'Lax'));
}

function fwcrm_rest_click($req) {
    global $wpdb;
    $url = isset($_GET['u']) ? base64_decode(rawurldecode(wp_unslash($_GET['u']))) : '';
    if (!preg_match('#^https?://#i', (string) $url)) $url = home_url('/');
    $e = fwcrm_email_by_token($req['t']);
    if (!$e) $url = home_url('/'); // unknown link: never bounce visitors to outside sites
    if ($e && !fwcrm_is_bot()) {
        $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('emails') . " SET clicks = clicks + 1, opens = GREATEST(opens, 1), first_open = COALESCE(first_open, %s) WHERE id = %d", fwcrm_now(), $e->id));
        if ($e->contact_id) {
            $c = fwcrm_get_contact($e->contact_id);
            $first_click = !$c->last_click;
            fwcrm_update_contact($c->id, array('last_click' => fwcrm_now(), 'last_open' => $c->last_open ? $c->last_open : fwcrm_now()));
            fwcrm_bump_stage($c->id, 'opened');
            fwcrm_add_score($c->id, 10);
            fwcrm_event($c->id, 'click', array('url' => $url), $e->id);
            fwcrm_set_contact_cookie($c->token);
            if ($first_click && fwcrm_opt('notify_hot_visit')) {
                fwcrm_notify(fwcrm_contact_name($c) . ' clicked a link in your email', array('Link: ' . $url, 'Email: ' . $e->subject, '', 'Good moment to follow up.'), fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id)));
            }
        }
    }
    // Tag links to our own site so the visit links up even if cookies are blocked.
    $hosts = array(wp_parse_url(home_url(), PHP_URL_HOST), wp_parse_url((string) fwcrm_opt('website_url'), PHP_URL_HOST));
    $hosts = array_merge($hosts, array_map(function ($h) { return strpos((string) $h, 'www.') === 0 ? substr($h, 4) : 'www.' . $h; }, $hosts));
    if ($e && $e->contact_id && in_array(wp_parse_url($url, PHP_URL_HOST), array_filter($hosts), true)) {
        $c = isset($c) ? $c : fwcrm_get_contact($e->contact_id);
        if ($c) $url = add_query_arg('fw', $c->token, $url);
    }
    fwcrm_nocache_headers();
    wp_redirect(esc_url_raw($url), 302);
    exit;
}

function fwcrm_rest_unsub($req) {
    $c = fwcrm_get_contact_by_token($req['t']);
    if ($c && !$c->unsubscribed) {
        fwcrm_update_contact($c->id, array('unsubscribed' => 1, 'next_followup' => null));
        fwcrm_stop_enrollments($c->id, 'unsubscribed');
        fwcrm_event($c->id, 'unsubscribe', array());
    }
    fwcrm_nocache_headers();
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unsubscribed</title></head><body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0A0A0A;color:#F3EEE4;font-family:Montserrat,Arial,sans-serif;text-align:center"><div><div style="width:56px;height:56px;margin:0 auto 18px;border:2px solid #B08A2E;border-radius:14px;display:flex;align-items:center;justify-content:center;font-weight:800">FW</div><h1 style="font-size:26px;margin:0 0 8px">You\'re unsubscribed</h1><p style="color:#bdb5a6;margin:0">You won\'t get any more emails from ' . esc_html(fwcrm_opt('from_name')) . '.</p></div></body></html>';
    exit;
}

/* ---------- Website visitor beacon ---------- */

function fwcrm_client_ip() {
    foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR') as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '';
}

function fwcrm_country() {
    foreach (array('HTTP_CF_IPCOUNTRY', 'HTTP_X_COUNTRY_CODE', 'HTTP_X_GEO_COUNTRY', 'HTTP_CLOUDFRONT_VIEWER_COUNTRY', 'GEOIP_COUNTRY_CODE', 'HTTP_X_HCDN_COUNTRY') as $k) {
        if (!empty($_SERVER[$k]) && preg_match('/^[A-Z]{2}$/i', $_SERVER[$k])) return strtoupper($_SERVER[$k]);
    }
    return '';
}

function fwcrm_device_browser($ua) {
    $device = preg_match('/iPad|Tablet/i', $ua) ? 'tablet' : (preg_match('/Mobi|Android|iPhone/i', $ua) ? 'mobile' : 'desktop');
    $b = 'Other';
    foreach (array('Edg/' => 'Edge', 'OPR/' => 'Opera', 'SamsungBrowser' => 'Samsung', 'Chrome/' => 'Chrome', 'CriOS' => 'Chrome', 'Firefox/' => 'Firefox', 'FxiOS' => 'Firefox', 'Safari/' => 'Safari') as $needle => $name) {
        if (stripos($ua, $needle) !== false) { $b = $name; break; }
    }
    return array($device, $b);
}

function fwcrm_rest_visit($req) {
    global $wpdb;
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    if (fwcrm_is_bot($ua) || !fwcrm_opt('track_visitors')) return new WP_REST_Response(array('ok' => 0), 200);
    $p = $req->get_json_params();
    if (!$p) $p = json_decode($req->get_body(), true);
    if (!is_array($p)) return new WP_REST_Response(array('ok' => 0), 200);
    $ev = isset($p['ev']) ? $p['ev'] : 'view';
    $vid = preg_replace('/[^a-z0-9]/i', '', isset($p['vid']) ? $p['vid'] : '');
    if (strlen($vid) < 8) return new WP_REST_Response(array('ok' => 0), 200);

    // Update an existing pageview (time on page, scroll, CTA clicks)
    if ($ev !== 'view') {
        $id = isset($p['id']) ? (int) $p['id'] : 0;
        if ($id) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT id, contact_id FROM " . fwcrm_t('visits') . " WHERE id = %d AND visitor_id = %s", $id, $vid));
            if ($row) {
                $upd = array();
                if (isset($p['dur'])) $upd['duration'] = min(7200, max(0, (int) $p['dur']));
                if (isset($p['scroll'])) $upd['max_scroll'] = min(100, max(0, (int) $p['scroll']));
                if ($ev === 'cta') {
                    $upd['clicked_cta'] = 1;
                    if ($row->contact_id) {
                        fwcrm_event($row->contact_id, 'cta_click', array('label' => sanitize_text_field(isset($p['label']) ? $p['label'] : '')));
                        fwcrm_add_score($row->contact_id, 15);
                    }
                }
                if ($upd) $wpdb->update(fwcrm_t('visits'), $upd, array('id' => $row->id));
            }
        }
        return new WP_REST_Response(array('ok' => 1), 200);
    }

    // Who is this? Cookie from an email click, or ?fw= token in the URL.
    $contact = null;
    $tok = '';
    if (!empty($p['fw'])) $tok = preg_replace('/[^a-z0-9]/', '', $p['fw']);
    elseif (!empty($_COOKIE['fwcrm_c'])) $tok = preg_replace('/[^a-z0-9]/', '', $_COOKIE['fwcrm_c']);
    if ($tok) $contact = fwcrm_get_contact_by_token($tok);
    if (!$contact) {
        $known = (int) $wpdb->get_var($wpdb->prepare("SELECT contact_id FROM " . fwcrm_t('visits') . " WHERE visitor_id = %s AND contact_id > 0 ORDER BY id DESC LIMIT 1", $vid));
        if ($known) $contact = fwcrm_get_contact($known);
    }
    if ($contact && !empty($p['fw']) && !fwcrm_is_site_mode()) fwcrm_set_contact_cookie($contact->token);

    $ref = esc_url_raw(isset($p['ref']) ? substr($p['ref'], 0, 255) : '');
    $ref_host = $ref ? (string) wp_parse_url($ref, PHP_URL_HOST) : '';
    $own = array(wp_parse_url(home_url(), PHP_URL_HOST), wp_parse_url((string) fwcrm_opt('website_url'), PHP_URL_HOST));
    if (in_array(preg_replace('/^www\./', '', $ref_host), array_map(function ($h) { return preg_replace('/^www\./', '', (string) $h); }, $own), true)) { $ref = ''; $ref_host = ''; }
    list($device, $browser) = fwcrm_device_browser($ua);
    $salt = wp_salt('nonce') . date('Y-m-d');
    $wpdb->insert(fwcrm_t('visits'), array(
        'visitor_id' => $vid,
        'session_id' => preg_replace('/[^a-z0-9]/i', '', isset($p['sid']) ? $p['sid'] : ''),
        'contact_id' => $contact ? $contact->id : 0,
        'path' => substr(sanitize_text_field(isset($p['path']) ? $p['path'] : '/'), 0, 255),
        'title' => substr(sanitize_text_field(isset($p['title']) ? $p['title'] : ''), 0, 255),
        'referrer' => $ref,
        'ref_host' => preg_replace('/^www\./', '', $ref_host),
        'utm_source' => substr(sanitize_text_field(isset($p['us']) ? $p['us'] : ''), 0, 100),
        'utm_medium' => substr(sanitize_text_field(isset($p['um']) ? $p['um'] : ''), 0, 100),
        'utm_campaign' => substr(sanitize_text_field(isset($p['uc']) ? $p['uc'] : ''), 0, 100),
        'device' => $device,
        'browser' => $browser,
        'country' => fwcrm_country(),
        'ip_hash' => hash('sha256', fwcrm_client_ip() . $salt),
        'created' => fwcrm_now(),
    ));
    $visit_id = (int) $wpdb->insert_id;

    if ($contact) {
        $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('visits') . " SET contact_id = %d WHERE visitor_id = %s AND contact_id = 0", $contact->id, $vid));
        $prev = $contact->last_visit ? strtotime($contact->last_visit) : 0;
        fwcrm_update_contact($contact->id, array('last_visit' => fwcrm_now()));
        if (current_time('timestamp') - $prev > 30 * MINUTE_IN_SECONDS) {
            fwcrm_add_score($contact->id, 5);
            fwcrm_event($contact->id, 'visit', array('path' => isset($p['path']) ? $p['path'] : '/'));
            if (fwcrm_opt('notify_hot_visit') && !get_transient('fwcrm_hot_' . $contact->id)) {
                set_transient('fwcrm_hot_' . $contact->id, 1, 6 * HOUR_IN_SECONDS);
                fwcrm_notify(fwcrm_contact_name($contact) . ' is on your website now', array('Page: ' . (isset($p['path']) ? $p['path'] : '/'), 'Company: ' . ($contact->company ?: '—'), '', 'They are warm. A quick personal follow-up works well right now.'), fwcrm_admin_url('fwcrm-contacts', array('view' => $contact->id)));
            }
        }
    }
    return new WP_REST_Response(array('ok' => 1, 'id' => $visit_id), 200);
}

/** Front-end tracker: tiny, cookie-light, no third parties. */
add_action('wp_footer', function () {
    if (!fwcrm_opt('track_visitors') || is_admin() || wp_doing_ajax()) return;
    if (is_user_logged_in() && current_user_can('manage_options') && !fwcrm_opt('track_admins')) return;
    $endpoint = esc_url_raw(fwcrm_track_endpoint());
    ?>
<script id="fwcrm-track">(function(){try{
var E=<?php echo wp_json_encode($endpoint); ?>,L=localStorage,S=sessionStorage;
function rid(){return (Date.now().toString(36)+Math.random().toString(36).slice(2,10));}
var vid=L.getItem('fwv');if(!vid){vid=rid();L.setItem('fwv',vid);}
var sid=S.getItem('fws');if(!sid){sid=rid();S.setItem('fws',sid);}
var q=new URLSearchParams(location.search),t0=Date.now(),id=0,max=0;
if(q.get('fw'))L.setItem('fwc',q.get('fw'));
var d={ev:'view',vid:vid,sid:sid,path:location.pathname+location.hash,title:document.title,ref:document.referrer,us:q.get('utm_source')||'',um:q.get('utm_medium')||'',uc:q.get('utm_campaign')||'',fw:q.get('fw')||L.getItem('fwc')||''};
fetch(E,{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify(d),credentials:'omit',keepalive:true}).then(function(r){return r.json()}).then(function(j){id=j&&j.id||0;}).catch(function(){});
if(q.get('fw')&&history.replaceState){q.delete('fw');var s=q.toString();history.replaceState(null,'',location.pathname+(s?'?'+s:'')+location.hash);}
addEventListener('scroll',function(){var h=document.documentElement,p=Math.round((h.scrollTop+innerHeight)/h.scrollHeight*100);if(p>max)max=p;},{passive:true});
function ping(ev,extra){if(!id)return;var b={ev:ev,vid:vid,id:id,dur:Math.round((Date.now()-t0)/1000),scroll:max};for(var k in extra)b[k]=extra[k];var body=JSON.stringify(b);if(navigator.sendBeacon){navigator.sendBeacon(E,new Blob([body],{type:'text/plain'}));}else{fetch(E,{method:'POST',headers:{'Content-Type':'text/plain'},body:body,credentials:'omit',keepalive:true});}}
document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')ping('ping');});
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a');if(!a)return;var h=a.getAttribute('href')||'';if(/calendar\.app\.google|calendly|mailto:|wa\.me|fiverr\.com|instagram\.com\/felixeweb/i.test(h)||/book|call|hire|contact/i.test(a.textContent)){ping('cta',{label:(a.textContent||h).trim().slice(0,80)});}},true);
}catch(e){}})();</script>
    <?php
}, 99);
