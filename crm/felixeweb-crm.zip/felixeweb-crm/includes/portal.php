<?php
/**
 * Sidebar navigation, messages (team + client chat), client portal and the branded Hub login.
 *
 * Threads:  u:<user_id>  Felix ↔ team member (direct)
 *           p:<project>  team chat for a project (Felix + lead person + assigned members)
 *           c:<project>  client chat for a project (Felix + the client's portal login)
 */
if (!defined('ABSPATH')) exit;

define('FWCRM_CLIENT_ROLE', 'fw_client');

/* =========================================================
 * Setup
 * ======================================================= */

add_action('init', function () {
    if (get_option('fwcrm_portal_version') === '1') return;
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE " . fwcrm_t('messages') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        thread varchar(40) NOT NULL DEFAULT '',
        sender_id bigint(20) unsigned NOT NULL DEFAULT 0,
        body text NULL,
        file_id bigint(20) unsigned NOT NULL DEFAULT 0,
        created datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY thread (thread)
    ) " . $wpdb->get_charset_collate() . ";");
    if (!get_role(FWCRM_CLIENT_ROLE)) add_role(FWCRM_CLIENT_ROLE, 'FelixeWeb Client', array('read' => true, 'fwcrm_client' => true));
    update_option('fwcrm_portal_version', '1', false);
});

function fwcrm_is_client($uid = 0) {
    $uid = $uid ?: get_current_user_id();
    return $uid && user_can($uid, 'fwcrm_client') && !user_can($uid, 'manage_options');
}

/* =========================================================
 * Sidebar
 * ======================================================= */

function fwcrm_icon($name) {
    $i = array(
        'today' => '<path d="M4 6h16M4 12h16M4 18h10"/>',
        'inbox' => '<path d="M4 5h16v11H8l-4 4z"/>',
        'leads' => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5M16 4.5a3.5 3.5 0 010 7"/>',
        'pipeline' => '<rect x="3" y="4" width="5" height="16" rx="1.5"/><rect x="10" y="4" width="5" height="11" rx="1.5"/><rect x="17" y="4" width="4" height="7" rx="1.5"/>',
        'follow' => '<path d="M4 12a8 8 0 0114-5.3M20 12a8 8 0 01-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/>',
        'projects' => '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M8 6V4h8v2"/>',
        'team' => '<circle cx="9" cy="8" r="3.5"/><circle cx="17" cy="9" r="2.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5M16 14.5c2.6 0 4.6 1.8 5.3 5.5"/>',
        'chat' => '<path d="M21 12a8 8 0 01-11.6 7.1L4 20l1-4.6A8 8 0 1121 12z"/>',
        'blog' => '<path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        'replies' => '<rect x="3" y="5" width="13" height="14" rx="2"/><path d="M16 10l5-3v10l-5-3"/>',
        'web' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>',
        'social' => '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.6M8.2 13.2l7.6 4.6"/>',
        'stats' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'ai' => '<path d="M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
        'shield' => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
        'wp' => '<circle cx="12" cy="12" r="9"/><path d="M5 8l4 11 3-8 3 8 4-11"/>',
        'out' => '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
        'work' => '<path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 01-2 2H6a2 2 0 01-2-2V5a2 2 0 012-2h9"/>',
        'collapse' => '<path d="M15 6l-6 6 6 6"/>',
    );
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . (isset($i[$name]) ? $i[$name] : '') . '</svg>';
}

function fwcrm_sidebar($cur) {
    global $wpdb;
    $unread = fwcrm_unread_total(get_current_user_id());
    if (function_exists('fwcrm_is_member') && fwcrm_is_member()) {
        $groups = array('' => array(
            'fwcrm-my' => array('My work', 'work', 0),
            'fwcrm-chat' => array('Messages', 'chat', $unread),
            'fwcrm-security' => array('Security', 'shield', 0),
        ));
        $bottom = '<a href="' . esc_url(wp_logout_url(home_url('/hub/'))) . '">' . fwcrm_icon('out') . '<span>Log out</span></a>';
    } else {
        $waiting = (int) $wpdb->get_var("SELECT COUNT(DISTINCT contact_id) FROM " . fwcrm_t('emails') . " WHERE direction='in' AND kind='reply' AND handled=0");
        $over = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " WHERE done = 0 AND due IS NOT NULL AND due <= %s", fwcrm_now()));
        $drafts = (int) wp_count_posts('post')->draft;
        $groups = array(
            'Sell' => array(
                'fwcrm' => array('Today', 'today', $over),
                'fwcrm-inbox' => array('Inbox', 'inbox', $waiting),
                'fwcrm-contacts' => array('Leads', 'leads', 0),
                'fwcrm-pipeline' => array('Pipeline', 'pipeline', 0),
                'fwcrm-sequences' => array('Follow-ups', 'follow', 0),
            ),
            'Deliver' => array(
                'fwcrm-projects' => array('Projects', 'projects', 0),
                'fwcrm-messages' => array('Messages', 'chat', $unread),
                'fwcrm-team' => array('Team', 'team', 0),
            ),
            'Grow' => array(
                'fwcrm-blog' => array('Blog', 'blog', $drafts),
                'fwcrm-replies' => array('Replies & videos', 'replies', 0),
                'fwcrm-social' => array('Social', 'social', 0),
                'fwcrm-visitors' => array('Website', 'web', 0),
                'fwcrm-stats' => array('Stats', 'stats', 0),
            ),
        );
        if (function_exists('fwcrm_ai_key') && fwcrm_ai_key() !== '') $groups['Grow']['fwcrm-ai'] = array('My AI', 'ai', 0);
        $bottom = '<a class="' . ($cur === 'fwcrm-security' ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-security')) . '">' . fwcrm_icon('shield') . '<span>Security</span></a>'
            . '<a class="' . ($cur === 'fwcrm-settings' ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-settings')) . '">' . fwcrm_icon('settings') . '<span>Settings</span></a>'
            . '<a href="' . esc_url(admin_url()) . '">' . fwcrm_icon('wp') . '<span>WordPress</span></a>'
            . '<a href="' . esc_url(wp_logout_url(home_url('/hub/'))) . '">' . fwcrm_icon('out') . '<span>Log out</span></a>';
    }
    $me = wp_get_current_user();
    $o = '<aside class="fw-snav" id="fw-snav"><div class="fw-snav-top"><a class="fw-brand" href="' . esc_url(fwcrm_admin_url(fwcrm_is_member() ? 'fwcrm-my' : 'fwcrm')) . '"><span class="fw-mark">F<b>W</b></span><span class="fw-word">FELIXE<b>WEB</b> <em>HUB</em></span></a><button type="button" class="fw-snav-col" data-fw-collapse title="Collapse menu">' . fwcrm_icon('collapse') . '</button></div><nav>';
    foreach ($groups as $g => $items) {
        if ($g) $o .= '<div class="fw-snav-g">' . esc_html($g) . '</div>';
        foreach ($items as $slug => $it) {
            $o .= '<a class="' . ($slug === $cur ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url($slug)) . '" title="' . esc_attr($it[0]) . '">' . fwcrm_icon($it[1]) . '<span>' . esc_html($it[0]) . '</span>' . ($it[2] ? '<b class="fw-snav-n">' . (int) $it[2] . '</b>' : '') . '</a>';
        }
    }
    $o .= '</nav><div class="fw-snav-bottom">' . $bottom . '<div class="fw-snav-me">' . (function_exists('fwcrm_member_avatar') ? fwcrm_member_avatar($me->ID) : '') . '<span>' . esc_html($me->display_name) . '</span></div></div></aside>';
    return $o;
}

add_action('admin_menu', function () {
    add_submenu_page('fwcrm', 'Messages', 'Messages', 'manage_options', 'fwcrm-messages', 'fwcrm_page_messages');
    if (function_exists('fwcrm_is_member') && fwcrm_is_member()) add_submenu_page('fwcrm-my', 'Messages', 'Messages', 'fwcrm_team', 'fwcrm-chat', 'fwcrm_page_member_chat');
}, 22);


/* =========================================================
 * Threads, permissions, unread counts
 * ======================================================= */

function fwcrm_thread_parts($t) {
    return preg_match('/^([upc]):(\d+)$/', (string) $t, $m) ? array($m[1], (int) $m[2]) : array('', 0);
}

function fwcrm_project_people($pid) {
    global $wpdb;
    $p = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('projects') . " WHERE id = %d", $pid));
    if (!$p) return array();
    $ids = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT assigned_to FROM " . fwcrm_t('tasks') . " WHERE project_id = %d AND assigned_to > 0", $pid));
    if ($p->owner_id) $ids[] = $p->owner_id;
    return array_values(array_unique(array_map('intval', $ids)));
}

function fwcrm_project_clients($pid) {
    global $wpdb;
    $cid = (int) $wpdb->get_var($wpdb->prepare("SELECT contact_id FROM " . fwcrm_t('projects') . " WHERE id = %d", $pid));
    if (!$cid) return array();
    return array_map('intval', get_users(array('role' => FWCRM_CLIENT_ROLE, 'meta_key' => 'fw_contact_id', 'meta_value' => $cid, 'fields' => 'ID')));
}

function fwcrm_can_thread($uid, $thread) {
    list($type, $id) = fwcrm_thread_parts($thread);
    if (!$type || !$uid) return false;
    if (user_can($uid, 'manage_options')) return true;
    if ($type === 'u') return $id === (int) $uid && user_can($uid, 'fwcrm_team');
    if ($type === 'p') return user_can($uid, 'fwcrm_team') && in_array((int) $uid, fwcrm_project_people($id), true);
    if ($type === 'c') return in_array((int) $uid, fwcrm_project_clients($id), true);
    return false;
}

function fwcrm_thread_participants($thread) {
    list($type, $id) = fwcrm_thread_parts($thread);
    $admins = array_map('intval', get_users(array('role' => 'administrator', 'fields' => 'ID')));
    if ($type === 'u') return array_unique(array_merge($admins, array($id)));
    if ($type === 'p') return array_unique(array_merge($admins, fwcrm_project_people($id)));
    if ($type === 'c') return array_unique(array_merge($admins, fwcrm_project_clients($id)));
    return $admins;
}

function fwcrm_thread_title($thread, $for_uid = 0) {
    global $wpdb;
    list($type, $id) = fwcrm_thread_parts($thread);
    if ($type === 'u') {
        if ($for_uid && !user_can($for_uid, 'manage_options')) return 'Felix';
        $u = get_userdata($id); return $u ? $u->display_name : 'Team member';
    }
    $title = (string) $wpdb->get_var($wpdb->prepare("SELECT title FROM " . fwcrm_t('projects') . " WHERE id = %d", $id));
    if ($type === 'p') return $title . ' · team';
    return $title . ($for_uid && fwcrm_is_client($for_uid) ? '' : ' · client');
}

/** Threads a user can see, newest activity first, with unread counts. */
function fwcrm_user_threads($uid) {
    global $wpdb;
    $T = fwcrm_t('messages');
    $threads = array();
    if (user_can($uid, 'manage_options')) {
        foreach (function_exists('fwcrm_team_users') ? fwcrm_team_users() : array() as $u) if ((int) $u->ID !== (int) $uid && !user_can($u, 'manage_options')) $threads['u:' . $u->ID] = 1;
        foreach ($wpdb->get_col("SELECT id FROM " . fwcrm_t('projects') . " WHERE status <> 'delivered' OR updated > DATE_SUB(NOW(), INTERVAL 30 DAY)") as $pid) {
            $threads['p:' . $pid] = 1;
            if (fwcrm_project_clients($pid)) $threads['c:' . $pid] = 1;
        }
        foreach ($wpdb->get_col("SELECT DISTINCT thread FROM $T") as $t) $threads[$t] = 1;
    } elseif (user_can($uid, 'fwcrm_team')) {
        $threads['u:' . $uid] = 1;
        foreach ($wpdb->get_col($wpdb->prepare("SELECT p.id FROM " . fwcrm_t('projects') . " p WHERE p.owner_id = %d OR EXISTS (SELECT 1 FROM " . fwcrm_t('tasks') . " t WHERE t.project_id = p.id AND t.assigned_to = %d)", $uid, $uid)) as $pid) $threads['p:' . $pid] = 1;
    } elseif (fwcrm_is_client($uid)) {
        $cid = (int) get_user_meta($uid, 'fw_contact_id', true);
        if ($cid) foreach ($wpdb->get_col($wpdb->prepare("SELECT id FROM " . fwcrm_t('projects') . " WHERE contact_id = %d", $cid)) as $pid) $threads['c:' . $pid] = 1;
    }
    $seen = (array) get_user_meta($uid, 'fwcrm_seen', true);
    $out = array();
    foreach (array_keys($threads) as $t) {
        if (!fwcrm_thread_parts($t)[0]) continue;
        $last = $wpdb->get_row($wpdb->prepare("SELECT id, body, sender_id, created, file_id FROM $T WHERE thread = %s ORDER BY id DESC LIMIT 1", $t));
        $after = isset($seen[$t]) ? (int) $seen[$t] : 0;
        $unread = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $T WHERE thread = %s AND id > %d AND sender_id <> %d", $t, $after, $uid));
        $out[] = array('thread' => $t, 'title' => fwcrm_thread_title($t, $uid), 'type' => fwcrm_thread_parts($t)[0], 'last' => $last ? wp_html_excerpt(($last->file_id && !$last->body ? '📎 File' : $last->body), 70, '…') : '', 'at' => $last ? $last->created : '', 'last_id' => $last ? (int) $last->id : 0, 'unread' => $unread);
    }
    usort($out, function ($a, $b) { return strcmp($b['at'], $a['at']); });
    return $out;
}

function fwcrm_unread_total($uid) {
    if (!$uid) return 0;
    $c = wp_cache_get('fwcrm_unread_' . $uid);
    if ($c !== false) return (int) $c;
    $n = 0; foreach (fwcrm_user_threads($uid) as $t) $n += $t['unread'];
    wp_cache_set('fwcrm_unread_' . $uid, $n);
    return $n;
}

function fwcrm_msg_out($m, $uid) {
    $u = get_userdata($m->sender_id);
    $file = null;
    if ($m->file_id) {
        if (get_post($m->file_id)) { $url = fwcrm_file_url($m->file_id); $file = array('url' => $url, 'name' => fwcrm_file_name($m->file_id), 'image' => strpos((string) get_post_mime_type($m->file_id), 'image/') === 0 ? $url : ''); }
    }
    $photo = function_exists('fwcrm_member_photo') ? fwcrm_member_photo($m->sender_id, 'thumbnail') : '';
    return array('id' => (int) $m->id, 'mine' => (int) $m->sender_id === (int) $uid, 'name' => $u ? $u->display_name : 'Someone', 'photo' => $photo, 'body' => (string) $m->body, 'file' => $file, 'at' => mysql2date('j M, H:i', $m->created));
}

/* =========================================================
 * AJAX
 * ======================================================= */

add_action('wp_ajax_fwcrm_chat', function () {
    if (!check_ajax_referer('fwcrm_chat', 'nonce', false)) wp_send_json_error('Session expired. Reload the page.');
    $uid = get_current_user_id();
    global $wpdb;
    $T = fwcrm_t('messages');
    $do = isset($_POST['do']) ? sanitize_key($_POST['do']) : '';
    if ($do === 'threads') wp_send_json_success(array('threads' => fwcrm_user_threads($uid), 'unread' => fwcrm_unread_total($uid)));
    $thread = isset($_POST['thread']) ? sanitize_text_field(wp_unslash($_POST['thread'])) : '';
    if (!fwcrm_can_thread($uid, $thread)) wp_send_json_error('You can’t open this conversation.');
    if ($do === 'load') {
        $after = (int) (isset($_POST['after']) ? $_POST['after'] : 0);
        $rows = $after ? $wpdb->get_results($wpdb->prepare("SELECT * FROM $T WHERE thread = %s AND id > %d ORDER BY id ASC LIMIT 200", $thread, $after))
                       : array_reverse($wpdb->get_results($wpdb->prepare("SELECT * FROM $T WHERE thread = %s ORDER BY id DESC LIMIT 80", $thread)));
        $msgs = array(); foreach ($rows as $r) $msgs[] = fwcrm_msg_out($r, $uid);
        if ($msgs) { $seen = (array) get_user_meta($uid, 'fwcrm_seen', true); $seen[$thread] = max((int) (isset($seen[$thread]) ? $seen[$thread] : 0), end($msgs)['id']); update_user_meta($uid, 'fwcrm_seen', $seen); }
        wp_send_json_success(array('messages' => $msgs, 'title' => fwcrm_thread_title($thread, $uid)));
    }
    if ($do === 'send') {
        $body = trim(sanitize_textarea_field(wp_unslash(isset($_POST['body']) ? $_POST['body'] : '')));
        $file_id = 0;
        if (!empty($_FILES['file']['name'])) {
            $ok = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'zip', 'mp4', 'mov', 'doc', 'docx', 'txt', 'psd', 'ai', 'svg', 'epub', 'mp3', 'wav');
            $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $ok, true)) wp_send_json_error('That file type isn’t allowed.');
            if ($ext === 'svg' && !user_can($uid, 'manage_options')) wp_send_json_error('That file type isn’t allowed.');
            $file_id = fwcrm_private_store($_FILES['file'], $thread);
            if (is_wp_error($file_id)) wp_send_json_error($file_id->get_error_message());
        }
        if ($body === '' && !$file_id) wp_send_json_error('Write a message first.');
        $wpdb->insert($T, array('thread' => $thread, 'sender_id' => $uid, 'body' => $body, 'file_id' => $file_id, 'created' => fwcrm_now()));
        $mid = (int) $wpdb->insert_id;
        $seen = (array) get_user_meta($uid, 'fwcrm_seen', true); $seen[$thread] = $mid; update_user_meta($uid, 'fwcrm_seen', $seen);
        fwcrm_chat_notify($thread, $uid, $body ?: '📎 Sent a file');
        list($type, $id) = fwcrm_thread_parts($thread);
        if (($type === 'p' || $type === 'c') && function_exists('fwcrm_project_log') && !user_can($uid, 'manage_options')) fwcrm_project_log($id, ($type === 'c' ? 'Client message: ' : 'Team message: ') . wp_html_excerpt($body ?: 'file', 80, '…'));
        $m = $wpdb->get_row($wpdb->prepare("SELECT * FROM $T WHERE id = %d", $mid));
        wp_send_json_success(array('message' => fwcrm_msg_out($m, $uid)));
    }
    wp_send_json_error('Unknown request');
});

function fwcrm_chat_notify($thread, $from, $text) {
    $sender = get_userdata($from);
    $name = $sender ? $sender->display_name : 'Someone';
    list($type, $id) = fwcrm_thread_parts($thread);
    if (!user_can($from, 'manage_options')) {
        $url = admin_url('admin.php?page=fwcrm-messages&t=' . rawurlencode($thread));
        if (function_exists('fwcrm_push')) fwcrm_push('💬 ' . $name . ($type === 'c' ? ' (client)' : ''), wp_html_excerpt($text, 180, '…'), $url, 'speech_balloon');
    }
    foreach (fwcrm_thread_participants($thread) as $uid) {
        if ((int) $uid === (int) $from || user_can($uid, 'manage_options')) continue;
        $key = 'fwcrm_chatmail_' . $uid . '_' . md5($thread);
        if (get_transient($key)) continue; // at most one email per conversation every 20 minutes
        set_transient($key, 1, 20 * MINUTE_IN_SECONDS);
        $u = get_userdata($uid); if (!$u || !$u->user_email) continue;
        $link = fwcrm_is_client($uid) ? home_url('/portal/') : admin_url('admin.php?page=fwcrm-chat&t=' . rawurlencode($thread));
        wp_mail($u->user_email, 'New message from ' . $name . ' · FelixeWeb', "Hi " . ($u->first_name ?: $u->display_name) . ",\n\n" . $name . " wrote:\n\n" . $text . "\n\nReply here: " . $link . "\n\nFelixeWeb");
    }
}

/* =========================================================
 * Chat UI (shared by Hub, team and portal)
 * ======================================================= */

function fwcrm_chat_assets() {
    static $done = false; if ($done) return ''; $done = true;
    return '<style>' . file_get_contents(FWCRM_DIR . 'assets/chat.css') . '</style><script>window.FWCHAT=' . wp_json_encode(array('ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('fwcrm_chat'))) . ';</script><script>' . file_get_contents(FWCRM_DIR . 'assets/chat.js') . '</script>';
}

function fwcrm_chat_ui($threads, $open = '', $opts = array()) {
    $o = fwcrm_chat_assets();
    $o .= '<div class="fwc" data-open="' . esc_attr($open) . '"' . (!empty($opts['single']) ? ' data-single="1"' : '') . '><div class="fwc-list"><div class="fwc-lh">' . esc_html(isset($opts['list_title']) ? $opts['list_title'] : 'Conversations') . '</div>';
    if (!$threads) $o .= '<div class="fwc-empty">No conversations yet.</div>';
    $labels = array('u' => 'Team member', 'p' => 'Project team', 'c' => 'Client');
    foreach ($threads as $t) {
        $o .= '<button type="button" class="fwc-t" data-thread="' . esc_attr($t['thread']) . '"><span class="fwc-av t-' . esc_attr($t['type']) . '">' . esc_html(strtoupper(mb_substr($t['title'], 0, 1))) . '</span><span class="fwc-tm"><b>' . esc_html($t['title']) . '</b><small>' . esc_html($t['last'] ?: (isset($labels[$t['type']]) ? $labels[$t['type']] : '')) . '</small></span>' . ($t['unread'] ? '<i class="fwc-badge">' . (int) $t['unread'] . '</i>' : '') . '</button>';
    }
    $o .= '</div><div class="fwc-pane"><div class="fwc-ph"><button type="button" class="fwc-back" aria-label="Back">←</button><b class="fwc-title">Pick a conversation</b></div><div class="fwc-msgs"><div class="fwc-hint">Choose a conversation on the left to start chatting.</div></div>';
    $o .= '<form class="fwc-form"><label class="fwc-attach" title="Attach a file"><input type="file" name="file" hidden><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M21 12l-8.5 8.5a5 5 0 01-7-7L14 5a3.3 3.3 0 014.7 4.7L10.2 18a1.7 1.7 0 01-2.4-2.4L15.5 8"/></svg></label><textarea name="body" rows="1" placeholder="Write a message…"></textarea><button class="fwc-send" type="submit" aria-label="Send"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg></button></form><div class="fwc-file"></div></div></div>';
    return $o;
}

function fwcrm_page_messages() {
    $uid = get_current_user_id();
    $open = isset($_GET['t']) ? sanitize_text_field(wp_unslash($_GET['t'])) : '';
    fwcrm_header('Messages', 'Chat with your team and your clients. Team members see only their own chats; clients see only theirs.');
    echo fwcrm_chat_ui(fwcrm_user_threads($uid), $open);
    fwcrm_footer();
}

function fwcrm_page_member_chat() {
    $uid = get_current_user_id();
    $open = isset($_GET['t']) ? sanitize_text_field(wp_unslash($_GET['t'])) : 'u:' . $uid;
    fwcrm_header('Messages', 'Talk to Felix about your work. Project chats include everyone on that project.');
    echo fwcrm_chat_ui(fwcrm_user_threads($uid), $open);
    fwcrm_footer();
}

/* =========================================================
 * Client portal invites (from a project)
 * ======================================================= */

add_action('admin_post_fwcrm_invite_client', function () {
    fwcrm_guard('fwcrm_invite_client');
    global $wpdb;
    $pid = (int) $_POST['project_id'];
    $p = $wpdb->get_row($wpdb->prepare("SELECT p.*, c.email, c.first_name, c.last_name, c.company FROM " . fwcrm_t('projects') . " p LEFT JOIN " . fwcrm_t('contacts') . " c ON c.id = p.contact_id WHERE p.id = %d", $pid));
    if (!$p || !$p->contact_id || !is_email($p->email)) fwcrm_back('fwcrm-projects', array('p' => $pid), 'Link this project to a client with an email first (Edit → Client email).', true);
    $uid = email_exists($p->email);
    if ($uid && user_can($uid, 'manage_options')) fwcrm_back('fwcrm-projects', array('p' => $pid), 'That email belongs to an admin.', true);
    if (!$uid) {
        $name = trim($p->first_name . ' ' . $p->last_name) ?: ($p->company ?: strstr($p->email, '@', true));
        $login = sanitize_user(strstr($p->email, '@', true), true) ?: 'client';
        while (username_exists($login)) $login .= wp_rand(1, 9);
        $uid = wp_insert_user(array('user_login' => $login, 'user_email' => $p->email, 'display_name' => $name, 'first_name' => $p->first_name, 'user_pass' => wp_generate_password(24), 'role' => FWCRM_CLIENT_ROLE));
        if (is_wp_error($uid)) fwcrm_back('fwcrm-projects', array('p' => $pid), $uid->get_error_message(), true);
    } elseif (!user_can($uid, 'fwcrm_client')) {
        (new WP_User($uid))->add_role(FWCRM_CLIENT_ROLE);
    }
    update_user_meta($uid, 'fw_contact_id', (int) $p->contact_id);
    $u = get_userdata($uid);
    $key = get_password_reset_key($u);
    $set = is_wp_error($key) ? wp_lostpassword_url() : network_site_url('wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode($u->user_login), 'login');
    wp_mail($u->user_email, 'Your FelixeWeb project portal', "Hi " . ($u->first_name ?: $u->display_name) . ",\n\nYour project \"" . $p->title . "\" now has its own page where you can follow progress, share files and message us directly.\n\n1. Set your password: " . $set . "\n2. Then sign in any time at: " . home_url('/portal/') . "\n\nFelix\nFelixeWeb");
    if (function_exists('fwcrm_project_log')) fwcrm_project_log($pid, 'Client invited to the portal');
    fwcrm_back('fwcrm-projects', array('p' => $pid), 'Invite sent to ' . $u->user_email . '.');
});

/* =========================================================
 * Front-end: /hub/ login and /portal/
 * ======================================================= */

function fwcrm_front_route() {
    $path = trim((string) parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH), '/');
    if ($path === 'hub' || $path === 'hub/login' || $path === 'team') return 'hub';
    if ($path === 'portal') return 'portal';
    return '';
}

function fwcrm_home_for($uid) {
    if (user_can($uid, 'manage_options')) return admin_url('admin.php?page=fwcrm');
    if (user_can($uid, 'fwcrm_team')) return admin_url('admin.php?page=fwcrm-my');
    if (user_can($uid, 'fwcrm_client')) return home_url('/portal/');
    return home_url('/');
}

add_action('init', function () {
    $r = fwcrm_front_route();
    if (!$r) return;
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow', true);
    if (function_exists('fwcrm_sec_headers')) { fwcrm_sec_headers(); header("Content-Security-Policy: frame-ancestors 'self'"); }
    $err = isset($_GET['locked']) ? 'Too many wrong codes. Sign in again.' : (isset($_GET['reset']) ? 'Check your email for the password link.' : '');
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fw_login'])) {
        if (!wp_verify_nonce(isset($_POST['_fw']) ? $_POST['_fw'] : '', 'fwcrm_front_login')) $err = 'The page expired. Please try again.';
        else {
            $user = wp_signon(array('user_login' => sanitize_text_field(wp_unslash($_POST['log'])), 'user_password' => (string) wp_unslash($_POST['pwd']), 'remember' => !empty($_POST['rememberme'])), is_ssl());
            if (is_wp_error($user)) $err = $user->get_error_code() === 'fw_locked' ? $user->get_error_message() : 'That email or password isn’t right.';
            else { wp_safe_redirect(fwcrm_home_for($user->ID)); exit; }
        }
    }
    if (is_user_logged_in()) {
        $uid = get_current_user_id();
        if ($r === 'hub' || !fwcrm_is_client($uid) && !user_can($uid, 'manage_options')) { wp_safe_redirect(fwcrm_home_for($uid)); exit; }
        if ($r === 'portal') { fwcrm_render_portal($uid); exit; }
    }
    fwcrm_render_login($r, $err);
    exit;
}, 5);

/* Clients never see wp-admin or the admin bar. */
add_action('admin_init', function () {
    if (wp_doing_ajax() || !is_user_logged_in()) return;
    if (fwcrm_is_client() && !current_user_can('fwcrm_team')) {
        global $pagenow;
        if (!in_array($pagenow, array('admin-post.php', 'async-upload.php'), true)) { wp_safe_redirect(home_url('/portal/')); exit; }
    }
}, 1);
add_filter('show_admin_bar', function ($s) { return fwcrm_is_client() ? false : $s; }, 20);
add_filter('login_redirect', function ($to, $req, $user) {
    if ($user instanceof WP_User && user_can($user, 'fwcrm_client') && !user_can($user, 'manage_options') && !user_can($user, 'fwcrm_team')) return home_url('/portal/');
    return $to;
}, 11, 3);

function fwcrm_front_head($title) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . esc_html($title) . ' · FelixeWeb</title><link rel="icon" href="' . esc_url(FWCRM_URL . 'assets/icon-192.png') . '"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300&display=swap" rel="stylesheet"><style>' . file_get_contents(FWCRM_DIR . 'assets/portal.css') . '</style></head><body>';
}

function fwcrm_render_login($r, $err) {
    $portal = $r === 'portal';
    fwcrm_front_head($portal ? 'Client portal' : 'Hub sign in');
    echo '<main class="fp-login"><div class="fp-glow"></div><div class="fp-card"><a class="fp-brand" href="/"><span class="fp-mark">F<b>W</b></span><span>FELIXE<b>WEB</b></span></a>';
    echo '<h1>' . ($portal ? 'Your project <em>portal</em>' : 'Sign in to the <em>Hub</em>') . '</h1><p class="fp-sub">' . ($portal ? 'Follow your project, share files and message the FelixeWeb team.' : 'For Felix and the FelixeWeb team. Team members land on their own work page.') . '</p>';
    if ($err) echo '<div class="fp-err">' . esc_html($err) . '</div>';
    echo '<form method="post" action="' . esc_url(home_url($portal ? '/portal/' : '/hub/')) . '"><input type="hidden" name="fw_login" value="1">' . wp_nonce_field('fwcrm_front_login', '_fw', false, false);
    echo '<label>Email or username<input name="log" autocomplete="username" required autofocus value="' . esc_attr(isset($_POST['log']) ? sanitize_text_field(wp_unslash($_POST['log'])) : '') . '"></label>';
    echo '<label>Password<span class="fp-pw"><input type="password" name="pwd" autocomplete="current-password" required><button type="button" onclick="var i=this.previousElementSibling;i.type=i.type===\'password\'?\'text\':\'password\';this.textContent=i.type===\'password\'?\'Show\':\'Hide\'">Show</button></span></label>';
    echo '<div class="fp-row"><label class="fp-check"><input type="checkbox" name="rememberme" value="1" checked> Keep me signed in</label><a href="' . esc_url(wp_lostpassword_url(home_url($portal ? '/portal/' : '/hub/'))) . '">Forgot password?</a></div>';
    echo '<button class="fp-btn" type="submit">Sign in →</button></form>';
    echo '<div class="fp-foot">' . ($portal ? 'Not a client yet? <a href="/contact/">Start a project</a>' : 'Client? <a href="/portal/">Go to the client portal</a>') . '</div></div></main></body></html>';
}

function fwcrm_render_portal($uid) {
    global $wpdb;
    $u = get_userdata($uid);
    $cid = (int) get_user_meta($uid, 'fw_contact_id', true);
    $projects = user_can($uid, 'manage_options') ? $wpdb->get_results("SELECT * FROM " . fwcrm_t('projects') . " ORDER BY updated DESC LIMIT 20")
        : ($cid ? $wpdb->get_results($wpdb->prepare("SELECT * FROM " . fwcrm_t('projects') . " WHERE contact_id = %d ORDER BY updated DESC", $cid)) : array());
    $statuses = function_exists('fwcrm_project_statuses') ? fwcrm_project_statuses() : array();
    $services = function_exists('fwcrm_project_services') ? fwcrm_project_services() : array();
    fwcrm_front_head('Client portal');
    echo '<header class="fp-top"><a class="fp-brand" href="/"><span class="fp-mark">F<b>W</b></span><span>FELIXE<b>WEB</b></span></a><span class="fp-tag">Client portal</span><span class="fp-me">' . esc_html($u->display_name) . '</span><a class="fp-out" href="' . esc_url(wp_logout_url(home_url('/portal/'))) . '">Log out</a></header>';
    echo '<main class="fp-wrap"><h1 class="fp-h1">Hi ' . esc_html($u->first_name ?: $u->display_name) . '.</h1><p class="fp-sub">Here’s where your project stands. Message us any time below; we usually reply within one working day.</p>';
    if (!$projects) echo '<div class="fp-empty">There’s no project linked to your account yet. Message <a href="mailto:hello@felixeweb.com">hello@felixeweb.com</a> and we’ll set it up.</div>';
    $threads = array();
    foreach ($projects as $p) {
        $keys = array_keys($statuses); $idx = array_search($p->status, $keys, true);
        echo '<section class="fp-proj"><div class="fp-ph"><span class="fp-svc">' . esc_html(isset($services[$p->service]) ? $services[$p->service] : $p->service) . '</span><h2>' . esc_html($p->title) . '</h2>' . ($p->due ? '<span class="fp-due">Due ' . esc_html(date_i18n('j M Y', strtotime($p->due))) . '</span>' : '') . '</div><ol class="fp-steps">';
        foreach ($keys as $i => $k) echo '<li class="' . ($i < $idx ? 'done' : ($i === $idx ? 'on' : '')) . '"><i></i><span>' . esc_html($statuses[$k]) . '</span></li>';
        echo '</ol>';
        if ($p->status === 'review' && fwcrm_is_client($uid)) echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="fp-approve"><input type="hidden" name="action" value="fwcrm_client_approve"><input type="hidden" name="pid" value="' . (int) $p->id . '">' . wp_nonce_field('fwcrm_client_approve_' . $p->id, '_fw', false, false) . '<span>Your project is ready for review. Happy with it?</span><button class="fp-btn sm" onclick="return confirm(\'Approve and mark this project as delivered?\')">Approve delivery</button></form>';
        if ($p->brief) echo '<details class="fp-brief"><summary>Project brief</summary><div>' . nl2br(esc_html($p->brief)) . '</div></details>';
        $files = get_posts(array('post_type' => 'attachment', 'post_status' => array('private', 'inherit'), 'numberposts' => 20, 'meta_key' => '_fwcrm_thread', 'meta_value' => 'c:' . $p->id));
        if ($files) { echo '<div class="fp-files"><b>Shared files</b>'; foreach ($files as $f) echo '<a href="' . esc_url(fwcrm_file_url($f->ID)) . '" target="_blank" rel="noopener">📎 ' . esc_html(fwcrm_file_name($f->ID)) . '</a>'; echo '</div>'; }
        echo '</section>';
        $threads[] = array('thread' => 'c:' . $p->id, 'title' => $p->title, 'type' => 'c', 'last' => '', 'at' => '', 'last_id' => 0, 'unread' => 0);
    }
    if ($projects) {
        $list = fwcrm_user_threads($uid);
        if (user_can($uid, 'manage_options')) $list = array_values(array_filter($list, function ($t) { return $t['type'] === 'c'; }));
        echo '<h2 class="fp-h2">Messages</h2>' . fwcrm_chat_ui($list ?: $threads, ($list ?: $threads)[0]['thread'], array('list_title' => 'Your projects', 'single' => count($list ?: $threads) === 1));
    }
    echo '</main></body></html>';
}

add_action('admin_post_fwcrm_client_approve', function () {
    $pid = (int) $_POST['pid'];
    if (!wp_verify_nonce(isset($_POST['_fw']) ? $_POST['_fw'] : '', 'fwcrm_client_approve_' . $pid) || !fwcrm_can_thread(get_current_user_id(), 'c:' . $pid)) wp_die('Not allowed');
    global $wpdb;
    $wpdb->update(fwcrm_t('projects'), array('status' => 'delivered', 'updated' => fwcrm_now()), array('id' => $pid, 'status' => 'review'));
    if (function_exists('fwcrm_project_log')) fwcrm_project_log($pid, 'Client approved the delivery');
    if (function_exists('fwcrm_push')) fwcrm_push('🎉 Client approved a delivery', (string) $wpdb->get_var($wpdb->prepare("SELECT title FROM " . fwcrm_t('projects') . " WHERE id = %d", $pid)), admin_url('admin.php?page=fwcrm-projects&p=' . $pid), 'tada');
    wp_safe_redirect(home_url('/portal/')); exit;
});
