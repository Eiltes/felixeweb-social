<?php
if (!defined('ABSPATH')) exit;

/* ---------- Menu & assets ---------- */

add_action('admin_menu', function () {
    $cap = 'manage_options';
    global $wpdb;
    $waiting = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction='in' AND kind='reply' AND handled=0");
    $bubble = $waiting ? ' <span class="awaiting-mod">' . $waiting . '</span>' : '';
    $icon = 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="1.5" y="1.5" width="17" height="17" rx="4" fill="none" stroke="#B08A2E" stroke-width="2"/><text x="10" y="14" font-family="Arial" font-weight="800" font-size="8" text-anchor="middle" fill="#B08A2E">FW</text></svg>');
    add_menu_page('FelixeWeb CRM', 'FelixeWeb CRM' . $bubble, $cap, 'fwcrm', 'fwcrm_page_today', $icon, 3);
    add_submenu_page('fwcrm', 'Today', 'Today', $cap, 'fwcrm', 'fwcrm_page_today');
    add_submenu_page('fwcrm', 'Contacts', 'Contacts', $cap, 'fwcrm-contacts', 'fwcrm_page_contacts');
    add_submenu_page('fwcrm', 'Pipeline', 'Pipeline', $cap, 'fwcrm-pipeline', 'fwcrm_page_pipeline');
    add_submenu_page('fwcrm', 'Inbox', 'Inbox' . $bubble, $cap, 'fwcrm-inbox', 'fwcrm_page_inbox');
    add_submenu_page('fwcrm', 'Follow-ups', 'Follow-ups', $cap, 'fwcrm-sequences', 'fwcrm_page_sequences');
    add_submenu_page('fwcrm', 'Website visitors', 'Website visitors', $cap, 'fwcrm-visitors', 'fwcrm_page_visitors');
    add_submenu_page('fwcrm', 'Social', 'Social', $cap, 'fwcrm-social', 'fwcrm_page_social');
    add_submenu_page('fwcrm', 'Replies & videos', 'Replies & videos', $cap, 'fwcrm-replies', 'fwcrm_page_replies');
    add_submenu_page('fwcrm', 'Stats', 'Stats', $cap, 'fwcrm-stats', 'fwcrm_page_dashboard');
    if (fwcrm_ai_key() !== '') add_submenu_page('fwcrm', 'My AI', 'My AI', $cap, 'fwcrm-ai', 'fwcrm_page_ai');
    add_submenu_page('fwcrm', 'Settings', 'Settings', $cap, 'fwcrm-settings', 'fwcrm_page_settings');
});

function fwcrm_is_crm_screen() {
    return isset($_GET['page']) && strpos(sanitize_key($_GET['page']), 'fwcrm') === 0;
}

add_filter('admin_body_class', function ($c) {
    return fwcrm_is_crm_screen() ? $c . ' fwcrm-screen' . (function_exists('fwcrm_is_member') && fwcrm_is_member() ? ' fwcrm-member' : '') : $c;
});

add_action('admin_enqueue_scripts', function () {
    if (!fwcrm_is_crm_screen()) return;
    wp_enqueue_style('fwcrm-font', 'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300&display=swap', array(), null);
    wp_enqueue_style('fwcrm-admin', FWCRM_URL . 'assets/admin.css', array(), FWCRM_VERSION);
    wp_enqueue_script('fwcrm-admin', FWCRM_URL . 'assets/admin.js', array(), FWCRM_VERSION, true);
    wp_localize_script('fwcrm-admin', 'FWCRM', array('ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('fwcrm')));
});

/* ---------- Shared UI bits ---------- */

function fwcrm_header($title, $sub = '', $actions = '') {
    $st = get_option('fwcrm_mailbox_status', array());
    $ok = fwcrm_mailbox_ready() && !empty($st['ok']);
    $pill = fwcrm_mailbox_ready()
        ? ($ok ? '<span class="fw-pill ok"><i></i>Mailbox connected · synced ' . esc_html(fwcrm_time_ago(isset($st['at']) ? $st['at'] : '')) . '</span>' : '<span class="fw-pill bad"><i></i>Mailbox error: ' . esc_html(isset($st['msg']) ? $st['msg'] : 'not synced yet') . '</span>')
        : '<a class="fw-pill bad" href="' . esc_url(fwcrm_admin_url('fwcrm-settings')) . '"><i></i>Connect your mailbox →</a>';
    if (!fwcrm_mailbox_ready() && fwcrm_gmail_ready()) $pill = !empty($st['ok']) ? '<span class="fw-pill ok"><i></i>Gmail synced ' . esc_html(fwcrm_time_ago(isset($st['at']) ? $st['at'] : '')) . '</span>' : '<span class="fw-pill bad"><i></i>' . esc_html(isset($st['msg']) ? $st['msg'] : 'Gmail not synced yet') . '</span>';
    if (fwcrm_is_site_mode()) $pill = '<span class="fw-pill ok"><i></i>Tracker → ' . esc_html(fwcrm_hub_host()) . '</span>';
    $pill .= '<a class="fw-gear' . (isset($_GET['page']) && $_GET['page'] === 'fwcrm-settings' ? ' on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-settings')) . '" title="Settings"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg></a>';
    $pill .= '<a class="fw-wplink" href="' . esc_url(admin_url()) . '" title="WordPress admin">WP</a>';
    $tabs = array('fwcrm' => 'Today', 'fwcrm-inbox' => 'Inbox', 'fwcrm-contacts' => 'Leads', 'fwcrm-pipeline' => 'Pipeline', 'fwcrm-sequences' => 'Follow-ups', 'fwcrm-projects' => 'Projects', 'fwcrm-team' => 'Team', 'fwcrm-blog' => 'Blog', 'fwcrm-replies' => 'Replies', 'fwcrm-visitors' => 'Website', 'fwcrm-social' => 'Social', 'fwcrm-stats' => 'Stats', 'fwcrm-ai' => '✦ My AI');
    if (fwcrm_ai_key() === '') unset($tabs['fwcrm-ai']);
    if (fwcrm_is_site_mode()) $tabs = array('fwcrm-settings' => 'Settings');
    if (!fwcrm_is_site_mode() && isset($_GET['page']) && $_GET['page'] === 'fwcrm-settings') $tabs['fwcrm-settings'] = 'Settings';
    if (function_exists('fwcrm_is_member') && fwcrm_is_member()) {
        $tabs = array('fwcrm-my' => 'My work');
        $pill = '<a class="fw-wplink" href="' . esc_url(wp_logout_url(wp_login_url())) . '" title="Log out">Log out</a>';
    }
    $cur = sanitize_key($_GET['page']);
    echo '<div class="fw-app"><div class="fw-top"><div class="fw-brand"><span class="fw-mark">F<b>W</b></span><span class="fw-word">FELIXE<b>WEB</b> <em>HUB</em></span></div><nav class="fw-tabs">';
    foreach ($tabs as $slug => $label) {
        echo '<a class="' . ($slug === $cur ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url($slug)) . '">' . esc_html($label) . '</a>';
    }
    echo '</nav><button type="button" class="fw-searchbtn" data-fw-search title="Search (Ctrl + K)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/></svg><span>Search</span><kbd>Ctrl K</kbd></button>' . $pill . '</div>';
    if (!empty($_GET['fwmsg'])) {
        $type = !empty($_GET['fwerr']) ? 'err' : 'ok';
        echo '<div class="fw-toast ' . $type . '">' . esc_html(wp_unslash($_GET['fwmsg'])) . '</div>';
    }
    if (function_exists('fwcrm_update_banner')) echo fwcrm_update_banner();
    echo '<div class="fw-head"><div><h1>' . esc_html($title) . '</h1>' . ($sub ? '<p>' . wp_kses_post($sub) . '</p>' : '') . '</div><div class="fw-actions">' . $actions . '</div></div>';
}

function fwcrm_footer() {
    echo '</div>';
}

function fwcrm_lead_title($c) {
    $c = (object) $c;
    if (!empty($c->company)) return $c->company;
    return fwcrm_contact_name($c);
}

function fwcrm_site_host($url) {
    return $url ? preg_replace('#^www\.#', '', (string) wp_parse_url((strpos($url, '://') === false ? 'https://' : '') . $url, PHP_URL_HOST)) : '';
}

function fwcrm_site_link($c, $cls = 'fw-site', $span = false) {
    $c = (object) $c;
    if (empty($c->website)) return '';
    $url = strpos($c->website, '://') === false ? 'https://' . $c->website : $c->website;
    if ($span) return '<span class="' . esc_attr($cls) . '" role="link" tabindex="0" data-fw-href="' . esc_url($url) . '">' . esc_html(fwcrm_site_host($url)) . ' ↗</span>';
    return '<a class="' . esc_attr($cls) . '" href="' . esc_url($url) . '" target="_blank" rel="noopener" onclick="event.stopPropagation()">' . esc_html(fwcrm_site_host($url)) . ' ↗</a>';
}

function fwcrm_first_problem($c, $len = 110) {
    $c = (object) $c;
    $p = trim((string) (isset($c->problems) ? $c->problems : ''));
    if ($p === '') return '';
    $first = preg_split('/;\s+|\n/', $p)[0];
    return wp_html_excerpt($first, $len, '…');
}

function fwcrm_stage_pill($stage) {
    $st = fwcrm_stages();
    return '<span class="fw-stage s-' . esc_attr($stage) . '">' . esc_html(isset($st[$stage]) ? $st[$stage] : $stage) . '</span>';
}

function fwcrm_btn($label, $href, $class = '') {
    return '<a class="fw-btn ' . esc_attr($class) . '" href="' . esc_url($href) . '">' . esc_html($label) . '</a>';
}

function fwcrm_post_form_open($action, $extra = '') {
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" ' . $extra . '><input type="hidden" name="action" value="' . esc_attr($action) . '">' . wp_nonce_field('fwcrm_' . $action, '_fwnonce', true, false);
}

function fwcrm_activity_icons($c) {
    $out = '';
    $now = current_time('timestamp');
    foreach (array('last_open' => array('Opened', 'o'), 'last_click' => array('Clicked', 'k'), 'last_visit' => array('Visited site', 'v'), 'last_reply' => array('Replied', 'r')) as $f => $d) {
        if (!empty($c->$f)) {
            $fresh = ($now - strtotime($c->$f)) < 3 * DAY_IN_SECONDS ? ' fresh' : '';
            $out .= '<span class="fw-ic ic-' . $d[1] . $fresh . '" title="' . esc_attr($d[0] . ' ' . fwcrm_time_ago($c->$f)) . '"></span>';
        }
    }
    return $out ?: '<span class="fw-dim">—</span>';
}

/* ---------- Dashboard ---------- */

function fwcrm_page_dashboard() {
    global $wpdb;
    $T = 'fwcrm_t';
    $now = current_time('timestamp');
    $d30 = date('Y-m-d H:i:s', $now - 30 * DAY_IN_SECONDS);
    $d7 = date('Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS);
    $today = date('Y-m-d 00:00:00', $now);

    $sent30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='out' AND status='sent' AND kind IN ('email','followup') AND sent_at >= %s", $d30));
    $opened30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='out' AND source='crm' AND status='sent' AND opens > 0 AND sent_at >= %s", $d30));
    $crm30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='out' AND source='crm' AND status='sent' AND sent_at >= %s", $d30));
    $contacted30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$T('emails')} WHERE direction='out' AND status='sent' AND sent_at >= %s", $d30));
    $replied30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('contacts')} WHERE last_reply >= %s AND last_contacted IS NOT NULL", $d30));
    $waiting = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='in' AND kind='reply' AND handled=0");
    $due = fwcrm_followups_due(100);
    $active_seq = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('enrollments')} WHERE status='active'");
    $vis_today = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM {$T('visits')} WHERE created >= %s", $today));
    $vis7 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM {$T('visits')} WHERE created >= %s", $d7));
    $known7 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$T('visits')} WHERE contact_id > 0 AND created >= %s", $d7));
    $won = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('contacts')} WHERE stage='won'");
    $open_rate = $crm30 ? round($opened30 / $crm30 * 100) : 0;
    $reply_rate = $contacted30 ? round($replied30 / $contacted30 * 100) : 0;

    $hour = (int) date('G', $now);
    $greet = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
    $user = wp_get_current_user();
    $actions = fwcrm_btn('+ Add lead', fwcrm_admin_url('fwcrm-contacts', array('add' => 1)), 'gold')
        . '<button class="fw-btn" data-fw-ajax="fwcrm_sync_now">↻ Sync mailbox</button>';
    $ls = get_option('fwcrm_last_scout_sync');
    $scout_line = $ls ? ' Last scout update ' . esc_html(fwcrm_time_ago($ls['at'])) . ' (' . (int) $ls['added'] . ' new leads).' : '';
    fwcrm_header('Stats', 'Your outreach, replies, money and website in one place.' . $scout_line, $actions);

    echo '<div class="fw-kpis">';
    $k = array(
        array('Emails sent', $sent30, 'last 30 days'),
        array('Open rate', $crm30 ? $open_rate . '%' : '—', $crm30 ? 'CRM-sent emails' : 'tracked on CRM-sent emails'),
        array('Reply rate', $reply_rate . '%', $replied30 . ' of ' . $contacted30 . ' leads'),
        array('Replies waiting', $waiting, 'need your answer', $waiting ? 'hot' : ''),
        array('Follow-ups due', count($due), $active_seq . ' in auto sequences'),
        array('Site visitors', $vis7, $vis_today . ' today · ' . $known7 . ' known leads'),
        array('Pipeline value', fwcrm_money($wpdb->get_var("SELECT COALESCE(SUM(deal_value),0) FROM {$T('contacts')} WHERE stage IN ('call','proposal')")), (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('contacts')} WHERE stage IN ('call','proposal')") . ' in call / proposal'),
        array('Won this month', fwcrm_money($wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(deal_value),0) FROM {$T('contacts')} WHERE stage='won' AND won_at >= %s", date('Y-m-01 00:00:00', $now)))), $won . ' won all time', 'gold'),
    );
    foreach ($k as $x) {
        echo '<div class="fw-kpi ' . (isset($x[3]) ? $x[3] : '') . '"><span>' . esc_html($x[0]) . '</span><b>' . esc_html($x[1]) . '</b><small>' . esc_html($x[2]) . '</small></div>';
    }
    echo '</div>';

    // Chart: 14 days sent vs replies vs visitors
    $days = array();
    for ($i = 13; $i >= 0; $i--) $days[date('Y-m-d', $now - $i * DAY_IN_SECONDS)] = array('s' => 0, 'r' => 0, 'v' => 0);
    $from = date('Y-m-d 00:00:00', $now - 13 * DAY_IN_SECONDS);
    foreach ($wpdb->get_results($wpdb->prepare("SELECT DATE(sent_at) d, direction, kind, COUNT(*) n FROM {$T('emails')} WHERE sent_at >= %s AND ((direction='out' AND status='sent') OR (direction='in' AND kind='reply')) GROUP BY DATE(sent_at), direction, kind", $from)) as $r) {
        if (!isset($days[$r->d])) continue;
        if ($r->direction === 'out') $days[$r->d]['s'] += $r->n; else $days[$r->d]['r'] += $r->n;
    }
    foreach ($wpdb->get_results($wpdb->prepare("SELECT DATE(created) d, COUNT(DISTINCT visitor_id) n FROM {$T('visits')} WHERE created >= %s GROUP BY DATE(created)", $from)) as $r) {
        if (isset($days[$r->d])) $days[$r->d]['v'] = (int) $r->n;
    }
    $max = 1;
    foreach ($days as $d) $max = max($max, $d['s'], $d['r'], $d['v']);

    echo '<div class="fw-grid2">';
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Last 14 days</h2><div class="fw-legend"><i class="l-s"></i>Sent <i class="l-r"></i>Replies <i class="l-v"></i>Visitors</div></div><div class="fw-chart">';
    foreach ($days as $date => $d) {
        echo '<div class="fw-col" title="' . esc_attr(date_i18n('D j M', strtotime($date)) . ': ' . $d['s'] . ' sent, ' . $d['r'] . ' replies, ' . $d['v'] . ' visitors') . '"><div class="fw-bars"><i class="b-s" style="height:' . round($d['s'] / $max * 100) . '%"></i><i class="b-r" style="height:' . round($d['r'] / $max * 100) . '%"></i><i class="b-v" style="height:' . round($d['v'] / $max * 100) . '%"></i></div><small>' . esc_html(date_i18n('j', strtotime($date))) . '</small></div>';
    }
    echo '</div></div>';

    // Pipeline summary
    $counts = array();
    foreach ($wpdb->get_results("SELECT stage, COUNT(*) n FROM {$T('contacts')} GROUP BY stage") as $r) $counts[$r->stage] = (int) $r->n;
    $total = max(1, array_sum($counts));
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Pipeline</h2>' . fwcrm_btn('Open board', fwcrm_admin_url('fwcrm-pipeline'), 'sm') . '</div><div class="fw-funnel">';
    foreach (fwcrm_stages() as $key => $label) {
        $n = isset($counts[$key]) ? $counts[$key] : 0;
        echo '<a class="fw-frow" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('stage' => $key))) . '"><span>' . esc_html($label) . '</span><div class="fw-fbar"><i class="s-' . esc_attr($key) . '" style="width:' . max(2, round($n / $total * 100)) . '%"></i></div><b>' . $n . '</b></a>';
    }
    echo '</div></div></div>';

    // Attention lists
    echo '<div class="fw-grid2">';
    $replies = $wpdb->get_results("SELECT e.*, c.first_name, c.last_name, c.email, c.company FROM {$T('emails')} e JOIN {$T('contacts')} c ON c.id=e.contact_id WHERE e.direction='in' AND e.kind='reply' AND e.handled=0 ORDER BY e.sent_at DESC LIMIT 8");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Replies waiting for you</h2>' . fwcrm_btn('Inbox', fwcrm_admin_url('fwcrm-inbox'), 'sm') . '</div>';
    if (!$replies) echo '<div class="fw-empty">No replies waiting. New replies show up here within 5 minutes.</div>';
    foreach ($replies as $r) {
        echo '<a class="fw-item" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $r->contact_id))) . '"><div class="fw-av">' . esc_html(strtoupper(substr($r->first_name ?: $r->email, 0, 1))) . '</div><div class="fw-it"><b>' . esc_html(fwcrm_contact_name($r)) . ($r->company ? ' <em>· ' . esc_html($r->company) . '</em>' : '') . '</b><span>' . esc_html($r->subject) . '</span><small>' . esc_html(wp_html_excerpt($r->snippet, 120, '…')) . '</small></div><time>' . esc_html(fwcrm_time_ago($r->sent_at)) . '</time></a>';
    }
    echo '</div>';

    echo '<div class="fw-card"><div class="fw-card-h"><h2>Follow-ups due</h2><span class="fw-dim">not in an auto sequence</span></div>';
    if (!$due) echo '<div class="fw-empty">Nothing due. Leads you email from webmail get a follow-up date automatically.</div>';
    $seqs = fwcrm_get_sequences(true);
    foreach (array_slice($due, 0, 8) as $c) {
        echo '<div class="fw-item"><div class="fw-av">' . esc_html(strtoupper(substr($c->first_name ?: $c->email, 0, 1))) . '</div><div class="fw-it"><a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><b>' . esc_html(fwcrm_lead_title($c)) . '</b></a><small>Last emailed ' . esc_html(fwcrm_time_ago($c->last_contacted)) . ' · ' . fwcrm_activity_icons($c) . '</small></div><div class="fw-mini">';
        echo '<select data-fw-enroll="' . (int) $c->id . '"><option value="">Auto follow-up…</option>';
        foreach ($seqs as $s) echo '<option value="' . (int) $s->id . '">' . esc_html($s->name) . '</option>';
        echo '</select><button class="fw-btn sm" data-fw-ajax="fwcrm_snooze" data-id="' . (int) $c->id . '" title="Remind me in 3 days">Snooze</button><button class="fw-btn sm ghost" data-fw-ajax="fwcrm_clear_followup" data-id="' . (int) $c->id . '" title="No follow-up needed">✓</button></div></div>';
    }
    echo '</div></div>';

    echo '<div class="fw-grid2">';
    // Hot leads
    $hot = $wpdb->get_results("SELECT * FROM {$T('contacts')} WHERE stage NOT IN ('won','lost') AND unsubscribed=0 ORDER BY score DESC, GREATEST(COALESCE(last_click,'2000-01-01'),COALESCE(last_visit,'2000-01-01'),COALESCE(last_open,'2000-01-01')) DESC LIMIT 8");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Hottest leads</h2><span class="fw-dim">by engagement score</span></div>';
    if (!$hot) echo '<div class="fw-empty">Add or import leads to get started.</div>';
    foreach ($hot as $c) {
        echo '<a class="fw-item" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><div class="fw-score">' . (int) $c->score . '</div><div class="fw-it"><b>' . esc_html(fwcrm_lead_title($c)) . '</b><small>' . fwcrm_stage_pill($c->stage) . ' ' . fwcrm_activity_icons($c) . ($c->country ? ' · ' . esc_html($c->country) : '') . '</small></div></a>';
    }
    echo '</div>';

    // Recent activity
    echo '</div>';
    if (function_exists('fwcrm_render_insights')) fwcrm_render_insights();
    echo '<div class="fw-grid2">';
    $ev = $wpdb->get_results("SELECT e.*, c.first_name, c.last_name, c.email FROM {$T('events')} e LEFT JOIN {$T('contacts')} c ON c.id=e.contact_id WHERE e.type IN ('reply','open','click','visit','cta_click','sent','bounce','unsubscribe','inbound','enrolled','sequence_done') ORDER BY e.id DESC LIMIT 12");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Live activity</h2></div><div class="fw-feed">';
    if (!$ev) echo '<div class="fw-empty">Activity from emails and your website appears here.</div>';
    foreach ($ev as $e) {
        echo '<div class="fw-fi"><i class="fw-dot t-' . esc_attr($e->type) . '"></i><div>' . fwcrm_event_text($e) . '<small>' . esc_html(fwcrm_time_ago($e->created)) . '</small></div></div>';
    }
    echo '</div></div></div>';
    fwcrm_footer();
}

function fwcrm_event_text($e) {
    $m = $e->meta ? json_decode($e->meta, true) : array();
    $name = $e->contact_id ? '<a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $e->contact_id))) . '"><b>' . esc_html(fwcrm_contact_name($e)) . '</b></a>' : (!empty($e->email) ? '<b>' . esc_html(fwcrm_contact_name($e)) . '</b>' : 'Someone');
    switch ($e->type) {
        case 'sent': return $name . ' was emailed' . (!empty($m['via']) ? ($m['via'] === 'scout' ? ' by the scout' : ' (from webmail)') : '') . (!empty($m['subject']) ? ': <em>' . esc_html($m['subject']) . '</em>' : '');
        case 'open': return $name . ' opened <em>' . esc_html(isset($m['subject']) ? $m['subject'] : 'your email') . '</em>';
        case 'click': return $name . ' clicked <em>' . esc_html(isset($m['url']) ? preg_replace('#^https?://#', '', $m['url']) : 'a link') . '</em>';
        case 'reply': return $name . ' <b class="g">replied</b>' . (!empty($m['snippet']) ? ': “' . esc_html($m['snippet']) . '”' : '');
        case 'inbound': return $name . ' emailed you';
        case 'visit': return $name . ' visited <em>' . esc_html(isset($m['path']) ? $m['path'] : '/') . '</em>';
        case 'cta_click': return $name . ' clicked <em>' . esc_html(isset($m['label']) ? $m['label'] : 'a button') . '</em> on your site';
        case 'bounce': return $name . '’s email bounced';
        case 'unsubscribe': return $name . ' unsubscribed';
        case 'enrolled': return $name . ' started <em>' . esc_html(isset($m['sequence']) ? $m['sequence'] : 'a sequence') . '</em>';
        case 'sequence_done': return $name . ' finished <em>' . esc_html(isset($m['sequence']) ? $m['sequence'] : 'a sequence') . '</em> with no reply';
        case 'sequence_stopped': return 'Follow-ups stopped for ' . $name . ' (' . esc_html(isset($m['reason']) ? $m['reason'] : '') . ')';
        case 'stage': return $name . ' moved to ' . fwcrm_stage_pill(isset($m['to']) ? $m['to'] : '');
        case 'note': return 'Note on ' . $name . ': ' . esc_html(isset($m['text']) ? $m['text'] : '');
        case 'created': return $name . ' added (' . esc_html(isset($m['source']) ? $m['source'] : '') . ')';
        case 'auto_reply': return $name . ' sent an auto-reply';
        case 'send_failed': return 'Email to ' . $name . ' failed: ' . esc_html(isset($m['error']) ? $m['error'] : '');
        default: return $name . ' · ' . esc_html($e->type);
    }
}

/* ---------- Contacts ---------- */

function fwcrm_page_contacts() {
    if (!empty($_GET['view'])) return fwcrm_page_contact((int) $_GET['view']);
    if (!empty($_GET['add']) || !empty($_GET['import'])) return fwcrm_page_contact_add();
    global $wpdb;
    $T = 'fwcrm_t';
    $where = array('1=1');
    $args = array();
    $s = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    $stage = isset($_GET['stage']) ? sanitize_key($_GET['stage']) : '';
    $source = isset($_GET['source']) ? sanitize_key($_GET['source']) : '';
    if ($s !== '') {
        $like = '%' . $wpdb->esc_like($s) . '%';
        $where[] = '(email LIKE %s OR first_name LIKE %s OR last_name LIKE %s OR company LIKE %s OR tags LIKE %s OR niche LIKE %s OR country LIKE %s OR problems LIKE %s)';
        array_push($args, $like, $like, $like, $like, $like, $like, $like, $like);
    }
    $country = isset($_GET['country']) ? sanitize_text_field(wp_unslash($_GET['country'])) : '';
    $platform = isset($_GET['platform']) ? sanitize_text_field(wp_unslash($_GET['platform'])) : '';
    $closed = !empty($_GET['closed']);
    if ($stage) { $where[] = 'stage = %s'; $args[] = $stage; }
    elseif (!$closed) { $where[] = "stage <> 'lost'"; }
    $lane = isset($_GET['lane']) ? sanitize_key($_GET['lane']) : '';
    if (in_array($lane, array('web', 'video', 'book'), true)) { $where[] = 'lane = %s'; $args[] = $lane; }
    if ($source) { $where[] = 'source = %s'; $args[] = $source; }
    if ($country !== '') { $where[] = 'country LIKE %s'; $args[] = '%' . $wpdb->esc_like($country); }
    if ($platform !== '') { $where[] = 'platform LIKE %s'; $args[] = '%' . $wpdb->esc_like($platform) . '%'; }
    $sql = "SELECT * FROM {$T('contacts')} WHERE " . implode(' AND ', $where) . " ORDER BY COALESCE(last_reply, last_contacted, created) DESC LIMIT 500";
    $rows = $args ? $wpdb->get_results($wpdb->prepare($sql, $args)) : $wpdb->get_results($sql);
    $active = array();
    foreach ($wpdb->get_results("SELECT e.contact_id, s.name FROM {$T('enrollments')} e JOIN {$T('sequences')} s ON s.id=e.sequence_id WHERE e.status='active'") as $r) $active[$r->contact_id] = $r->name;

    $actions = fwcrm_btn('Import CSV', fwcrm_admin_url('fwcrm-contacts', array('import' => 1))) . fwcrm_btn('+ Add lead', fwcrm_admin_url('fwcrm-contacts', array('add' => 1)), 'gold');
    fwcrm_header('Leads', count($rows) . ' leads' . ($stage ? ' in ' . fwcrm_stage_pill($stage) : ''), $actions);

    echo fwcrm_lane_filter_html('fwcrm-contacts', array_filter(array('stage' => $stage, 's' => $s)));
    $nf = count(array_filter(array($stage, $source, $country, $platform, $closed ? '1' : '')));
    echo '<form class="fw-filters" method="get"><input type="hidden" name="page" value="fwcrm-contacts">' . ($lane ? '<input type="hidden" name="lane" value="' . esc_attr($lane) . '">' : '') . '<input type="search" name="s" placeholder="Search name, company, country, problem…" value="' . esc_attr($s) . '"><button type="button" class="fw-btn fw-ftoggle" onclick="this.form.classList.toggle(\'open\')">Filters' . ($nf ? ' · ' . $nf : '') . '</button><select name="stage"><option value="">All stages</option>';
    foreach (fwcrm_stages() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($stage, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select><select name="source"><option value="">All sources</option>';
    foreach (array('scout' => 'Scout (automatic)', 'scouting' => 'Scouting (webmail)', 'manual' => 'Added manually', 'import' => 'CSV import', 'inbound' => 'Inbound email') as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($source, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select>';
    $countries = array();
    foreach ($wpdb->get_col("SELECT DISTINCT country FROM {$T('contacts')} WHERE country <> ''") as $cn) { $bits = array_map('trim', explode(',', $cn)); $last = end($bits); if ($last !== '' && strlen($last) < 40) $countries[$last] = 1; }
    ksort($countries);
    echo '<select name="country"><option value="">All countries</option>';
    foreach (array_keys($countries) as $cn) echo '<option value="' . esc_attr($cn) . '"' . selected($country, $cn, false) . '>' . esc_html($cn) . '</option>';
    echo '</select><select name="platform"><option value="">All platforms</option>';
    $plats = array();
    foreach ($wpdb->get_col("SELECT DISTINCT platform FROM {$T('contacts')} WHERE platform <> ''") as $pl) { $pl = trim(preg_split('/[\/(,;]/', $pl)[0]); if ($pl !== '' && strlen($pl) < 30) $plats[$pl] = 1; }
    ksort($plats);
    foreach (array_keys($plats) as $pl) echo '<option value="' . esc_attr($pl) . '"' . selected($platform, $pl, false) . '>' . esc_html($pl) . '</option>';
    echo '</select><label class="fw-check inline"><input type="checkbox" name="closed" value="1"' . checked($closed, true, false) . ' onchange="this.form.submit()"> Show lost</label><button class="fw-btn">Filter</button>' . ($s || $stage || $source || $country || $platform || $closed ? '<a class="fw-link" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts')) . '">Clear</a>' : '') . '</form>';

    echo fwcrm_post_form_open('fwcrm_bulk', 'id="fw-bulk"');
    echo '<div class="fw-bulkbar"><span><b id="fw-selcount">0</b> selected</span><select name="bulk_action"><option value="">Bulk action…</option><optgroup label="Start auto follow-ups">';
    foreach (fwcrm_get_sequences(true) as $sq) echo '<option value="enroll:' . (int) $sq->id . '">' . esc_html($sq->name) . '</option>';
    echo '</optgroup><optgroup label="Move to stage">';
    foreach (fwcrm_stages() as $k => $l) echo '<option value="stage:' . esc_attr($k) . '">' . esc_html($l) . '</option>';
    echo '</optgroup><option value="tag">Add a tag…</option><option value="handled">Mark replies handled</option><option value="stop">Stop follow-ups</option><option value="delete">Delete</option></select><input name="bulk_tag" class="fw-bulktag" placeholder="Tag name" hidden><button class="fw-btn sm gold">Apply</button></div>';
    foreach (array('s' => $s, 'stage' => $stage, 'source' => $source, 'country' => $country, 'platform' => $platform, 'closed' => $closed ? '1' : '') as $k => $v) if ($v !== '') echo '<input type="hidden" name="f_' . $k . '" value="' . esc_attr($v) . '">';
    echo '<div class="fw-card fw-tablewrap"><table class="fw-table"><thead><tr><th><input type="checkbox" id="fw-all"></th><th>Lead</th><th>Stage</th><th>Activity</th><th>Last emailed</th><th>Next follow-up</th><th>Score</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="7"><div class="fw-empty">No leads yet. Add one, import a CSV, or connect your mailbox. Every scouting email you send is imported automatically.</div></td></tr>';
    foreach ($rows as $c) {
        $url = fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id));
        $flags = ($c->unsubscribed ? '<span class="fw-flag">unsubscribed</span>' : '') . ($c->bounced ? '<span class="fw-flag">bounced</span>' : '');
        $next = isset($active[$c->id]) ? '<span class="fw-auto" title="' . esc_attr($active[$c->id]) . '">⚡ ' . esc_html(fwcrm_time_ago($c->next_followup)) . '</span>' : ($c->next_followup ? '<span class="' . (strtotime($c->next_followup) <= current_time('timestamp') ? 'fw-due' : '') . '">' . esc_html(fwcrm_time_ago($c->next_followup)) . '</span>' : '<span class="fw-dim">—</span>');
        echo '<tr><td><input type="checkbox" name="ids[]" value="' . (int) $c->id . '"></td><td class="fw-leadcell"><a class="fw-lead" href="' . esc_url($url) . '"><div class="fw-av">' . esc_html(strtoupper(substr(fwcrm_lead_title($c), 0, 1))) . '</div><div><b>' . esc_html(fwcrm_lead_title($c)) . fwcrm_lane_chip($c) . '</b><small>' . esc_html(trim($c->first_name . ' ' . $c->last_name) ? trim($c->first_name . ' ' . $c->last_name) . ' · ' : '') . esc_html($c->email) . ($c->country ? ' · ' . esc_html($c->country) : '') . '</small></div></a>' . '<div class="fw-leadmeta">' . fwcrm_site_link($c) . (fwcrm_first_problem($c) ? '<span class="fw-probline">' . esc_html(fwcrm_first_problem($c)) . '</span>' : '') . '</div>' . $flags . '</td><td>' . fwcrm_stage_pill($c->stage) . '</td><td>' . fwcrm_activity_icons($c) . '</td><td>' . esc_html(fwcrm_time_ago($c->last_contacted)) . '</td><td>' . $next . '</td><td><span class="fw-score sm">' . (int) $c->score . '</span></td></tr>';
    }
    echo '</tbody></table></div></form>';
    fwcrm_footer();
}

function fwcrm_page_contact_add() {
    $import = !empty($_GET['import']);
    fwcrm_header($import ? 'Import leads' : 'Add a lead', $import ? 'Upload a CSV or paste rows. The first row must be headers: <code>email, first_name, last_name, company, website, niche, notes</code> (only email is required).' : 'Add someone you want to reach out to.');
    $seqs = fwcrm_get_sequences(true);
    echo '<div class="fw-grid2"><div class="fw-card">';
    if ($import) {
        echo fwcrm_post_form_open('fwcrm_import', 'enctype="multipart/form-data"');
        echo '<label class="fw-f"><span>CSV file</span><input type="file" name="csv" accept=".csv,text/csv"></label><label class="fw-f"><span>…or paste CSV here</span><textarea name="csv_text" rows="8" placeholder="email,first_name,company&#10;jane@brand.com,Jane,Brand Co"></textarea></label>';
    } else {
        echo fwcrm_post_form_open('fwcrm_add');
        echo '<div class="fw-row2"><label class="fw-f"><span>First name</span><input name="first_name"></label><label class="fw-f"><span>Last name</span><input name="last_name"></label></div>';
        echo '<label class="fw-f"><span>Email *</span><input type="email" name="email" required></label><div class="fw-row2"><label class="fw-f"><span>Company / brand</span><input name="company"></label><label class="fw-f"><span>Website</span><input name="website" placeholder="https://"></label></div>';
        echo '<div class="fw-row2"><label class="fw-f"><span>Niche</span><input name="niche" placeholder="e.g. research peptides"></label><label class="fw-f"><span>Stage</span><select name="stage">';
        foreach (fwcrm_stages() as $k => $l) echo '<option value="' . esc_attr($k) . '">' . esc_html($l) . '</option>';
        echo '</select></label></div><label class="fw-f"><span>Notes</span><textarea name="notes" rows="3"></textarea></label>';
    }
    echo '<label class="fw-f"><span>Start automatic emails</span><select name="enroll"><option value="">Don\'t send anything yet</option>';
    foreach ($seqs as $s) echo '<option value="' . (int) $s->id . '">' . esc_html($s->name) . '</option>';
    echo '</select><em>“Cold outreach” sends the first email in the next sending window, then follows up until they reply.</em></label>';
    echo '<button class="fw-btn gold">' . ($import ? 'Import leads' : 'Save lead') . '</button></form></div>';
    echo '<div class="fw-card fw-help"><h2>Tips</h2><ul><li>Leads you email from your normal webmail or phone are added automatically when the mailbox syncs, so you don\'t need to add them twice.</li><li>Follow-ups stop the moment someone replies, bounces or unsubscribes.</li><li>Use <code>{{first_name|there}}</code> and <code>{{company|your brand}}</code> in emails. The text after <code>|</code> is used when the field is empty.</li></ul></div></div>';
    fwcrm_footer();
}

function fwcrm_page_contact($id) {
    global $wpdb;
    $T = 'fwcrm_t';
    $c = fwcrm_get_contact($id);
    if (!$c) { fwcrm_header('Lead not found'); fwcrm_footer(); return; }
    $enr = $wpdb->get_row($wpdb->prepare("SELECT e.*, s.name, s.steps FROM {$T('enrollments')} e JOIN {$T('sequences')} s ON s.id=e.sequence_id WHERE e.contact_id=%d AND e.status='active' LIMIT 1", $id));
    $emails = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$T('emails')} WHERE contact_id=%d ORDER BY sent_at DESC LIMIT 100", $id));
    $events = $wpdb->get_results($wpdb->prepare("SELECT e.*, '' first_name, '' last_name, '' email FROM {$T('events')} e WHERE contact_id=%d AND type IN ('open','click','visit','cta_click','stage','note','enrolled','sequence_done','sequence_stopped','bounce','unsubscribe','created') ORDER BY id DESC LIMIT 100", $id));
    $visits = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$T('visits')} WHERE contact_id=%d ORDER BY id DESC LIMIT 30", $id));
    $last_in = null;
    foreach ($emails as $e) { if ($e->direction === 'in' && $e->kind === 'reply') { $last_in = $e; break; } }
    $last_out = null;
    foreach ($emails as $e) { if ($e->direction === 'out' && $e->status === 'sent') { $last_out = $e; break; } }

    $actions = fwcrm_btn('← All contacts', fwcrm_admin_url('fwcrm-contacts'));
    $person = trim($c->first_name . ' ' . $c->last_name);
    $sub = ($person && $c->company ? esc_html($person) . ' · ' : '') . '<a href="mailto:' . esc_attr($c->email) . '">' . esc_html($c->email) . '</a>' . ($c->country ? ' · ' . esc_html($c->country) : '') . ($c->platform ? ' · ' . esc_html($c->platform) : '');
    if ($c->website) $actions = fwcrm_site_link($c, 'fw-btn gold') . $actions;
    $actions = '<button class="fw-btn" data-fw-open="assign">+ Assign task</button><button class="fw-btn" data-fw-open="project">▶ Start project</button>' . $actions;
    fwcrm_header(fwcrm_lead_title($c) . ($c->lane === 'video' ? ' · Video lead' : ($c->lane === 'book' ? ' · Book lead' : '')), $sub, $actions);
    echo fwcrm_assign_dialog(0, $c->id) . fwcrm_project_dialog(null, $c->id);

    echo '<div class="fw-contact"><div class="fw-side">';
    // Stage + score
    echo '<div class="fw-card"><div class="fw-statline"><div><span>Stage</span><select data-fw-stage="' . (int) $c->id . '">';
    foreach (fwcrm_stages() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($c->stage, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select></div><div><span>Score</span><b class="fw-score">' . (int) $c->score . '</b></div></div>';
    echo '<div class="fw-facts">';
    foreach (array('Last emailed' => $c->last_contacted, 'Last opened' => $c->last_open, 'Last clicked' => $c->last_click, 'Last site visit' => $c->last_visit, 'Last reply' => $c->last_reply) as $l => $v) echo '<div><span>' . esc_html($l) . '</span><b>' . esc_html(fwcrm_time_ago($v)) . '</b></div>';
    echo '</div>';
    if ($c->unsubscribed) echo '<div class="fw-warn">Unsubscribed. No emails will be sent.</div>';
    if ($c->bounced) echo '<div class="fw-warn">This address bounced. <button class="fw-link" data-fw-ajax="fwcrm_unbounce" data-id="' . (int) $c->id . '">Mark as valid</button></div>';
    echo '<label class="fw-deal"><span>Deal value</span><input inputmode="decimal" data-fw-deal="' . (int) $c->id . '" value="' . esc_attr((float) $c->deal_value ? rtrim(rtrim(number_format((float) $c->deal_value, 2, '.', ''), '0'), '.') : '') . '" placeholder="$0"></label>';
    echo '</div>';
    $ctasks = fwcrm_open_tasks($c->id, 20);
    echo '<div class="fw-card fw-ctasks"><div class="fw-card-h"><h3>Tasks &amp; promises</h3><button class="fw-btn sm" data-fw-open="task">+ Task</button></div>';
    if (!$ctasks) echo '<p class="fw-dim">Nothing open.</p>';
    foreach ($ctasks as $t) echo fwcrm_task_row($t);
    echo '</div>' . fwcrm_task_modal($c->id);

    // Automation box
    echo '<div class="fw-card"><h3>Automatic follow-ups</h3>';
    if ($enr) {
        $steps = json_decode($enr->steps, true) ?: array();
        echo '<p class="fw-auto big">⚡ ' . esc_html($enr->name) . '</p><p class="fw-dim">Step ' . ((int) $enr->current_step + 1) . ' of ' . count($steps) . ' · next email ' . esc_html(fwcrm_time_ago($enr->next_run)) . ' (' . esc_html(date_i18n('D j M, H:i', strtotime($enr->next_run))) . ')</p>';
        echo '<div class="fw-btnrow"><button class="fw-btn sm" data-fw-ajax="fwcrm_send_next" data-id="' . (int) $c->id . '">Send next one now</button><button class="fw-btn sm ghost" data-fw-ajax="fwcrm_stop" data-id="' . (int) $c->id . '">Stop</button></div>';
    } else {
        echo '<p class="fw-dim">' . ($c->next_followup ? 'Manual follow-up due ' . esc_html(fwcrm_time_ago($c->next_followup)) . '.' : 'Not in a sequence.') . '</p><select data-fw-enroll="' . (int) $c->id . '"><option value="">Start a sequence…</option>';
        foreach (fwcrm_get_sequences(true) as $s) echo '<option value="' . (int) $s->id . '">' . esc_html($s->name) . '</option>';
        echo '</select>';
    }
    echo '</div>';

    // Details form
    echo '<div class="fw-card"><h3>Details</h3>' . fwcrm_post_form_open('fwcrm_save_contact') . '<input type="hidden" name="id" value="' . (int) $c->id . '">';
    foreach (array('first_name' => 'First name', 'last_name' => 'Last name', 'email' => 'Email', 'company' => 'Company', 'website' => 'Website', 'phone' => 'Phone / WhatsApp', 'country' => 'Country / city', 'platform' => 'Store platform', 'niche' => 'Niche', 'tags' => 'Tags (comma separated)') as $f => $l) {
        echo '<label class="fw-f sm"><span>' . esc_html($l) . '</span><input name="' . esc_attr($f) . '" value="' . esc_attr($c->$f) . '"></label>';
    }
    echo '<label class="fw-f sm"><span>Notes</span><textarea name="notes" rows="4">' . esc_textarea($c->notes) . '</textarea></label><div class="fw-btnrow"><button class="fw-btn sm gold">Save</button></div></form>';
    echo fwcrm_post_form_open('fwcrm_delete_contact', 'onsubmit="return confirm(\'Delete this lead and all its history?\')"') . '<input type="hidden" name="id" value="' . (int) $c->id . '"><button class="fw-link danger">Delete lead</button></form></div>';
    echo '</div>';

    // Main: compose + timeline
    echo '<div class="fw-main">';
    if (trim((string) $c->problems) !== '') {
        echo '<div class="fw-card fw-problems"><div class="fw-card-h"><h3>Problems found on their store</h3>' . ($c->platform ? '<span class="fw-stage">' . esc_html($c->platform) . '</span>' : '') . '</div><ul>';
        foreach (array_filter(array_map('trim', preg_split('/;\s+|\n/', $c->problems))) as $pr) echo '<li>' . esc_html($pr) . '</li>';
        echo '</ul></div>';
    }
    echo '<div class="fw-card fw-chatcard">';
    fwcrm_render_chat($c, 'contact');
    echo fwcrm_post_form_open('fwcrm_note', 'class="fw-noteform"') . '<input type="hidden" name="id" value="' . (int) $c->id . '"><input name="note" placeholder="Add a quick note (call outcome, budget, next step)…"><button class="fw-btn sm">Add note</button></form></div>';

    if ($visits) {
        echo '<div class="fw-card"><h3>Website visits</h3><table class="fw-table mini"><tbody>';
        foreach ($visits as $v) echo '<tr><td>' . esc_html($v->path) . '</td><td>' . esc_html($v->title) . '</td><td>' . ($v->duration ? esc_html(gmdate($v->duration >= 3600 ? 'G\h i\m' : 'i:s', $v->duration)) : '—') . '</td><td>' . esc_html(fwcrm_time_ago($v->created)) . '</td></tr>';
        echo '</tbody></table></div>';
    }
    echo '</div></div>';
    fwcrm_footer();
}

/* ---------- Pipeline (kanban) ---------- */

function fwcrm_page_pipeline() {
    global $wpdb;
    $lane = isset($_GET['lane']) ? sanitize_key($_GET['lane']) : '';
    $lw = in_array($lane, array('web', 'video', 'book'), true) ? $wpdb->prepare(' WHERE lane = %s', $lane) : '';
    $rows = $wpdb->get_results("SELECT * FROM " . fwcrm_t('contacts') . $lw . " ORDER BY score DESC, updated DESC LIMIT 1000");
    $by = array();
    foreach ($rows as $r) $by[$r->stage][] = $r;
    fwcrm_header('Pipeline', 'Drag a card to move a lead. Leads move forward automatically when they open, reply or book.', fwcrm_btn('+ Add lead', fwcrm_admin_url('fwcrm-contacts', array('add' => 1)), 'gold'));
    echo fwcrm_lane_filter_html('fwcrm-pipeline');
    echo '<div class="fw-board">';
    foreach (fwcrm_stages() as $k => $l) {
        $list = isset($by[$k]) ? $by[$k] : array();
        $sum = array_sum(array_map(function ($x) { return (float) $x->deal_value; }, $list));
        echo '<div class="fw-lane' . (!$list ? ' empty' : '') . '" data-stage="' . esc_attr($k) . '"><div class="fw-lane-h"><span class="fw-stage s-' . esc_attr($k) . '">' . esc_html($l) . '</span>' . ($sum ? '<em class="fw-lane-sum">' . esc_html(fwcrm_money($sum)) . '</em>' : '') . '<b>' . count($list) . '</b></div><div class="fw-drop">';
        foreach ($list as $c) {
            $prob = fwcrm_first_problem($c, 90);
            echo '<a class="fw-kcard" draggable="true" data-id="' . (int) $c->id . '" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><b>' . esc_html(fwcrm_lead_title($c)) . fwcrm_lane_chip($c) . '</b><small>' . esc_html(trim($c->first_name . ' ' . $c->last_name) ?: $c->email) . '</small>' . fwcrm_site_link($c, 'fw-site', true) . ($prob ? '<p class="fw-kprob">' . esc_html($prob) . '</p>' : '') . '<div>' . ($c->country ? '<span class="fw-chipc">' . esc_html(wp_html_excerpt($c->country, 22, '…')) . '</span>' : '') . fwcrm_activity_icons($c) . ((float) $c->deal_value ? '<span class="fw-val">' . esc_html(fwcrm_money($c->deal_value)) . '</span>' : '') . '<span class="fw-score sm">' . (int) $c->score . '</span></div></a>';
        }
        echo '</div></div>';
    }
    echo '</div>';
    fwcrm_footer();
}

/* ---------- Inbox ---------- */

function fwcrm_page_inbox() {
    global $wpdb;
    $T = 'fwcrm_t';
    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'waiting';
    $q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
    fwcrm_header('Inbox', 'Every email conversation with your leads, like a chat. Pulled from hello@ every 5 minutes.', '<button class="fw-btn" data-fw-ajax="fwcrm_sync_now">↻ Check now</button>');
    echo '<div class="fw-subtabs">';
    foreach (array('waiting' => 'Needs reply', 'replied' => 'Replied', 'all' => 'All chats', 'other' => 'Auto-replies & bounces') as $k => $l) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', array('tab' => $k))) . '">' . esc_html($l) . '</a>';
    echo '</div>';

    if ($tab === 'other') {
        $rows = $wpdb->get_results("SELECT e.*, c.first_name, c.last_name, c.email, c.company, c.stage FROM {$T('emails')} e JOIN {$T('contacts')} c ON c.id=e.contact_id WHERE e.direction='in' AND e.kind IN ('auto_reply','bounce') ORDER BY e.sent_at DESC LIMIT 200");
        echo '<div class="fw-card">';
        if (!$rows) echo '<div class="fw-empty">Nothing here yet.</div>';
        foreach ($rows as $r) echo '<div class="fw-msg"><div class="fw-av">' . esc_html(strtoupper(substr($r->company ?: $r->email, 0, 1))) . '</div><div class="fw-it"><div class="fw-msg-h"><a href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $r->contact_id))) . '"><b>' . esc_html($r->company ?: fwcrm_contact_name($r)) . '</b></a> <span class="fw-stage">' . ($r->kind === 'bounce' ? 'Bounce' : 'Auto-reply') . '</span><time>' . esc_html(date_i18n('D j M, H:i', strtotime($r->sent_at))) . '</time></div><p>' . esc_html(wp_html_excerpt($r->body ?: $r->snippet, 300, '…')) . '</p></div></div>';
        echo '</div>';
        fwcrm_footer();
        return;
    }

    $convs = fwcrm_conversations($tab, $q);
    $sel = isset($_GET['c']) ? (int) $_GET['c'] : 0;
    $current = $sel ? fwcrm_get_contact($sel) : ($convs ? fwcrm_get_contact($convs[0]->id) : null);
    echo '<div class="fw-messenger' . ($sel ? ' open' : '') . '"><div class="fw-clist">';
    echo '<form class="fw-csearch" method="get"><input type="hidden" name="page" value="fwcrm-inbox"><input type="hidden" name="tab" value="' . esc_attr($tab) . '"><input type="search" name="q" value="' . esc_attr($q) . '" placeholder="Search business, name or email…"></form>';
    if (!$convs) echo '<div class="fw-empty">' . ($tab === 'waiting' ? 'You\'re all caught up. No replies waiting.' : 'No conversations yet.') . '</div>';
    foreach ($convs as $r) {
        $prev = $r->last ? ($r->last->direction === 'out' ? 'You: ' : '') . wp_html_excerpt(preg_replace('/\s+/', ' ', fwcrm_clean_text($r->last->body ?: $r->last->snippet)), 70, '…') : '';
        $on = $current && (int) $current->id === (int) $r->id;
        echo '<a class="fw-conv' . ($on ? ' on' : '') . ($r->unread ? ' unread' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', array_filter(array('tab' => $tab, 'q' => $q, 'c' => $r->id)))) . '"><div class="fw-av">' . esc_html(strtoupper(mb_substr(fwcrm_lead_title($r), 0, 1))) . '</div><div class="fw-conv-t"><div><b>' . esc_html(fwcrm_lead_title($r)) . '</b><time>' . esc_html(fwcrm_time_ago($r->last_at)) . '</time></div><p>' . esc_html($prev) . '</p></div>' . ($r->unread ? '<span class="fw-badge">' . (int) $r->unread . '</span>' : '') . '</a>';
    }
    echo '</div><div class="fw-cpane">';
    if ($current) fwcrm_render_chat($current, 'inbox');
    else echo '<div class="fw-chat-empty">Pick a conversation.</div>';
    echo '</div></div>';
    fwcrm_footer();
}

/* ---------- Sequences ---------- */

function fwcrm_page_sequences() {
    global $wpdb;
    $T = 'fwcrm_t';
    if (isset($_GET['edit'])) return fwcrm_page_sequence_edit((int) $_GET['edit']);
    $seqs = fwcrm_get_sequences();
    fwcrm_header('Follow-up sequences', 'Automatic emails that stop the moment a lead replies, bounces or unsubscribes. Sent only on your sending days and hours, max ' . (int) fwcrm_opt('daily_cap') . ' per day.', fwcrm_btn('+ New sequence', fwcrm_admin_url('fwcrm-sequences', array('edit' => 0)), 'gold') . '<button class="fw-btn" data-fw-ajax="fwcrm_run_now">▶ Run due emails now</button>');
    $auto = (int) fwcrm_opt('auto_enroll_seq');
    echo '<div class="fw-cards3">';
    foreach ($seqs as $s) {
        $st = array();
        foreach ($wpdb->get_results($wpdb->prepare("SELECT status, COUNT(*) n FROM {$T('enrollments')} WHERE sequence_id=%d GROUP BY status", $s->id)) as $r) $st[$r->status] = (int) $r->n;
        $total = array_sum($st);
        $replied = isset($st['replied']) ? $st['replied'] : 0;
        $rr = $total ? round($replied / $total * 100) : 0;
        echo '<div class="fw-card fw-seq"><div class="fw-card-h"><h2>' . esc_html($s->name) . '</h2><span class="fw-pill ' . ($s->active ? 'ok' : '') . '"><i></i>' . ($s->active ? 'Active' : 'Paused') . '</span></div>';
        if ($auto === (int) $s->id) echo '<p class="fw-auto">⚡ Auto-starts for every new scouting email you send</p>';
        echo '<div class="fw-steps">';
        $acc = 0;
        foreach ($s->steps_arr as $i => $step) {
            $acc += (float) $step['delay_days'];
            echo '<div class="fw-step"><i>' . ($i + 1) . '</i><div><b>' . esc_html($step['subject'] !== '' ? fwcrm_merge($step['subject'], array()) : 'Reply in thread') . '</b><small>Day ' . esc_html(rtrim(rtrim(number_format($acc, 1), '0'), '.')) . ' · ' . esc_html(wp_html_excerpt(str_replace("\n", ' ', $step['body']), 90, '…')) . '</small></div></div>';
        }
        echo '</div><div class="fw-seqstats"><div><b>' . (isset($st['active']) ? $st['active'] : 0) . '</b><span>in progress</span></div><div><b>' . $replied . '</b><span>replied</span></div><div><b>' . $rr . '%</b><span>reply rate</span></div></div><div class="fw-btnrow">' . fwcrm_btn('Edit', fwcrm_admin_url('fwcrm-sequences', array('edit' => $s->id)), 'sm') . '</div></div>';
    }
    echo '</div>';
    fwcrm_footer();
}

function fwcrm_page_sequence_edit($id) {
    $s = $id ? fwcrm_get_sequence($id) : null;
    $steps = $s ? $s->steps_arr : array(array('delay_days' => 0, 'subject' => 'Quick idea for {{company|your store}}', 'body' => "Hi {{first_name|there}},\n\n"), array('delay_days' => 3, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\n"));
    fwcrm_header($s ? 'Edit sequence' : 'New sequence', 'Leave a step\'s subject empty to reply in the same thread (best for follow-ups). Variables: <code>{{first_name|there}}</code> <code>{{company|your brand}}</code> <code>{{website}}</code> <code>{{sender_name}}</code>', fwcrm_btn('← Back', fwcrm_admin_url('fwcrm-sequences')));
    echo fwcrm_post_form_open('fwcrm_save_sequence', 'id="fw-seqform"') . '<input type="hidden" name="id" value="' . (int) $id . '"><div class="fw-card"><div class="fw-row2"><label class="fw-f"><span>Name</span><input name="name" value="' . esc_attr($s ? $s->name : '') . '" required></label><label class="fw-f"><span>Status</span><select name="active"><option value="1"' . selected(!$s || $s->active, true, false) . '>Active</option><option value="0"' . selected($s && !$s->active, true, false) . '>Paused</option></select></label></div>';
    echo '<label class="fw-check"><input type="checkbox" name="auto_enroll" value="1"' . checked($s && (int) fwcrm_opt('auto_enroll_seq') === (int) $s->id, true, false) . '> Start this automatically for every new scouting email I send from webmail (only one sequence can do this)</label></div><div id="fw-steplist">';
    foreach ($steps as $i => $st) fwcrm_step_html($i, $st);
    echo '</div><template id="fw-steptpl">';
    fwcrm_step_html('__i__', array('delay_days' => 3, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\n"));
    echo '</template><div class="fw-btnrow"><button type="button" class="fw-btn" id="fw-addstep">+ Add step</button><button class="fw-btn gold">Save sequence</button></div></form>';
    if ($s) echo fwcrm_post_form_open('fwcrm_delete_sequence', 'onsubmit="return confirm(\'Delete this sequence? Leads in it will stop receiving its emails.\')"') . '<input type="hidden" name="id" value="' . (int) $s->id . '"><button class="fw-link danger">Delete sequence</button></form>';
    fwcrm_footer();
}

function fwcrm_step_html($i, $st) {
    echo '<div class="fw-card fw-stepedit"><div class="fw-card-h"><h3>Step <span class="fw-stepno"></span></h3><button type="button" class="fw-link danger fw-rmstep">Remove</button></div><div class="fw-row3"><label class="fw-f"><span>Wait (days after previous email)</span><input type="number" step="0.5" min="0" name="steps[' . esc_attr($i) . '][delay_days]" value="' . esc_attr($st['delay_days']) . '"></label><label class="fw-f wide"><span>Subject (empty = reply in thread)</span><input name="steps[' . esc_attr($i) . '][subject]" value="' . esc_attr($st['subject']) . '"></label></div><label class="fw-f"><span>Email</span><textarea rows="7" name="steps[' . esc_attr($i) . '][body]">' . esc_textarea($st['body']) . '</textarea></label></div>';
}

/* ---------- Visitors ---------- */

function fwcrm_page_visitors() {
    global $wpdb;
    $T = 'fwcrm_t';
    $range = isset($_GET['range']) ? (int) $_GET['range'] : 7;
    if (!in_array($range, array(1, 7, 30, 90), true)) $range = 7;
    $from = date('Y-m-d H:i:s', current_time('timestamp') - $range * DAY_IN_SECONDS);
    $visitors = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM {$T('visits')} WHERE created >= %s", $from));
    $sessions = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT session_id) FROM {$T('visits')} WHERE created >= %s", $from));
    $views = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('visits')} WHERE created >= %s", $from));
    $avg = (int) $wpdb->get_var($wpdb->prepare("SELECT AVG(t) FROM (SELECT SUM(duration) t FROM {$T('visits')} WHERE created >= %s GROUP BY session_id) x", $from));
    $known = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$T('visits')} WHERE contact_id>0 AND created >= %s", $from));
    $cta = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT session_id) FROM {$T('visits')} WHERE clicked_cta=1 AND created >= %s", $from));

    $tabs = '';
    foreach (array(1 => 'Today', 7 => '7 days', 30 => '30 days', 90 => '90 days') as $k => $l) $tabs .= '<a class="fw-btn sm ' . ($k === $range ? 'gold' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-visitors', array('range' => $k))) . '">' . esc_html($l) . '</a>';
    fwcrm_header('Website visitors', 'Privacy-friendly analytics for ' . esc_html(wp_parse_url(home_url(), PHP_URL_HOST)) . '. Leads who click your emails are recognised by name.', $tabs);
    echo '<div class="fw-kpis">';
    foreach (array(array('Visitors', $visitors), array('Visits', $sessions), array('Page views', $views), array('Avg. visit time', $avg ? gmdate($avg >= 3600 ? 'G\h i\m' : 'i:s', $avg) : '0:00'), array('Known leads', $known), array('Clicked “Book a call”', $cta)) as $k) echo '<div class="fw-kpi"><span>' . esc_html($k[0]) . '</span><b>' . esc_html($k[1]) . '</b></div>';
    echo '</div>';

    $top = $wpdb->get_results($wpdb->prepare("SELECT path, COUNT(*) n, COUNT(DISTINCT visitor_id) u FROM {$T('visits')} WHERE created >= %s GROUP BY path ORDER BY n DESC LIMIT 10", $from));
    $refs = $wpdb->get_results($wpdb->prepare("SELECT CASE WHEN utm_source<>'' THEN utm_source WHEN ref_host<>'' THEN ref_host ELSE 'Direct / none' END src, COUNT(DISTINCT session_id) n FROM {$T('visits')} WHERE created >= %s GROUP BY src ORDER BY n DESC LIMIT 10", $from));
    $dev = $wpdb->get_results($wpdb->prepare("SELECT device, COUNT(DISTINCT session_id) n FROM {$T('visits')} WHERE created >= %s GROUP BY device ORDER BY n DESC", $from));
    $cty = $wpdb->get_results($wpdb->prepare("SELECT country, COUNT(DISTINCT visitor_id) n FROM {$T('visits')} WHERE created >= %s AND country<>'' GROUP BY country ORDER BY n DESC LIMIT 8", $from));
    echo '<div class="fw-grid3">';
    fwcrm_bars_card('Top pages', $top, 'path', 'n');
    fwcrm_bars_card('Traffic sources', $refs, 'src', 'n');
    echo '<div>';
    fwcrm_bars_card('Devices', $dev, 'device', 'n');
    if ($cty) fwcrm_bars_card('Countries', $cty, 'country', 'n');
    echo '</div></div>';

    $sess = $wpdb->get_results($wpdb->prepare("SELECT session_id, visitor_id, MAX(contact_id) contact_id, MIN(created) started, COUNT(*) pages, SUM(duration) dur, MAX(clicked_cta) cta, SUBSTRING_INDEX(GROUP_CONCAT(path ORDER BY id SEPARATOR '|'),'|',6) paths, MAX(ref_host) ref_host, MAX(utm_source) utm, MAX(device) device, MAX(country) country FROM {$T('visits')} WHERE created >= %s GROUP BY session_id ORDER BY started DESC LIMIT 100", $from));
    echo '<div class="fw-card fw-tablewrap"><div class="fw-card-h"><h2>Recent visits</h2></div><table class="fw-table"><thead><tr><th>Visitor</th><th>Pages</th><th>Source</th><th>Time on site</th><th>When</th></tr></thead><tbody>';
    if (!$sess) echo '<tr><td colspan="5"><div class="fw-empty">No visits recorded yet. Tracking starts as soon as the plugin is active (your own visits while logged in are not counted).</div></td></tr>';
    foreach ($sess as $v) {
        $who = '<span class="fw-dim">Anonymous</span>';
        if ($v->contact_id) {
            $c = fwcrm_get_contact($v->contact_id);
            if ($c) $who = '<a class="fw-lead" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><div class="fw-av gold">' . esc_html(strtoupper(substr($c->first_name ?: $c->email, 0, 1))) . '</div><div><b>' . esc_html(fwcrm_contact_name($c)) . '</b><small>' . esc_html($c->company) . '</small></div></a>';
        }
        $meta = trim(($v->country ? $v->country . ' · ' : '') . $v->device);
        echo '<tr><td>' . $who . '<small class="fw-dim">' . esc_html($meta) . '</small>' . ($v->cta ? ' <span class="fw-ok">clicked CTA</span>' : '') . '</td><td><small>' . esc_html(str_replace('|', ' → ', $v->paths)) . '</small></td><td>' . esc_html($v->utm ?: ($v->ref_host ?: 'Direct')) . '</td><td>' . esc_html($v->dur ? gmdate($v->dur >= 3600 ? 'G\h i\m' : 'i:s', $v->dur) : '<0:05') . '</td><td>' . esc_html(fwcrm_time_ago($v->started)) . '</td></tr>';
    }
    echo '</tbody></table></div>';
    fwcrm_footer();
}

function fwcrm_bars_card($title, $rows, $label, $val) {
    $max = 1;
    foreach ($rows as $r) $max = max($max, (int) $r->$val);
    echo '<div class="fw-card"><h2>' . esc_html($title) . '</h2><div class="fw-hbars">';
    if (!$rows) echo '<div class="fw-empty sm">No data yet</div>';
    foreach ($rows as $r) echo '<div class="fw-hb"><span>' . esc_html($r->$label ?: '—') . '</span><b>' . (int) $r->$val . '</b><i style="width:' . round($r->$val / $max * 100) . '%"></i></div>';
    echo '</div></div>';
}

/* ---------- Settings ---------- */

function fwcrm_page_settings() {
    $s = fwcrm_settings();
    $st = get_option('fwcrm_mailbox_status', array());
    fwcrm_header('Settings', 'Connect your mailbox and tune how the CRM sends and tracks.');
    echo fwcrm_post_form_open('fwcrm_save_settings') . '<div class="fw-grid2"><div>';

    echo '<div class="fw-card"><h2>1 · Your mailbox</h2><p class="fw-dim">The account your outreach emails are sent from. The password is stored encrypted and never shown again.</p>';
    echo '<div class="fw-row2"><label class="fw-f"><span>From name</span><input name="from_name" value="' . esc_attr($s['from_name']) . '"></label><label class="fw-f"><span>From email</span><input name="from_email" value="' . esc_attr($s['from_email']) . '"></label></div>';
    echo '<div class="fw-row2"><label class="fw-f"><span>Mailbox login (usually the same email)</span><input name="mail_user" value="' . esc_attr($s['mail_user']) . '" autocomplete="off"></label><label class="fw-f"><span>Mailbox password</span><input type="password" name="mail_pass" value="" placeholder="' . (fwcrm_mail_pass() !== '' ? '•••••••• saved (type to change)' : 'Enter your email password') . '" autocomplete="new-password"></label></div>';
    echo '<details class="fw-adv"><summary>Server settings (Hostinger defaults)</summary><div class="fw-row3"><label class="fw-f"><span>SMTP host</span><input name="smtp_host" value="' . esc_attr($s['smtp_host']) . '"></label><label class="fw-f"><span>SMTP port</span><input name="smtp_port" value="' . esc_attr($s['smtp_port']) . '"></label><label class="fw-f"><span>Security</span><select name="smtp_secure"><option value="ssl"' . selected($s['smtp_secure'], 'ssl', false) . '>SSL</option><option value="tls"' . selected($s['smtp_secure'], 'tls', false) . '>TLS</option></select></label></div><div class="fw-row3"><label class="fw-f"><span>IMAP host</span><input name="imap_host" value="' . esc_attr($s['imap_host']) . '"></label><label class="fw-f"><span>IMAP port</span><input name="imap_port" value="' . esc_attr($s['imap_port']) . '"></label><label class="fw-f"><span>Sent folder</span><input name="sent_folder" value="' . esc_attr($s['sent_folder']) . '" placeholder="auto-detect"></label></div><label class="fw-f"><span>Reply-To (optional)</span><input name="reply_to" value="' . esc_attr($s['reply_to']) . '"></label></details>';
    echo '<div class="fw-btnrow"><button type="button" class="fw-btn" data-fw-ajax="fwcrm_test_mailbox">Test connection</button><button type="button" class="fw-btn" data-fw-ajax="fwcrm_test_send">Send me a test email</button></div>';
    if (!empty($st['at'])) echo '<p class="fw-dim">Last sync ' . esc_html(fwcrm_time_ago($st['at'])) . ': ' . esc_html($st['msg']) . '</p>';
    echo '</div>';

    echo '<div class="fw-card"><h2>2 · Importing your scouting emails</h2><label class="fw-check"><input type="checkbox" name="import_sent" value="1"' . checked($s['import_sent'], 1, false) . '> Add everyone I email from webmail/phone as a lead and track their replies</label><div class="fw-row2"><label class="fw-f"><span>On first connect, import the last … days</span><input type="number" name="import_days" min="1" max="365" value="' . esc_attr($s['import_days']) . '"></label><label class="fw-f"><span>Remind me to follow up after … days</span><input type="number" name="followup_days" min="1" max="60" value="' . esc_attr($s['followup_days']) . '"></label></div><label class="fw-f"><span>Never import these domains/emails (clients, friends, services)</span><textarea name="ignore_domains" rows="2" placeholder="fiverr.com, hostinger.com, mum@gmail.com">' . esc_textarea($s['ignore_domains']) . '</textarea></label><label class="fw-f"><span>Start this sequence automatically for each new scouting email</span><select name="auto_enroll_seq"><option value="0">Off, just remind me</option>';
    foreach (fwcrm_get_sequences() as $q) echo '<option value="' . (int) $q->id . '"' . selected((int) $s['auto_enroll_seq'], (int) $q->id, false) . '>' . esc_html($q->name) . '</option>';
    echo '</select></label><label class="fw-check"><input type="checkbox" name="save_to_sent" value="1"' . checked($s['save_to_sent'], 1, false) . '> Save CRM-sent emails into my Sent folder too</label></div>';
    echo '<div class="fw-card" id="gmail"><h2>Gmail used by your scout</h2><p class="fw-dim">Your scout tasks send from Gmail as ' . esc_html($s['from_email']) . '. Connect that Gmail so the hub sees every scout email and every reply. Use a Google <b>app password</b> (Google Account → Security → 2-Step Verification → App passwords), not your normal password. Only emails sent as the address below are imported; your personal mail is ignored.</p><label class="fw-check"><input type="checkbox" name="gmail_enabled" value="1"' . checked($s['gmail_enabled'], 1, false) . '> Sync this Gmail</label><div class="fw-row2"><label class="fw-f"><span>Gmail address</span><input name="gmail_user" value="' . esc_attr($s['gmail_user']) . '" autocomplete="off"></label><label class="fw-f"><span>App password</span><input type="password" name="gmail_pass" value="" placeholder="' . (fwcrm_decrypt($s['gmail_pass']) !== '' ? '•••••••• saved (type to change)' : '16-character app password') . '" autocomplete="new-password"></label></div><div class="fw-row2"><label class="fw-f"><span>Only import emails sent as</span><input name="gmail_from_filter" value="' . esc_attr($s['gmail_from_filter']) . '"></label><label class="fw-f"><span>On first connect, import the last … days</span><input type="number" name="gmail_import_days" min="1" max="365" value="' . esc_attr($s['gmail_import_days']) . '"></label></div></div>';
    echo '</div><div>';

    echo '<div class="fw-card"><h2>3 · Sending rules</h2><p class="fw-dim">Slow and steady keeps you out of spam folders.</p><div class="fw-row3"><label class="fw-f"><span>Max emails / day</span><input type="number" name="daily_cap" min="1" max="200" value="' . esc_attr($s['daily_cap']) . '"></label><label class="fw-f"><span>Minutes between sends</span><input type="number" name="min_gap_minutes" min="0" max="120" value="' . esc_attr($s['min_gap_minutes']) . '"></label><label class="fw-f"><span>Sent today</span><input disabled value="' . esc_attr(fwcrm_sent_today()) . '"></label></div><div class="fw-row2"><label class="fw-f"><span>Send from (hour, ' . esc_html(wp_timezone_string()) . ')</span><input type="number" name="window_start" min="0" max="23" value="' . esc_attr($s['window_start']) . '"></label><label class="fw-f"><span>Until (hour)</span><input type="number" name="window_end" min="1" max="24" value="' . esc_attr($s['window_end']) . '"></label></div><div class="fw-days">';
    foreach (array(1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun') as $n => $l) echo '<label><input type="checkbox" name="workdays[]" value="' . $n . '"' . checked(in_array($n, array_map('intval', (array) $s['workdays']), true), true, false) . '><span>' . $l . '</span></label>';
    echo '</div><label class="fw-f"><span>Signature (added to every CRM email)</span><textarea name="signature" rows="3">' . esc_textarea($s['signature']) . '</textarea></label><label class="fw-check"><input type="checkbox" name="unsub_footer" value="1"' . checked($s['unsub_footer'], 1, false) . '> Add an opt-out line under each email</label><label class="fw-f"><span>Opt-out line</span><input name="unsub_text" value="' . esc_attr($s['unsub_text']) . '"></label></div>';

    echo '<div class="fw-card"><h2>4 · Tracking & alerts</h2><label class="fw-check"><input type="checkbox" name="track_opens" value="1"' . checked($s['track_opens'], 1, false) . '> Track email opens</label><label class="fw-check"><input type="checkbox" name="track_clicks" value="1"' . checked($s['track_clicks'], 1, false) . '> Track link clicks (and recognise leads on your website)</label><label class="fw-check"><input type="checkbox" name="track_visitors" value="1"' . checked($s['track_visitors'], 1, false) . '> Track website visitors</label><label class="fw-check"><input type="checkbox" name="track_admins" value="1"' . checked($s['track_admins'], 1, false) . '> Also count my own visits while logged in</label><label class="fw-f"><span>Send alerts to</span><input name="notify_email" value="' . esc_attr($s['notify_email']) . '"></label><label class="fw-check"><input type="checkbox" name="notify_reply" value="1"' . checked($s['notify_reply'], 1, false) . '> Email me when a lead replies</label><label class="fw-check"><input type="checkbox" name="notify_hot_visit" value="1"' . checked($s['notify_hot_visit'], 1, false) . '> Email me when a lead clicks or is on my website</label><label class="fw-check"><input type="checkbox" name="daily_digest" value="1"' . checked($s['daily_digest'], 1, false) . '> Daily summary email</label></div>';

    echo '<div class="fw-card" id="alerts"><h2>📱 Phone alerts</h2><input type="hidden" name="has_push" value="1"><p class="fw-dim">Get a notification the moment a lead replies, a promise goes overdue, someone watches your video or books a call.</p>';
    echo '<label class="fw-check"><input type="checkbox" name="push_ntfy" value="1"' . checked($s['push_ntfy'], 1, false) . '> <b>ntfy</b> (free, easiest): install the <b>ntfy</b> app (Play Store / App Store), tap +, and subscribe to this topic:</label><label class="fw-f"><span>Your private topic name (keep it secret)</span><input name="ntfy_topic" value="' . esc_attr($s['ntfy_topic']) . '"></label>';
    echo '<details class="fw-sub"><summary>Or use Telegram</summary><p class="fw-dim">Message <b>@BotFather</b> → /newbot → copy the token. Then message your new bot once and get your chat ID from <b>@userinfobot</b>.</p><div class="fw-row2"><label class="fw-f"><span>Bot token</span><input type="password" name="tg_token" value="" autocomplete="new-password" placeholder="' . (fwcrm_decrypt($s['tg_token']) !== '' ? '•••••••• saved (type to change)' : '123456:ABC…') . '"></label><label class="fw-f"><span>Chat ID</span><input name="tg_chat" value="' . esc_attr($s['tg_chat']) . '"></label></div></details>';
    echo '<div class="fw-checks"><label class="fw-check"><input type="checkbox" name="push_reply" value="1"' . checked($s['push_reply'], 1, false) . '> A lead replies</label><label class="fw-check"><input type="checkbox" name="push_tasks" value="1"' . checked($s['push_tasks'], 1, false) . '> A promise or call is due</label><label class="fw-check"><input type="checkbox" name="push_hot" value="1"' . checked($s['push_hot'], 1, false) . '> A lead watches my video</label></div>';
    echo '<div class="fw-row2"><label class="fw-f"><span>Booking link (used in saved replies and video pages)</span><input name="booking_url" value="' . esc_attr($s['booking_url']) . '"></label><label class="fw-f"><span>Promise due after (hours)</span><input type="number" min="1" max="72" name="promise_hours" value="' . (int) $s['promise_hours'] . '"></label></div>';
    echo '<div class="fw-btnrow"><span class="fw-dim">Save first, then test.</span><button type="button" class="fw-btn" data-fw-work="push_test">Send a test alert</button></div></div>';

    $cron = wp_next_scheduled('fwcrm_tick');
    echo '<div class="fw-card"><h2>5 · Background worker</h2><p class="fw-dim">Checks the mailbox and sends due follow-ups every 5 minutes. Last run: <b>' . esc_html(fwcrm_time_ago(get_option('fwcrm_last_tick'))) . '</b>' . ($cron ? ' · next ' . esc_html(human_time_diff(time(), $cron)) : '') . '.</p><p class="fw-dim">For rock-solid timing, add a cron job in hPanel → Advanced → Cron Jobs that runs every 5 minutes:<br><code>wget -q -O - ' . esc_html(site_url('wp-cron.php?doing_wp_cron')) . ' &gt;/dev/null 2&gt;&amp;1</code></p></div>';

    echo '<div class="fw-card" id="social"><h2>Social accounts (Windsor.ai)</h2><p class="fw-dim">Paste your Windsor.ai API key (windsor.ai → account → API key). Threads and Instagram numbers update daily.</p><label class="fw-f"><span>Windsor API key</span><input type="password" name="windsor_key" value="" placeholder="' . (fwcrm_decrypt($s['windsor_key']) !== '' ? '•••••••• saved (type to change)' : 'Windsor API key') . '" autocomplete="new-password"></label><div class="fw-row2"><label class="fw-f"><span>Threads account id</span><input name="windsor_threads_id" value="' . esc_attr($s['windsor_threads_id']) . '"></label><label class="fw-f"><span>Instagram account id</span><input name="windsor_instagram_id" value="' . esc_attr($s['windsor_instagram_id']) . '"></label></div><label class="fw-f"><span>Post schedule (schedule.json link)</span><input name="schedule_url" value="' . esc_attr($s['schedule_url']) . '"></label></div>';

    echo fwcrm_ai_key() === '' ? '<details class="fw-card" id="ai"><summary><strong>✦ My AI</strong> <span class="fw-dim">· off (optional, needs a paid Anthropic API key)</span></summary>' : '<div class="fw-card" id="ai"><h2>✦ My AI</h2>';
    echo '<p class="fw-dim">Runs on Claude through Anthropic\'s API (pay-as-you-go, billed separately from claude.ai). Create a key at console.anthropic.com → API keys.</p><div class="fw-row2"><label class="fw-f"><span>Anthropic API key</span><input type="password" name="ai_key" value="" placeholder="' . (fwcrm_ai_key() !== '' ? '•••••••• saved (type to change)' : 'sk-ant-…') . '" autocomplete="new-password"></label><label class="fw-f"><span>Model</span><select name="ai_model">';
    foreach (array('claude-sonnet-5-5' => 'Claude Sonnet 5.5 (fast, low cost)', 'claude-opus-5-5' => 'Claude Opus 5.5 (smartest)', 'claude-haiku-5-5' => 'Claude Haiku 5.5 (cheapest)') as $mk => $ml) echo '<option value="' . esc_attr($mk) . '"' . selected($s['ai_model'], $mk, false) . '>' . esc_html($ml) . '</option>';
    echo '</select></label></div><label class="fw-f"><span>What My AI should know about you and your business</span><textarea name="ai_about" rows="9">' . esc_textarea($s['ai_about']) . '</textarea></label>' . (fwcrm_ai_key() === '' ? '</details>' : '</div>');

    echo '<div class="fw-card" id="hub"><h2>Hub & website tracking</h2><div class="fw-row2"><label class="fw-f"><span>This install is</span><select name="hub_mode"><option value="hub"' . selected($s['hub_mode'], 'hub', false) . '>The hub (crm.felixeweb.com)</option><option value="site"' . selected($s['hub_mode'], 'site', false) . '>The website: only track visitors and send them to the hub</option></select></label><label class="fw-f"><span>Hub address (for website mode)</span><input name="remote_hub_url" value="' . esc_attr($s['remote_hub_url']) . '" placeholder="https://crm.felixeweb.com"></label></div><div class="fw-row2"><label class="fw-f"><span>Your website</span><input name="website_url" value="' . esc_attr($s['website_url']) . '"></label><label class="fw-f"><span>Other sites allowed to send visits</span><input name="allowed_origins" value="' . esc_attr($s['allowed_origins']) . '" placeholder="https://felixeweb.com"></label></div><label class="fw-check"><input type="checkbox" name="app_frontpage" value="1"' . checked(fwcrm_opt('app_frontpage'), 1, false) . '> This subdomain opens straight into the hub (branded login)</label><label class="fw-check"><input type="checkbox" name="app_mode" value="1"' . checked(fwcrm_opt('app_mode', 1), 1, false) . '> Full-screen app look (hide the WordPress menu on hub pages)</label><label class="fw-f"><span>API key for tools that push leads in (optional)</span><input name="api_key" value="' . esc_attr($s['api_key']) . '" placeholder="leave empty to disable"></label></div>';
    echo '</div></div><div class="fw-btnrow sticky"><button class="fw-btn gold">Save settings</button></div></form>';

    if (function_exists('fwcrm_update_card')) echo fwcrm_update_card();
    $log = get_option('fwcrm_log', array());
    if ($log) echo '<div class="fw-card"><details><summary><b>Activity log</b></summary><pre class="fw-log">' . esc_html(implode("\n", array_slice($log, 0, 40))) . '</pre></details></div>';
    fwcrm_footer();
}
