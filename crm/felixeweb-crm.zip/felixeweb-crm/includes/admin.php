<?php
if (!defined('ABSPATH')) exit;

/* ---------- Menu & assets ---------- */

add_action('admin_menu', function () {
    $cap = 'manage_options';
    global $wpdb;
    $waiting = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction='in' AND kind='reply' AND handled=0");
    $bubble = $waiting ? ' <span class="awaiting-mod">' . $waiting . '</span>' : '';
    $icon = 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="1.5" y="1.5" width="17" height="17" rx="4" fill="none" stroke="#B08A2E" stroke-width="2"/><text x="10" y="14" font-family="Arial" font-weight="800" font-size="8" text-anchor="middle" fill="#B08A2E">FW</text></svg>');
    add_menu_page('FelixeWeb CRM', 'FelixeWeb CRM' . $bubble, $cap, 'fwcrm', 'fwcrm_page_dashboard', $icon, 3);
    add_submenu_page('fwcrm', 'Dashboard', 'Dashboard', $cap, 'fwcrm', 'fwcrm_page_dashboard');
    add_submenu_page('fwcrm', 'Contacts', 'Contacts', $cap, 'fwcrm-contacts', 'fwcrm_page_contacts');
    add_submenu_page('fwcrm', 'Pipeline', 'Pipeline', $cap, 'fwcrm-pipeline', 'fwcrm_page_pipeline');
    add_submenu_page('fwcrm', 'Inbox', 'Inbox' . $bubble, $cap, 'fwcrm-inbox', 'fwcrm_page_inbox');
    add_submenu_page('fwcrm', 'Follow-ups', 'Follow-ups', $cap, 'fwcrm-sequences', 'fwcrm_page_sequences');
    add_submenu_page('fwcrm', 'Website visitors', 'Website visitors', $cap, 'fwcrm-visitors', 'fwcrm_page_visitors');
    add_submenu_page('fwcrm', 'Settings', 'Settings', $cap, 'fwcrm-settings', 'fwcrm_page_settings');
});

function fwcrm_is_crm_screen() {
    return isset($_GET['page']) && strpos(sanitize_key($_GET['page']), 'fwcrm') === 0;
}

add_filter('admin_body_class', function ($c) {
    return fwcrm_is_crm_screen() ? $c . ' fwcrm-screen' : $c;
});

add_action('admin_enqueue_scripts', function () {
    if (!fwcrm_is_crm_screen()) return;
    wp_enqueue_style('fwcrm-font', 'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300&display=swap', array(), null);
    wp_enqueue_style('fwcrm-admin', FWCRM_URL . 'assets/admin.css', array(), FWCRM_VERSION);
    wp_enqueue_script('fwcrm-admin', FWCRM_URL . 'assets/admin.js', array(), FWCRM_VERSION, true);
    wp_localize_script('fwcrm-admin', 'FWCRM', array('ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('fwcrm')));
});

/* ---------- Shared UI bits ---------- */

function fwcrm_header($title, $sub = '', $actions = '') {
    $st = get_option('fwcrm_mailbox_status', array());
    $ok = fwcrm_mailbox_ready() && !empty($st['ok']);
    $pill = fwcrm_mailbox_ready()
        ? ($ok ? '<span class="fw-pill ok"><i></i>Mailbox connected · synced ' . esc_html(fwcrm_time_ago(isset($st['at']) ? $st['at'] : '')) . '</span>' : '<span class="fw-pill bad"><i></i>Mailbox error: ' . esc_html(isset($st['msg']) ? $st['msg'] : 'not synced yet') . '</span>')
        : '<a class="fw-pill bad" href="' . esc_url(fwcrm_admin_url('fwcrm-settings')) . '"><i></i>Connect your mailbox →</a>';
    $tabs = array('fwcrm' => 'Dashboard', 'fwcrm-contacts' => 'Contacts', 'fwcrm-pipeline' => 'Pipeline', 'fwcrm-inbox' => 'Inbox', 'fwcrm-sequences' => 'Follow-ups', 'fwcrm-visitors' => 'Visitors', 'fwcrm-settings' => 'Settings');
    $cur = sanitize_key($_GET['page']);
    echo '<div class="fw-app"><div class="fw-top"><div class="fw-brand"><span class="fw-mark">F<b>W</b></span><span class="fw-word">FELIXE<b>WEB</b> <em>CRM</em></span></div><nav class="fw-tabs">';
    foreach ($tabs as $slug => $label) {
        echo '<a class="' . ($slug === $cur ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url($slug)) . '">' . esc_html($label) . '</a>';
    }
    echo '</nav>' . $pill . '</div>';
    if (!empty($_GET['fwmsg'])) {
        $type = !empty($_GET['fwerr']) ? 'err' : 'ok';
        echo '<div class="fw-toast ' . $type . '">' . esc_html(wp_unslash($_GET['fwmsg'])) . '</div>';
    }
    echo '<div class="fw-head"><div><h1>' . esc_html($title) . '</h1>' . ($sub ? '<p>' . wp_kses_post($sub) . '</p>' : '') . '</div><div class="fw-actions">' . $actions . '</div></div>';
}

function fwcrm_footer() {
    echo '</div>';
}

function fwcrm_stage_pill($stage) {
    $st = fwcrm_stages();
    return '<span class="fw-stage s-' . esc_attr($stage) . '">' . esc_html(isset($st[$stage]) ? $st[$stage] : $stage) . '</span>';
}

function fwcrm_btn($label, $href, $class = '') {
    return '<a class="fw-btn ' . esc_attr($class) . '" href="' . esc_url($href) . '">' . esc_html($label) . '</a>';
}

function fwcrm_post_form_open($action, $extra = '') {
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" ' . $extra . '><input type="hidden" name="action" value="' . esc_attr($action) . '">' . wp_nonce_field('fwcrm_' . $action, '_fwnonce', true, false);
}

function fwcrm_activity_icons($c) {
    $out = '';
    $now = current_time('timestamp');
    foreach (array('last_open' => array('Opened', 'o'), 'last_click' => array('Clicked', 'k'), 'last_visit' => array('Visited site', 'v'), 'last_reply' => array('Replied', 'r')) as $f => $d) {
        if (!empty($c->$f)) {
            $fresh = ($now - strtotime($c->$f)) < 3 * DAY_IN_SECONDS ? ' fresh' : '';
            $out .= '<span class="fw-ic ic-' . $d[1] . $fresh . '" title="' . esc_attr($d[0] . ' ' . fwcrm_time_ago($c->$f)) . '"></span>';
        }
    }
    return $out ?: '<span class="fw-dim">—</span>';
}

/* ---------- Dashboard ---------- */

function fwcrm_page_dashboard() {
    global $wpdb;
    $T = 'fwcrm_t';
    $now = current_time('timestamp');
    $d30 = date('Y-m-d H:i:s', $now - 30 * DAY_IN_SECONDS);
    $d7 = date('Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS);
    $today = date('Y-m-d 00:00:00', $now);

    $sent30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='out' AND status='sent' AND kind IN ('email','followup') AND sent_at >= %s", $d30));
    $opened30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='out' AND source='crm' AND status='sent' AND opens > 0 AND sent_at >= %s", $d30));
    $crm30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='out' AND source='crm' AND status='sent' AND sent_at >= %s", $d30));
    $contacted30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$T('emails')} WHERE direction='out' AND status='sent' AND sent_at >= %s", $d30));
    $replied30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT e.contact_id) FROM {$T('emails')} e WHERE e.direction='in' AND e.kind='reply' AND e.sent_at >= %s AND EXISTS (SELECT 1 FROM {$T('emails')} o WHERE o.contact_id=e.contact_id AND o.direction='out')", $d30));
    $waiting = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('emails')} WHERE direction='in' AND kind='reply' AND handled=0");
    $due = fwcrm_followups_due(100);
    $active_seq = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('enrollments')} WHERE status='active'");
    $vis_today = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM {$T('visits')} WHERE created >= %s", $today));
    $vis7 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM {$T('visits')} WHERE created >= %s", $d7));
    $known7 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$T('visits')} WHERE contact_id > 0 AND created >= %s", $d7));
    $won = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T('contacts')} WHERE stage='won'");
    $open_rate = $crm30 ? round($opened30 / $crm30 * 100) : 0;
    $reply_rate = $contacted30 ? round($replied30 / $contacted30 * 100) : 0;

    $hour = (int) date('G', $now);
    $greet = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
    $user = wp_get_current_user();
    $actions = fwcrm_btn('+ Add lead', fwcrm_admin_url('fwcrm-contacts', array('add' => 1)), 'gold')
        . '<button class="fw-btn" data-fw-ajax="fwcrm_sync_now">↻ Sync mailbox</button>';
    fwcrm_header($greet . ', ' . ($user->first_name ?: $user->display_name), 'Here is everything happening with your outreach and website.', $actions);

    echo '<div class="fw-kpis">';
    $k = array(
        array('Emails sent', $sent30, 'last 30 days'),
        array('Open rate', $open_rate . '%', 'CRM-sent emails'),
        array('Reply rate', $reply_rate . '%', $replied30 . ' of ' . $contacted30 . ' leads'),
        array('Replies waiting', $waiting, 'need your answer', $waiting ? 'hot' : ''),
        array('Follow-ups due', count($due), $active_seq . ' in auto sequences'),
        array('Site visitors', $vis7, $vis_today . ' today · ' . $known7 . ' known leads'),
    );
    foreach ($k as $x) {
        echo '<div class="fw-kpi ' . (isset($x[3]) ? $x[3] : '') . '"><span>' . esc_html($x[0]) . '</span><b>' . esc_html($x[1]) . '</b><small>' . esc_html($x[2]) . '</small></div>';
    }
    echo '</div>';

    // Chart: 14 days sent vs replies vs visitors
    $days = array();
    for ($i = 13; $i >= 0; $i--) $days[date('Y-m-d', $now - $i * DAY_IN_SECONDS)] = array('s' => 0, 'r' => 0, 'v' => 0);
    $from = date('Y-m-d 00:00:00', $now - 13 * DAY_IN_SECONDS);
    foreach ($wpdb->get_results($wpdb->prepare("SELECT DATE(sent_at) d, direction, kind, COUNT(*) n FROM {$T('emails')} WHERE sent_at >= %s AND ((direction='out' AND status='sent') OR (direction='in' AND kind='reply')) GROUP BY DATE(sent_at), direction, kind", $from)) as $r) {
        if (!isset($days[$r->d])) continue;
        if ($r->direction === 'out') $days[$r->d]['s'] += $r->n; else $days[$r->d]['r'] += $r->n;
    }
    foreach ($wpdb->get_results($wpdb->prepare("SELECT DATE(created) d, COUNT(DISTINCT visitor_id) n FROM {$T('visits')} WHERE created >= %s GROUP BY DATE(created)", $from)) as $r) {
        if (isset($days[$r->d])) $days[$r->d]['v'] = (int) $r->n;
    }
    $max = 1;
    foreach ($days as $d) $max = max($max, $d['s'], $d['r'], $d['v']);

    echo '<div class="fw-grid2">';
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Last 14 days</h2><div class="fw-legend"><i class="l-s"></i>Sent <i class="l-r"></i>Replies <i class="l-v"></i>Visitors</div></div><div class="fw-chart">';
    foreach ($days as $date => $d) {
        echo '<div class="fw-col" title="' . esc_attr(date_i18n('D j M', strtotime($date)) . ': ' . $d['s'] . ' sent, ' . $d['r'] . ' replies, ' . $d['v'] . ' visitors') . '"><div class="fw-bars"><i class="b-s" style="height:' . round($d['s'] / $max * 100) . '%"></i><i class="b-r" style="height:' . round($d['r'] / $max * 100) . '%"></i><i class="b-v" style="height:' . round($d['v'] / $max * 100) . '%"></i></div><small>' . esc_html(date_i18n('j', strtotime($date))) . '</small></div>';
    }
    echo '</div></div>';

    // Pipeline summary
    $counts = array();
    foreach ($wpdb->get_results("SELECT stage, COUNT(*) n FROM {$T('contacts')} GROUP BY stage") as $r) $counts[$r->stage] = (int) $r->n;
    $total = max(1, array_sum($counts));
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Pipeline</h2>' . fwcrm_btn('Open board', fwcrm_admin_url('fwcrm-pipeline'), 'sm') . '</div><div class="fw-funnel">';
    foreach (fwcrm_stages() as $key => $label) {
        $n = isset($counts[$key]) ? $counts[$key] : 0;
        echo '<a class="fw-frow" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('stage' => $key))) . '"><span>' . esc_html($label) . '</span><div class="fw-fbar"><i class="s-' . esc_attr($key) . '" style="width:' . max(2, round($n / $total * 100)) . '%"></i></div><b>' . $n . '</b></a>';
    }
    echo '</div></div></div>';

    // Attention lists
    echo '<div class="fw-grid2">';
    $replies = $wpdb->get_results("SELECT e.*, c.first_name, c.last_name, c.email, c.company FROM {$T('emails')} e JOIN {$T('contacts')} c ON c.id=e.contact_id WHERE e.direction='in' AND e.kind='reply' AND e.handled=0 ORDER BY e.sent_at DESC LIMIT 8");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Replies waiting for you</h2>' . fwcrm_btn('Inbox', fwcrm_admin_url('fwcrm-inbox'), 'sm') . '</div>';
    if (!$replies) echo '<div class="fw-empty">No replies waiting. New replies show up here within 5 minutes.</div>';
    foreach ($replies as $r) {
        echo '<a class="fw-item" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $r->contact_id))) . '"><div class="fw-av">' . esc_html(strtoupper(substr($r->first_name ?: $r->email, 0, 1))) . '</div><div class="fw-it"><b>' . esc_html(fwcrm_contact_name($r)) . ($r->company ? ' <em>· ' . esc_html($r->company) . '</em>' : '') . '</b><span>' . esc_html($r->subject) . '</span><small>' . esc_html(wp_html_excerpt($r->snippet, 120, '…')) . '</small></div><time>' . esc_html(fwcrm_time_ago($r->sent_at)) . '</time></a>';
    }
    echo '</div>';

    echo '<div class="fw-card"><div class="fw-card-h"><h2>Follow-ups due</h2><span class="fw-dim">not in an auto sequence</span></div>';
    if (!$due) echo '<div class="fw-empty">Nothing due. Leads you email from webmail get a follow-up date automatically.</div>';
    $seqs = fwcrm_get_sequences(true);
    foreach (array_slice($due, 0, 8) as $c) {
        echo '<div class="fw-item"><div class="fw-av">' . esc_html(strtoupper(substr($c->first_name ?: $c->email, 0, 1))) . '</div><div class="fw-it"><a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><b>' . esc_html(fwcrm_contact_name($c)) . ($c->company ? ' <em>· ' . esc_html($c->company) . '</em>' : '') . '</b></a><small>Last emailed ' . esc_html(fwcrm_time_ago($c->last_contacted)) . ' · ' . fwcrm_activity_icons($c) . '</small></div><div class="fw-mini">';
        echo '<select data-fw-enroll="' . (int) $c->id . '"><option value="">Auto follow-up…</option>';
        foreach ($seqs as $s) echo '<option value="' . (int) $s->id . '">' . esc_html($s->name) . '</option>';
        echo '</select><button class="fw-btn sm" data-fw-ajax="fwcrm_snooze" data-id="' . (int) $c->id . '" title="Remind me in 3 days">Snooze</button><button class="fw-btn sm ghost" data-fw-ajax="fwcrm_clear_followup" data-id="' . (int) $c->id . '" title="No follow-up needed">✓</button></div></div>';
    }
    echo '</div></div>';

    echo '<div class="fw-grid2">';
    // Hot leads
    $hot = $wpdb->get_results("SELECT * FROM {$T('contacts')} WHERE stage NOT IN ('won','lost') AND unsubscribed=0 ORDER BY score DESC, GREATEST(COALESCE(last_click,'2000-01-01'),COALESCE(last_visit,'2000-01-01'),COALESCE(last_open,'2000-01-01')) DESC LIMIT 8");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Hottest leads</h2><span class="fw-dim">by engagement score</span></div>';
    if (!$hot) echo '<div class="fw-empty">Add or import leads to get started.</div>';
    foreach ($hot as $c) {
        echo '<a class="fw-item" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><div class="fw-score">' . (int) $c->score . '</div><div class="fw-it"><b>' . esc_html(fwcrm_contact_name($c)) . ($c->company ? ' <em>· ' . esc_html($c->company) . '</em>' : '') . '</b><small>' . fwcrm_stage_pill($c->stage) . ' ' . fwcrm_activity_icons($c) . '</small></div></a>';
    }
    echo '</div>';

    // Recent activity
    $ev = $wpdb->get_results("SELECT e.*, c.first_name, c.last_name, c.email FROM {$T('events')} e LEFT JOIN {$T('contacts')} c ON c.id=e.contact_id WHERE e.type IN ('reply','open','click','visit','cta_click','sent','bounce','unsubscribe','inbound','enrolled','sequence_done') ORDER BY e.id DESC LIMIT 12");
    echo '<div class="fw-card"><div class="fw-card-h"><h2>Live activity</h2></div><div class="fw-feed">';
    if (!$ev) echo '<div class="fw-empty">Activity from emails and your website appears here.</div>';
    foreach ($ev as $e) {
        echo '<div class="fw-fi"><i class="fw-dot t-' . esc_attr($e->type) . '"></i><div>' . fwcrm_event_text($e) . '<small>' . esc_html(fwcrm_time_ago($e->created)) . '</small></div></div>';
    }
    echo '</div></div></div>';
    fwcrm_footer();
}

function fwcrm_event_text($e) {
    $m = $e->meta ? json_decode($e->meta, true) : array();
    $name = $e->contact_id ? '<a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $e->contact_id))) . '"><b>' . esc_html(fwcrm_contact_name($e)) . '</b></a>' : (!empty($e->email) ? '<b>' . esc_html(fwcrm_contact_name($e)) . '</b>' : 'Someone');
    switch ($e->type) {
        case 'sent': return $name . ' was emailed' . (!empty($m['via']) ? ' (from webmail)' : '') . (!empty($m['subject']) ? ': <em>' . esc_html($m['subject']) . '</em>' : '');
        case 'open': return $name . ' opened <em>' . esc_html(isset($m['subject']) ? $m['subject'] : 'your email') . '</em>';
        case 'click': return $name . ' clicked <em>' . esc_html(isset($m['url']) ? preg_replace('#^https?://#', '', $m['url']) : 'a link') . '</em>';
        case 'reply': return $name . ' <b class="g">replied</b>' . (!empty($m['snippet']) ? ': “' . esc_html($m['snippet']) . '”' : '');
        case 'inbound': return $name . ' emailed you';
        case 'visit': return $name . ' visited <em>' . esc_html(isset($m['path']) ? $m['path'] : '/') . '</em>';
        case 'cta_click': return $name . ' clicked <em>' . esc_html(isset($m['label']) ? $m['label'] : 'a button') . '</em> on your site';
        case 'bounce': return $name . '’s email bounced';
        case 'unsubscribe': return $name . ' unsubscribed';
        case 'enrolled': return $name . ' started <em>' . esc_html(isset($m['sequence']) ? $m['sequence'] : 'a sequence') . '</em>';
        case 'sequence_done': return $name . ' finished <em>' . esc_html(isset($m['sequence']) ? $m['sequence'] : 'a sequence') . '</em> with no reply';
        case 'sequence_stopped': return 'Follow-ups stopped for ' . $name . ' (' . esc_html(isset($m['reason']) ? $m['reason'] : '') . ')';
        case 'stage': return $name . ' moved to ' . fwcrm_stage_pill(isset($m['to']) ? $m['to'] : '');
        case 'note': return 'Note on ' . $name . ': ' . esc_html(isset($m['text']) ? $m['text'] : '');
        case 'created': return $name . ' added (' . esc_html(isset($m['source']) ? $m['source'] : '') . ')';
        case 'auto_reply': return $name . ' sent an auto-reply';
        case 'send_failed': return 'Email to ' . $name . ' failed: ' . esc_html(isset($m['error']) ? $m['error'] : '');
        default: return $name . ' · ' . esc_html($e->type);
    }
}

/* ---------- Contacts ---------- */

function fwcrm_page_contacts() {
    if (!empty($_GET['view'])) return fwcrm_page_contact((int) $_GET['view']);
    if (!empty($_GET['add']) || !empty($_GET['import'])) return fwcrm_page_contact_add();
    global $wpdb;
    $T = 'fwcrm_t';
    $where = array('1=1');
    $args = array();
    $s = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    $stage = isset($_GET['stage']) ? sanitize_key($_GET['stage']) : '';
    $source = isset($_GET['source']) ? sanitize_key($_GET['source']) : '';
    if ($s !== '') {
        $like = '%' . $wpdb->esc_like($s) . '%';
        $where[] = '(email LIKE %s OR first_name LIKE %s OR last_name LIKE %s OR company LIKE %s OR tags LIKE %s OR niche LIKE %s)';
        array_push($args, $like, $like, $like, $like, $like, $like);
    }
    if ($stage) { $where[] = 'stage = %s'; $args[] = $stage; }
    if ($source) { $where[] = 'source = %s'; $args[] = $source; }
    $sql = "SELECT * FROM {$T('contacts')} WHERE " . implode(' AND ', $where) . " ORDER BY COALESCE(last_reply, last_contacted, created) DESC LIMIT 500";
    $rows = $args ? $wpdb->get_results($wpdb->prepare($sql, $args)) : $wpdb->get_results($sql);
    $active = array();
    foreach ($wpdb->get_results("SELECT e.contact_id, s.name FROM {$T('enrollments')} e JOIN {$T('sequences')} s ON s.id=e.sequence_id WHERE e.status='active'") as $r) $active[$r->contact_id] = $r->name;

    $actions = fwcrm_btn('Import CSV', fwcrm_admin_url('fwcrm-contacts', array('import' => 1))) . fwcrm_btn('+ Add lead', fwcrm_admin_url('fwcrm-contacts', array('add' => 1)), 'gold');
    fwcrm_header('Contacts', count($rows) . ' leads' . ($stage ? ' in ' . fwcrm_stage_pill($stage) : ''), $actions);

    echo '<form class="fw-filters" method="get"><input type="hidden" name="page" value="fwcrm-contacts"><input type="search" name="s" placeholder="Search name, email, company, tag…" value="' . esc_attr($s) . '"><select name="stage"><option value="">All stages</option>';
    foreach (fwcrm_stages() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($stage, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select><select name="source"><option value="">All sources</option>';
    foreach (array('scouting' => 'Scouting (webmail)', 'manual' => 'Added manually', 'import' => 'CSV import', 'inbound' => 'Inbound email') as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($source, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select><button class="fw-btn">Filter</button></form>';

    echo fwcrm_post_form_open('fwcrm_bulk', 'id="fw-bulk"');
    echo '<div class="fw-bulkbar"><span><b id="fw-selcount">0</b> selected</span><select name="bulk_action"><option value="">Bulk action…</option><optgroup label="Start auto follow-ups">';
    foreach (fwcrm_get_sequences(true) as $sq) echo '<option value="enroll:' . (int) $sq->id . '">' . esc_html($sq->name) . '</option>';
    echo '</optgroup><optgroup label="Move to stage">';
    foreach (fwcrm_stages() as $k => $l) echo '<option value="stage:' . esc_attr($k) . '">' . esc_html($l) . '</option>';
    echo '</optgroup><option value="stop">Stop follow-ups</option><option value="delete">Delete</option></select><button class="fw-btn sm gold">Apply</button></div>';
    echo '<div class="fw-card fw-tablewrap"><table class="fw-table"><thead><tr><th><input type="checkbox" id="fw-all"></th><th>Lead</th><th>Stage</th><th>Activity</th><th>Last emailed</th><th>Next follow-up</th><th>Score</th></tr></thead><tbody>';
    if (!$rows) echo '<tr><td colspan="7"><div class="fw-empty">No leads yet. Add one, import a CSV, or connect your mailbox. Every scouting email you send is imported automatically.</div></td></tr>';
    foreach ($rows as $c) {
        $url = fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id));
        $flags = ($c->unsubscribed ? '<span class="fw-flag">unsubscribed</span>' : '') . ($c->bounced ? '<span class="fw-flag">bounced</span>' : '');
        $next = isset($active[$c->id]) ? '<span class="fw-auto" title="' . esc_attr($active[$c->id]) . '">⚡ ' . esc_html(fwcrm_time_ago($c->next_followup)) . '</span>' : ($c->next_followup ? '<span class="' . (strtotime($c->next_followup) <= current_time('timestamp') ? 'fw-due' : '') . '">' . esc_html(fwcrm_time_ago($c->next_followup)) . '</span>' : '<span class="fw-dim">—</span>');
        echo '<tr><td><input type="checkbox" name="ids[]" value="' . (int) $c->id . '"></td><td><a class="fw-lead" href="' . esc_url($url) . '"><div class="fw-av">' . esc_html(strtoupper(substr($c->first_name ?: $c->email, 0, 1))) . '</div><div><b>' . esc_html(fwcrm_contact_name($c)) . '</b><small>' . esc_html($c->email) . ($c->company ? ' · ' . esc_html($c->company) : '') . '</small></div></a>' . $flags . '</td><td>' . fwcrm_stage_pill($c->stage) . '</td><td>' . fwcrm_activity_icons($c) . '</td><td>' . esc_html(fwcrm_time_ago($c->last_contacted)) . '</td><td>' . $next . '</td><td><span class="fw-score sm">' . (int) $c->score . '</span></td></tr>';
    }
    echo '</tbody></table></div></form>';
    fwcrm_footer();
}

function fwcrm_page_contact_add() {
    $import = !empty($_GET['import']);
    fwcrm_header($import ? 'Import leads' : 'Add a lead', $import ? 'Upload a CSV or paste rows. The first row must be headers: <code>email, first_name, last_name, company, website, niche, notes</code> (only email is required).' : 'Add someone you want to reach out to.');
    $seqs = fwcrm_get_sequences(true);
    echo '<div class="fw-grid2"><div class="fw-card">';
    if ($import) {
        echo fwcrm_post_form_open('fwcrm_import', 'enctype="multipart/form-data"');
        echo '<label class="fw-f"><span>CSV file</span><input type="file" name="csv" accept=".csv,text/csv"></label><label class="fw-f"><span>…or paste CSV here</span><textarea name="csv_text" rows="8" placeholder="email,first_name,company&#10;jane@brand.com,Jane,Brand Co"></textarea></label>';
    } else {
        echo fwcrm_post_form_open('fwcrm_add');
        echo '<div class="fw-row2"><label class="fw-f"><span>First name</span><input name="first_name"></label><label class="fw-f"><span>Last name</span><input name="last_name"></label></div>';
        echo '<label class="fw-f"><span>Email *</span><input type="email" name="email" required></label><div class="fw-row2"><label class="fw-f"><span>Company / brand</span><input name="company"></label><label class="fw-f"><span>Website</span><input name="website" placeholder="https://"></label></div>';
        echo '<div class="fw-row2"><label class="fw-f"><span>Niche</span><input name="niche" placeholder="e.g. research peptides"></label><label class="fw-f"><span>Stage</span><select name="stage">';
        foreach (fwcrm_stages() as $k => $l) echo '<option value="' . esc_attr($k) . '">' . esc_html($l) . '</option>';
        echo '</select></label></div><label class="fw-f"><span>Notes</span><textarea name="notes" rows="3"></textarea></label>';
    }
    echo '<label class="fw-f"><span>Start automatic emails</span><select name="enroll"><option value="">Don\'t send anything yet</option>';
    foreach ($seqs as $s) echo '<option value="' . (int) $s->id . '">' . esc_html($s->name) . '</option>';
    echo '</select><em>“Cold outreach” sends the first email in the next sending window, then follows up until they reply.</em></label>';
    echo '<button class="fw-btn gold">' . ($import ? 'Import leads' : 'Save lead') . '</button></form></div>';
    echo '<div class="fw-card fw-help"><h2>Tips</h2><ul><li>Leads you email from your normal webmail or phone are added automatically when the mailbox syncs, so you don\'t need to add them twice.</li><li>Follow-ups stop the moment someone replies, bounces or unsubscribes.</li><li>Use <code>{{first_name|there}}</code> and <code>{{company|your brand}}</code> in emails. The text after <code>|</code> is used when the field is empty.</li></ul></div></div>';
    fwcrm_footer();
}

function fwcrm_page_contact($id) {
    global $wpdb;
    $T = 'fwcrm_t';
    $c = fwcrm_get_contact($id);
    if (!$c) { fwcrm_header('Lead not found'); fwcrm_footer(); return; }
    $enr = $wpdb->get_row($wpdb->prepare("SELECT e.*, s.name, s.steps FROM {$T('enrollments')} e JOIN {$T('sequences')} s ON s.id=e.sequence_id WHERE e.contact_id=%d AND e.status='active' LIMIT 1", $id));
    $emails = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$T('emails')} WHERE contact_id=%d ORDER BY sent_at DESC LIMIT 100", $id));
    $events = $wpdb->get_results($wpdb->prepare("SELECT e.*, '' first_name, '' last_name, '' email FROM {$T('events')} e WHERE contact_id=%d AND type IN ('open','click','visit','cta_click','stage','note','enrolled','sequence_done','sequence_stopped','bounce','unsubscribe','created') ORDER BY id DESC LIMIT 100", $id));
    $visits = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$T('visits')} WHERE contact_id=%d ORDER BY id DESC LIMIT 30", $id));
    $last_in = null;
    foreach ($emails as $e) { if ($e->direction === 'in' && $e->kind === 'reply') { $last_in = $e; break; } }
    $last_out = null;
    foreach ($emails as $e) { if ($e->direction === 'out' && $e->status === 'sent') { $last_out = $e; break; } }

    $actions = fwcrm_btn('← All contacts', fwcrm_admin_url('fwcrm-contacts'));
    $sub = esc_html($c->email) . ($c->company ? ' · ' . esc_html($c->company) : '') . ($c->website ? ' · <a href="' . esc_url($c->website) . '" target="_blank" rel="noopener">' . esc_html(preg_replace('#^https?://(www\.)?#', '', rtrim($c->website, '/'))) . ' ↗</a>' : '');
    fwcrm_header(fwcrm_contact_name($c), $sub, $actions);

    echo '<div class="fw-contact"><div class="fw-side">';
    // Stage + score
    echo '<div class="fw-card"><div class="fw-statline"><div><span>Stage</span><select data-fw-stage="' . (int) $c->id . '">';
    foreach (fwcrm_stages() as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($c->stage, $k, false) . '>' . esc_html($l) . '</option>';
    echo '</select></div><div><span>Score</span><b class="fw-score">' . (int) $c->score . '</b></div></div>';
    echo '<div class="fw-facts">';
    foreach (array('Last emailed' => $c->last_contacted, 'Last opened' => $c->last_open, 'Last clicked' => $c->last_click, 'Last site visit' => $c->last_visit, 'Last reply' => $c->last_reply) as $l => $v) echo '<div><span>' . esc_html($l) . '</span><b>' . esc_html(fwcrm_time_ago($v)) . '</b></div>';
    echo '</div>';
    if ($c->unsubscribed) echo '<div class="fw-warn">Unsubscribed. No emails will be sent.</div>';
    if ($c->bounced) echo '<div class="fw-warn">This address bounced. <button class="fw-link" data-fw-ajax="fwcrm_unbounce" data-id="' . (int) $c->id . '">Mark as valid</button></div>';
    echo '</div>';

    // Automation box
    echo '<div class="fw-card"><h3>Automatic follow-ups</h3>';
    if ($enr) {
        $steps = json_decode($enr->steps, true) ?: array();
        echo '<p class="fw-auto big">⚡ ' . esc_html($enr->name) . '</p><p class="fw-dim">Step ' . ((int) $enr->current_step + 1) . ' of ' . count($steps) . ' · next email ' . esc_html(fwcrm_time_ago($enr->next_run)) . ' (' . esc_html(date_i18n('D j M, H:i', strtotime($enr->next_run))) . ')</p>';
        echo '<div class="fw-btnrow"><button class="fw-btn sm" data-fw-ajax="fwcrm_send_next" data-id="' . (int) $c->id . '">Send next one now</button><button class="fw-btn sm ghost" data-fw-ajax="fwcrm_stop" data-id="' . (int) $c->id . '">Stop</button></div>';
    } else {
        echo '<p class="fw-dim">' . ($c->next_followup ? 'Manual follow-up due ' . esc_html(fwcrm_time_ago($c->next_followup)) . '.' : 'Not in a sequence.') . '</p><select data-fw-enroll="' . (int) $c->id . '"><option value="">Start a sequence…</option>';
        foreach (fwcrm_get_sequences(true) as $s) echo '<option value="' . (int) $s->id . '">' . esc_html($s->name) . '</option>';
        echo '</select>';
    }
    echo '</div>';

    // Details form
    echo '<div class="fw-card"><h3>Details</h3>' . fwcrm_post_form_open('fwcrm_save_contact') . '<input type="hidden" name="id" value="' . (int) $c->id . '">';
    foreach (array('first_name' => 'First name', 'last_name' => 'Last name', 'email' => 'Email', 'company' => 'Company', 'website' => 'Website', 'phone' => 'Phone / WhatsApp', 'niche' => 'Niche', 'tags' => 'Tags (comma separated)') as $f => $l) {
        echo '<label class="fw-f sm"><span>' . esc_html($l) . '</span><input name="' . esc_attr($f) . '" value="' . esc_attr($c->$f) . '"></label>';
    }
    echo '<label class="fw-f sm"><span>Notes</span><textarea name="notes" rows="4">' . esc_textarea($c->notes) . '</textarea></label><div class="fw-btnrow"><button class="fw-btn sm gold">Save</button></div></form>';
    echo fwcrm_post_form_open('fwcrm_delete_contact', 'onsubmit="return confirm(\'Delete this lead and all its history?\')"') . '<input type="hidden" name="id" value="' . (int) $c->id . '"><button class="fw-link danger">Delete lead</button></form></div>';
    echo '</div>';

    // Main: compose + timeline
    echo '<div class="fw-main">';
    $re_subject = $last_in ? 'Re: ' . fwcrm_strip_re($last_in->subject) : ($last_out ? 'Re: ' . fwcrm_strip_re($last_out->subject) : '');
    $reply_to = $last_in ? $last_in->message_id : ($last_out ? $last_out->message_id : '');
    echo '<div class="fw-card fw-compose">' . fwcrm_post_form_open('fwcrm_send') . '<input type="hidden" name="id" value="' . (int) $c->id . '"><h3>Write to ' . esc_html($c->first_name ?: $c->email) . '</h3>';
    if ($reply_to) echo '<label class="fw-check"><input type="checkbox" name="thread" value="' . esc_attr($reply_to) . '" checked> Reply in the same email thread</label>';
    echo '<input class="fw-subj" name="subject" placeholder="Subject" value="' . esc_attr($re_subject) . '"><textarea name="body" rows="7" placeholder="Hi ' . esc_attr($c->first_name ?: 'there') . ',&#10;&#10;…"></textarea><div class="fw-btnrow"><span class="fw-dim">Your signature is added automatically · opens &amp; clicks are tracked</span><button class="fw-btn gold">Send email</button></div></form>';
    echo fwcrm_post_form_open('fwcrm_note', 'class="fw-noteform"') . '<input type="hidden" name="id" value="' . (int) $c->id . '"><input name="note" placeholder="Add a quick note (call outcome, budget, next step)…"><button class="fw-btn sm">Add note</button></form></div>';

    // Timeline merge
    $items = array();
    foreach ($emails as $e) $items[] = array('t' => strtotime($e->sent_at), 'kind' => 'email', 'o' => $e);
    foreach ($events as $e) $items[] = array('t' => strtotime($e->created), 'kind' => 'event', 'o' => $e);
    usort($items, function ($a, $b) { return $b['t'] - $a['t']; });
    echo '<div class="fw-card"><div class="fw-card-h"><h3>Timeline</h3><span class="fw-dim">' . count($emails) . ' emails · ' . count($visits) . ' page views</span></div><div class="fw-timeline">';
    if (!$items) echo '<div class="fw-empty">No activity yet.</div>';
    foreach ($items as $it) {
        $o = $it['o'];
        if ($it['kind'] === 'email') {
            $cls = $o->direction === 'in' ? 'in' : 'out';
            $label = $o->direction === 'in' ? ($o->kind === 'bounce' ? 'Bounce' : ($o->kind === 'auto_reply' ? 'Auto-reply' : 'Reply received')) : ($o->kind === 'followup' ? 'Auto follow-up' . ($o->step ? ' #' . (int) $o->step : '') : ($o->source === 'webmail' ? 'Sent from webmail' : 'Sent from CRM'));
            $meta = $o->direction === 'out' && $o->source === 'crm' ? ($o->status === 'failed' ? '<span class="fw-flag">failed: ' . esc_html($o->error) . '</span>' : ($o->opens ? '<span class="fw-ok">opened ' . (int) $o->opens . '×</span>' : '<span class="fw-dim">not opened yet</span>') . ($o->clicks ? ' <span class="fw-ok">clicked ' . (int) $o->clicks . '×</span>' : '')) : '';
            echo '<details class="fw-mail ' . $cls . ($o->direction === 'in' && !$o->handled ? ' unread' : '') . '"' . ($o->direction === 'in' && $o->kind === 'reply' ? ' open' : '') . '><summary><i></i><div><b>' . esc_html($label) . '</b> · ' . esc_html($o->subject) . '<small>' . esc_html(date_i18n('D j M Y, H:i', $it['t'])) . ' ' . $meta . '</small></div></summary><pre>' . esc_html($o->body ? $o->body : $o->snippet) . '</pre>';
            if ($o->direction === 'in' && !$o->handled && $o->kind === 'reply') echo '<button class="fw-btn sm" data-fw-ajax="fwcrm_handled" data-id="' . (int) $o->id . '">Mark as handled</button>';
            echo '</details>';
        } else {
            echo '<div class="fw-fi"><i class="fw-dot t-' . esc_attr($o->type) . '"></i><div>' . fwcrm_event_text((object) array_merge((array) $o, array('contact_id' => 0, 'first_name' => $c->first_name, 'last_name' => $c->last_name, 'email' => $c->email))) . '<small>' . esc_html(date_i18n('D j M, H:i', $it['t'])) . '</small></div></div>';
        }
    }
    echo '</div></div>';

    if ($visits) {
        echo '<div class="fw-card"><h3>Website visits</h3><table class="fw-table mini"><tbody>';
        foreach ($visits as $v) echo '<tr><td>' . esc_html($v->path) . '</td><td>' . esc_html($v->title) . '</td><td>' . ($v->duration ? esc_html(gmdate($v->duration >= 3600 ? 'G\h i\m' : 'i:s', $v->duration)) : '—') . '</td><td>' . esc_html(fwcrm_time_ago($v->created)) . '</td></tr>';
        echo '</tbody></table></div>';
    }
    echo '</div></div>';
    fwcrm_footer();
}

/* ---------- Pipeline (kanban) ---------- */

function fwcrm_page_pipeline() {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT * FROM " . fwcrm_t('contacts') . " ORDER BY score DESC, updated DESC LIMIT 1000");
    $by = array();
    foreach ($rows as $r) $by[$r->stage][] = $r;
    fwcrm_header('Pipeline', 'Drag a card to move a lead. Leads move forward automatically when they open, reply or book.', fwcrm_btn('+ Add lead', fwcrm_admin_url('fwcrm-contacts', array('add' => 1)), 'gold'));
    echo '<div class="fw-board">';
    foreach (fwcrm_stages() as $k => $l) {
        $list = isset($by[$k]) ? $by[$k] : array();
        echo '<div class="fw-lane" data-stage="' . esc_attr($k) . '"><div class="fw-lane-h"><span class="fw-stage s-' . esc_attr($k) . '">' . esc_html($l) . '</span><b>' . count($list) . '</b></div><div class="fw-drop">';
        foreach ($list as $c) {
            echo '<a class="fw-kcard" draggable="true" data-id="' . (int) $c->id . '" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><b>' . esc_html(fwcrm_contact_name($c)) . '</b><small>' . esc_html($c->company ?: $c->email) . '</small><div>' . fwcrm_activity_icons($c) . '<span class="fw-score sm">' . (int) $c->score . '</span></div></a>';
        }
        echo '</div></div>';
    }
    echo '</div>';
    fwcrm_footer();
}

/* ---------- Inbox ---------- */

function fwcrm_page_inbox() {
    global $wpdb;
    $T = 'fwcrm_t';
    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'waiting';
    $where = array(
        'waiting' => "e.direction='in' AND e.kind='reply' AND e.handled=0",
        'all' => "e.direction='in' AND e.kind='reply'",
        'other' => "e.direction='in' AND e.kind IN ('auto_reply','bounce')",
        'sent' => "e.direction='out'",
    );
    $w = isset($where[$tab]) ? $where[$tab] : $where['waiting'];
    $rows = $wpdb->get_results("SELECT e.*, c.first_name, c.last_name, c.email, c.company, c.stage FROM {$T('emails')} e JOIN {$T('contacts')} c ON c.id=e.contact_id WHERE $w ORDER BY e.sent_at DESC LIMIT 200");
    fwcrm_header('Inbox', 'Replies from your leads, pulled from hello@ every 5 minutes.', '<button class="fw-btn" data-fw-ajax="fwcrm_sync_now">↻ Check now</button>');
    echo '<div class="fw-subtabs">';
    foreach (array('waiting' => 'Needs reply', 'all' => 'All replies', 'other' => 'Auto-replies & bounces', 'sent' => 'Sent') as $k => $l) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', array('tab' => $k))) . '">' . esc_html($l) . '</a>';
    echo '</div><div class="fw-card">';
    if (!$rows) echo '<div class="fw-empty">' . ($tab === 'waiting' ? 'You\'re all caught up.' : 'Nothing here yet.') . '</div>';
    foreach ($rows as $r) {
        echo '<div class="fw-msg' . ($r->direction === 'in' && !$r->handled ? ' unread' : '') . '"><div class="fw-av">' . esc_html(strtoupper(substr($r->first_name ?: $r->email, 0, 1))) . '</div><div class="fw-it"><div class="fw-msg-h"><a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $r->contact_id))) . '"><b>' . esc_html(fwcrm_contact_name($r)) . '</b></a>' . ($r->company ? ' <em>· ' . esc_html($r->company) . '</em>' : '') . ' ' . fwcrm_stage_pill($r->stage) . '<time>' . esc_html(date_i18n('D j M, H:i', strtotime($r->sent_at))) . '</time></div><span>' . esc_html($r->subject) . '</span><p>' . nl2br(esc_html(wp_html_excerpt($r->body ?: $r->snippet, 700, '…'))) . '</p>';
        if ($r->direction === 'in' && $r->kind === 'reply') {
            echo '<details class="fw-quick"><summary class="fw-btn sm gold">Reply</summary>' . fwcrm_post_form_open('fwcrm_send') . '<input type="hidden" name="id" value="' . (int) $r->contact_id . '"><input type="hidden" name="thread" value="' . esc_attr($r->message_id) . '"><input type="hidden" name="back" value="inbox"><input type="hidden" name="handled" value="' . (int) $r->id . '"><input class="fw-subj" name="subject" value="' . esc_attr('Re: ' . fwcrm_strip_re($r->subject)) . '"><textarea name="body" rows="5" placeholder="Write your reply…"></textarea><button class="fw-btn gold sm">Send reply</button></form></details>';
            if (!$r->handled) echo ' <button class="fw-btn sm ghost" data-fw-ajax="fwcrm_handled" data-id="' . (int) $r->id . '">Mark handled</button>';
        }
        echo '</div></div>';
    }
    echo '</div>';
    fwcrm_footer();
}

/* ---------- Sequences ---------- */

function fwcrm_page_sequences() {
    global $wpdb;
    $T = 'fwcrm_t';
    if (isset($_GET['edit'])) return fwcrm_page_sequence_edit((int) $_GET['edit']);
    $seqs = fwcrm_get_sequences();
    fwcrm_header('Follow-up sequences', 'Automatic emails that stop the moment a lead replies, bounces or unsubscribes. Sent only on your sending days and hours, max ' . (int) fwcrm_opt('daily_cap') . ' per day.', fwcrm_btn('+ New sequence', fwcrm_admin_url('fwcrm-sequences', array('edit' => 0)), 'gold') . '<button class="fw-btn" data-fw-ajax="fwcrm_run_now">▶ Run due emails now</button>');
    $auto = (int) fwcrm_opt('auto_enroll_seq');
    echo '<div class="fw-cards3">';
    foreach ($seqs as $s) {
        $st = array();
        foreach ($wpdb->get_results($wpdb->prepare("SELECT status, COUNT(*) n FROM {$T('enrollments')} WHERE sequence_id=%d GROUP BY status", $s->id)) as $r) $st[$r->status] = (int) $r->n;
        $total = array_sum($st);
        $replied = isset($st['replied']) ? $st['replied'] : 0;
        $rr = $total ? round($replied / $total * 100) : 0;
        echo '<div class="fw-card fw-seq"><div class="fw-card-h"><h2>' . esc_html($s->name) . '</h2><span class="fw-pill ' . ($s->active ? 'ok' : '') . '"><i></i>' . ($s->active ? 'Active' : 'Paused') . '</span></div>';
        if ($auto === (int) $s->id) echo '<p class="fw-auto">⚡ Auto-starts for every new scouting email you send</p>';
        echo '<div class="fw-steps">';
        $acc = 0;
        foreach ($s->steps_arr as $i => $step) {
            $acc += (float) $step['delay_days'];
            echo '<div class="fw-step"><i>' . ($i + 1) . '</i><div><b>' . esc_html($step['subject'] !== '' ? fwcrm_merge($step['subject'], array()) : 'Reply in thread') . '</b><small>Day ' . esc_html(rtrim(rtrim(number_format($acc, 1), '0'), '.')) . ' · ' . esc_html(wp_html_excerpt(str_replace("\n", ' ', $step['body']), 90, '…')) . '</small></div></div>';
        }
        echo '</div><div class="fw-seqstats"><div><b>' . (isset($st['active']) ? $st['active'] : 0) . '</b><span>in progress</span></div><div><b>' . $replied . '</b><span>replied</span></div><div><b>' . $rr . '%</b><span>reply rate</span></div></div><div class="fw-btnrow">' . fwcrm_btn('Edit', fwcrm_admin_url('fwcrm-sequences', array('edit' => $s->id)), 'sm') . '</div></div>';
    }
    echo '</div>';
    fwcrm_footer();
}

function fwcrm_page_sequence_edit($id) {
    $s = $id ? fwcrm_get_sequence($id) : null;
    $steps = $s ? $s->steps_arr : array(array('delay_days' => 0, 'subject' => 'Quick idea for {{company|your store}}', 'body' => "Hi {{first_name|there}},\n\n"), array('delay_days' => 3, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\n"));
    fwcrm_header($s ? 'Edit sequence' : 'New sequence', 'Leave a step\'s subject empty to reply in the same thread (best for follow-ups). Variables: <code>{{first_name|there}}</code> <code>{{company|your brand}}</code> <code>{{website}}</code> <code>{{sender_name}}</code>', fwcrm_btn('← Back', fwcrm_admin_url('fwcrm-sequences')));
    echo fwcrm_post_form_open('fwcrm_save_sequence', 'id="fw-seqform"') . '<input type="hidden" name="id" value="' . (int) $id . '"><div class="fw-card"><div class="fw-row2"><label class="fw-f"><span>Name</span><input name="name" value="' . esc_attr($s ? $s->name : '') . '" required></label><label class="fw-f"><span>Status</span><select name="active"><option value="1"' . selected(!$s || $s->active, true, false) . '>Active</option><option value="0"' . selected($s && !$s->active, true, false) . '>Paused</option></select></label></div>';
    echo '<label class="fw-check"><input type="checkbox" name="auto_enroll" value="1"' . checked($s && (int) fwcrm_opt('auto_enroll_seq') === (int) $s->id, true, false) . '> Start this automatically for every new scouting email I send from webmail (only one sequence can do this)</label></div><div id="fw-steplist">';
    foreach ($steps as $i => $st) fwcrm_step_html($i, $st);
    echo '</div><template id="fw-steptpl">';
    fwcrm_step_html('__i__', array('delay_days' => 3, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\n"));
    echo '</template><div class="fw-btnrow"><button type="button" class="fw-btn" id="fw-addstep">+ Add step</button><button class="fw-btn gold">Save sequence</button></div></form>';
    if ($s) echo fwcrm_post_form_open('fwcrm_delete_sequence', 'onsubmit="return confirm(\'Delete this sequence? Leads in it will stop receiving its emails.\')"') . '<input type="hidden" name="id" value="' . (int) $s->id . '"><button class="fw-link danger">Delete sequence</button></form>';
    fwcrm_footer();
}

function fwcrm_step_html($i, $st) {
    echo '<div class="fw-card fw-stepedit"><div class="fw-card-h"><h3>Step <span class="fw-stepno"></span></h3><button type="button" class="fw-link danger fw-rmstep">Remove</button></div><div class="fw-row3"><label class="fw-f"><span>Wait (days after previous email)</span><input type="number" step="0.5" min="0" name="steps[' . esc_attr($i) . '][delay_days]" value="' . esc_attr($st['delay_days']) . '"></label><label class="fw-f wide"><span>Subject (empty = reply in thread)</span><input name="steps[' . esc_attr($i) . '][subject]" value="' . esc_attr($st['subject']) . '"></label></div><label class="fw-f"><span>Email</span><textarea rows="7" name="steps[' . esc_attr($i) . '][body]">' . esc_textarea($st['body']) . '</textarea></label></div>';
}

/* ---------- Visitors ---------- */

function fwcrm_page_visitors() {
    global $wpdb;
    $T = 'fwcrm_t';
    $range = isset($_GET['range']) ? (int) $_GET['range'] : 7;
    if (!in_array($range, array(1, 7, 30, 90), true)) $range = 7;
    $from = date('Y-m-d H:i:s', current_time('timestamp') - $range * DAY_IN_SECONDS);
    $visitors = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM {$T('visits')} WHERE created >= %s", $from));
    $sessions = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT session_id) FROM {$T('visits')} WHERE created >= %s", $from));
    $views = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$T('visits')} WHERE created >= %s", $from));
    $avg = (int) $wpdb->get_var($wpdb->prepare("SELECT AVG(t) FROM (SELECT SUM(duration) t FROM {$T('visits')} WHERE created >= %s GROUP BY session_id) x", $from));
    $known = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT contact_id) FROM {$T('visits')} WHERE contact_id>0 AND created >= %s", $from));
    $cta = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT session_id) FROM {$T('visits')} WHERE clicked_cta=1 AND created >= %s", $from));

    $tabs = '';
    foreach (array(1 => 'Today', 7 => '7 days', 30 => '30 days', 90 => '90 days') as $k => $l) $tabs .= '<a class="fw-btn sm ' . ($k === $range ? 'gold' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-visitors', array('range' => $k))) . '">' . esc_html($l) . '</a>';
    fwcrm_header('Website visitors', 'Privacy-friendly analytics for ' . esc_html(wp_parse_url(home_url(), PHP_URL_HOST)) . '. Leads who click your emails are recognised by name.', $tabs);
    echo '<div class="fw-kpis">';
    foreach (array(array('Visitors', $visitors), array('Visits', $sessions), array('Page views', $views), array('Avg. visit time', $avg ? gmdate($avg >= 3600 ? 'G\h i\m' : 'i:s', $avg) : '0:00'), array('Known leads', $known), array('Clicked “Book a call”', $cta)) as $k) echo '<div class="fw-kpi"><span>' . esc_html($k[0]) . '</span><b>' . esc_html($k[1]) . '</b></div>';
    echo '</div>';

    $top = $wpdb->get_results($wpdb->prepare("SELECT path, COUNT(*) n, COUNT(DISTINCT visitor_id) u FROM {$T('visits')} WHERE created >= %s GROUP BY path ORDER BY n DESC LIMIT 10", $from));
    $refs = $wpdb->get_results($wpdb->prepare("SELECT CASE WHEN utm_source<>'' THEN utm_source WHEN ref_host<>'' THEN ref_host ELSE 'Direct / none' END src, COUNT(DISTINCT session_id) n FROM {$T('visits')} WHERE created >= %s GROUP BY src ORDER BY n DESC LIMIT 10", $from));
    $dev = $wpdb->get_results($wpdb->prepare("SELECT device, COUNT(DISTINCT session_id) n FROM {$T('visits')} WHERE created >= %s GROUP BY device ORDER BY n DESC", $from));
    $cty = $wpdb->get_results($wpdb->prepare("SELECT country, COUNT(DISTINCT visitor_id) n FROM {$T('visits')} WHERE created >= %s AND country<>'' GROUP BY country ORDER BY n DESC LIMIT 8", $from));
    echo '<div class="fw-grid3">';
    fwcrm_bars_card('Top pages', $top, 'path', 'n');
    fwcrm_bars_card('Traffic sources', $refs, 'src', 'n');
    echo '<div>';
    fwcrm_bars_card('Devices', $dev, 'device', 'n');
    if ($cty) fwcrm_bars_card('Countries', $cty, 'country', 'n');
    echo '</div></div>';

    $sess = $wpdb->get_results($wpdb->prepare("SELECT session_id, visitor_id, MAX(contact_id) contact_id, MIN(created) started, COUNT(*) pages, SUM(duration) dur, MAX(clicked_cta) cta, SUBSTRING_INDEX(GROUP_CONCAT(path ORDER BY id SEPARATOR '|'),'|',6) paths, MAX(ref_host) ref_host, MAX(utm_source) utm, MAX(device) device, MAX(country) country FROM {$T('visits')} WHERE created >= %s GROUP BY session_id ORDER BY started DESC LIMIT 100", $from));
    echo '<div class="fw-card fw-tablewrap"><div class="fw-card-h"><h2>Recent visits</h2></div><table class="fw-table"><thead><tr><th>Visitor</th><th>Pages</th><th>Source</th><th>Time on site</th><th>When</th></tr></thead><tbody>';
    if (!$sess) echo '<tr><td colspan="5"><div class="fw-empty">No visits recorded yet. Tracking starts as soon as the plugin is active (your own visits while logged in are not counted).</div></td></tr>';
    foreach ($sess as $v) {
        $who = '<span class="fw-dim">Anonymous</span>';
        if ($v->contact_id) {
            $c = fwcrm_get_contact($v->contact_id);
            if ($c) $who = '<a class="fw-lead" href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><div class="fw-av gold">' . esc_html(strtoupper(substr($c->first_name ?: $c->email, 0, 1))) . '</div><div><b>' . esc_html(fwcrm_contact_name($c)) . '</b><small>' . esc_html($c->company) . '</small></div></a>';
        }
        $meta = trim(($v->country ? $v->country . ' · ' : '') . $v->device);
        echo '<tr><td>' . $who . '<small class="fw-dim">' . esc_html($meta) . '</small>' . ($v->cta ? ' <span class="fw-ok">clicked CTA</span>' : '') . '</td><td><small>' . esc_html(str_replace('|', ' → ', $v->paths)) . '</small></td><td>' . esc_html($v->utm ?: ($v->ref_host ?: 'Direct')) . '</td><td>' . esc_html($v->dur ? gmdate($v->dur >= 3600 ? 'G\h i\m' : 'i:s', $v->dur) : '<0:05') . '</td><td>' . esc_html(fwcrm_time_ago($v->started)) . '</td></tr>';
    }
    echo '</tbody></table></div>';
    fwcrm_footer();
}

function fwcrm_bars_card($title, $rows, $label, $val) {
    $max = 1;
    foreach ($rows as $r) $max = max($max, (int) $r->$val);
    echo '<div class="fw-card"><h2>' . esc_html($title) . '</h2><div class="fw-hbars">';
    if (!$rows) echo '<div class="fw-empty sm">No data yet</div>';
    foreach ($rows as $r) echo '<div class="fw-hb"><span>' . esc_html($r->$label ?: '—') . '</span><b>' . (int) $r->$val . '</b><i style="width:' . round($r->$val / $max * 100) . '%"></i></div>';
    echo '</div></div>';
}

/* ---------- Settings ---------- */

function fwcrm_page_settings() {
    $s = fwcrm_settings();
    $st = get_option('fwcrm_mailbox_status', array());
    fwcrm_header('Settings', 'Connect your mailbox and tune how the CRM sends and tracks.');
    echo fwcrm_post_form_open('fwcrm_save_settings') . '<div class="fw-grid2"><div>';

    echo '<div class="fw-card"><h2>1 · Your mailbox</h2><p class="fw-dim">The account your outreach emails are sent from. The password is stored encrypted and never shown again.</p>';
    echo '<div class="fw-row2"><label class="fw-f"><span>From name</span><input name="from_name" value="' . esc_attr($s['from_name']) . '"></label><label class="fw-f"><span>From email</span><input name="from_email" value="' . esc_attr($s['from_email']) . '"></label></div>';
    echo '<div class="fw-row2"><label class="fw-f"><span>Mailbox login (usually the same email)</span><input name="mail_user" value="' . esc_attr($s['mail_user']) . '" autocomplete="off"></label><label class="fw-f"><span>Mailbox password</span><input type="password" name="mail_pass" value="" placeholder="' . (fwcrm_mail_pass() !== '' ? '•••••••• saved (type to change)' : 'Enter your email password') . '" autocomplete="new-password"></label></div>';
    echo '<details class="fw-adv"><summary>Server settings (Hostinger defaults)</summary><div class="fw-row3"><label class="fw-f"><span>SMTP host</span><input name="smtp_host" value="' . esc_attr($s['smtp_host']) . '"></label><label class="fw-f"><span>SMTP port</span><input name="smtp_port" value="' . esc_attr($s['smtp_port']) . '"></label><label class="fw-f"><span>Security</span><select name="smtp_secure"><option value="ssl"' . selected($s['smtp_secure'], 'ssl', false) . '>SSL</option><option value="tls"' . selected($s['smtp_secure'], 'tls', false) . '>TLS</option></select></label></div><div class="fw-row3"><label class="fw-f"><span>IMAP host</span><input name="imap_host" value="' . esc_attr($s['imap_host']) . '"></label><label class="fw-f"><span>IMAP port</span><input name="imap_port" value="' . esc_attr($s['imap_port']) . '"></label><label class="fw-f"><span>Sent folder</span><input name="sent_folder" value="' . esc_attr($s['sent_folder']) . '" placeholder="auto-detect"></label></div><label class="fw-f"><span>Reply-To (optional)</span><input name="reply_to" value="' . esc_attr($s['reply_to']) . '"></label></details>';
    echo '<div class="fw-btnrow"><button type="button" class="fw-btn" data-fw-ajax="fwcrm_test_mailbox">Test connection</button><button type="button" class="fw-btn" data-fw-ajax="fwcrm_test_send">Send me a test email</button></div>';
    if (!empty($st['at'])) echo '<p class="fw-dim">Last sync ' . esc_html(fwcrm_time_ago($st['at'])) . ': ' . esc_html($st['msg']) . '</p>';
    echo '</div>';

    echo '<div class="fw-card"><h2>2 · Importing your scouting emails</h2><label class="fw-check"><input type="checkbox" name="import_sent" value="1"' . checked($s['import_sent'], 1, false) . '> Add everyone I email from webmail/phone as a lead and track their replies</label><div class="fw-row2"><label class="fw-f"><span>On first connect, import the last … days</span><input type="number" name="import_days" min="1" max="365" value="' . esc_attr($s['import_days']) . '"></label><label class="fw-f"><span>Remind me to follow up after … days</span><input type="number" name="followup_days" min="1" max="60" value="' . esc_attr($s['followup_days']) . '"></label></div><label class="fw-f"><span>Never import these domains/emails (clients, friends, services)</span><textarea name="ignore_domains" rows="2" placeholder="fiverr.com, hostinger.com, mum@gmail.com">' . esc_textarea($s['ignore_domains']) . '</textarea></label><label class="fw-f"><span>Start this sequence automatically for each new scouting email</span><select name="auto_enroll_seq"><option value="0">Off, just remind me</option>';
    foreach (fwcrm_get_sequences() as $q) echo '<option value="' . (int) $q->id . '"' . selected((int) $s['auto_enroll_seq'], (int) $q->id, false) . '>' . esc_html($q->name) . '</option>';
    echo '</select></label><label class="fw-check"><input type="checkbox" name="save_to_sent" value="1"' . checked($s['save_to_sent'], 1, false) . '> Save CRM-sent emails into my Sent folder too</label></div>';
    echo '</div><div>';

    echo '<div class="fw-card"><h2>3 · Sending rules</h2><p class="fw-dim">Slow and steady keeps you out of spam folders.</p><div class="fw-row3"><label class="fw-f"><span>Max emails / day</span><input type="number" name="daily_cap" min="1" max="200" value="' . esc_attr($s['daily_cap']) . '"></label><label class="fw-f"><span>Minutes between sends</span><input type="number" name="min_gap_minutes" min="0" max="120" value="' . esc_attr($s['min_gap_minutes']) . '"></label><label class="fw-f"><span>Sent today</span><input disabled value="' . esc_attr(fwcrm_sent_today()) . '"></label></div><div class="fw-row2"><label class="fw-f"><span>Send from (hour, ' . esc_html(wp_timezone_string()) . ')</span><input type="number" name="window_start" min="0" max="23" value="' . esc_attr($s['window_start']) . '"></label><label class="fw-f"><span>Until (hour)</span><input type="number" name="window_end" min="1" max="24" value="' . esc_attr($s['window_end']) . '"></label></div><div class="fw-days">';
    foreach (array(1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun') as $n => $l) echo '<label><input type="checkbox" name="workdays[]" value="' . $n . '"' . checked(in_array($n, array_map('intval', (array) $s['workdays']), true), true, false) . '><span>' . $l . '</span></label>';
    echo '</div><label class="fw-f"><span>Signature (added to every CRM email)</span><textarea name="signature" rows="3">' . esc_textarea($s['signature']) . '</textarea></label><label class="fw-check"><input type="checkbox" name="unsub_footer" value="1"' . checked($s['unsub_footer'], 1, false) . '> Add an opt-out line under each email</label><label class="fw-f"><span>Opt-out line</span><input name="unsub_text" value="' . esc_attr($s['unsub_text']) . '"></label></div>';

    echo '<div class="fw-card"><h2>4 · Tracking & alerts</h2><label class="fw-check"><input type="checkbox" name="track_opens" value="1"' . checked($s['track_opens'], 1, false) . '> Track email opens</label><label class="fw-check"><input type="checkbox" name="track_clicks" value="1"' . checked($s['track_clicks'], 1, false) . '> Track link clicks (and recognise leads on your website)</label><label class="fw-check"><input type="checkbox" name="track_visitors" value="1"' . checked($s['track_visitors'], 1, false) . '> Track website visitors</label><label class="fw-check"><input type="checkbox" name="track_admins" value="1"' . checked($s['track_admins'], 1, false) . '> Also count my own visits while logged in</label><label class="fw-f"><span>Send alerts to</span><input name="notify_email" value="' . esc_attr($s['notify_email']) . '"></label><label class="fw-check"><input type="checkbox" name="notify_reply" value="1"' . checked($s['notify_reply'], 1, false) . '> Email me when a lead replies</label><label class="fw-check"><input type="checkbox" name="notify_hot_visit" value="1"' . checked($s['notify_hot_visit'], 1, false) . '> Email me when a lead clicks or is on my website</label><label class="fw-check"><input type="checkbox" name="daily_digest" value="1"' . checked($s['daily_digest'], 1, false) . '> Daily summary email</label></div>';

    $cron = wp_next_scheduled('fwcrm_tick');
    echo '<div class="fw-card"><h2>5 · Background worker</h2><p class="fw-dim">Checks the mailbox and sends due follow-ups every 5 minutes. Last run: <b>' . esc_html(fwcrm_time_ago(get_option('fwcrm_last_tick'))) . '</b>' . ($cron ? ' · next ' . esc_html(human_time_diff(time(), $cron)) : '') . '.</p><p class="fw-dim">For rock-solid timing, add a cron job in hPanel → Advanced → Cron Jobs that runs every 5 minutes:<br><code>wget -q -O - ' . esc_html(site_url('wp-cron.php?doing_wp_cron')) . ' &gt;/dev/null 2&gt;&amp;1</code></p></div>';
    echo '</div></div><div class="fw-btnrow sticky"><button class="fw-btn gold">Save settings</button></div></form>';

    $log = get_option('fwcrm_log', array());
    if ($log) echo '<div class="fw-card"><details><summary><b>Activity log</b></summary><pre class="fw-log">' . esc_html(implode("\n", array_slice($log, 0, 40))) . '</pre></details></div>';
    fwcrm_footer();
}
