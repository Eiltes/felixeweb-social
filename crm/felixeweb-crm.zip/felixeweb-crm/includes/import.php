<?php
if (!defined('ABSPATH')) exit;

/**
 * Import leads from the scout tracker sheet (and a key-protected API so other tools can push leads in).
 */
add_action('rest_api_init', function () {
    register_rest_route('fwcrm/v1', '/import', array(
        'methods' => 'POST',
        'callback' => 'fwcrm_rest_import',
        'permission_callback' => function () { return current_user_can('manage_options'); },
    ));
    register_rest_route('fwcrm/v1', '/api/leads', array(
        'methods' => 'POST',
        'callback' => 'fwcrm_rest_import',
        'permission_callback' => function ($req) {
            $key = (string) fwcrm_opt('api_key');
            $sent = (string) $req->get_header('x-fw-key');
            return $key !== '' && $sent !== '' && hash_equals($key, $sent);
        },
    ));
});

function fwcrm_sheet_stage($status) {
    $s = strtolower(trim((string) $status));
    if ($s === 'replied') return 'replied';
    if (strpos($s, 'call') !== false) return 'call';
    if (strpos($s, 'proposal') !== false) return 'proposal';
    if ($s === 'won') return 'won';
    if (in_array($s, array('not a fit', 'lost', 'no'), true)) return 'lost';
    if ($s === '' || $s === 'new' || $s === 'found') return 'new';
    return 'contacted';
}

/** "Morning run · London, UK · email sent · …" → "London, UK" */
function fwcrm_country_from_notes($notes) {
    $parts = array_map('trim', explode('·', (string) $notes));
    foreach ($parts as $i => $p) {
        if (preg_match('/\b(run|batch|scout)\b/i', $p)) continue;
        if ($p === '' || preg_match('/^(email drafted|email sent|replied|bounced|follow|new address|drafted|sent|double|email drafted)/i', $p)) continue;
        if (preg_match('/\d{1,2}:\d{2}|@/', $p)) continue;
        return wp_html_excerpt(preg_replace('/\s*\(.*\)$/', '', $p), 78, '');
    }
    return '';
}

function fwcrm_parse_sheet_date($v) {
    if (is_array($v) && isset($v['date'])) $v = $v['date'];
    $v = trim((string) $v);
    if ($v === '') return '';
    $t = strtotime($v);
    return $t ? date('Y-m-d', $t) : '';
}

function fwcrm_import_lead($l) {
    global $wpdb;
    $email = fwcrm_clean_email(isset($l['email']) ? $l['email'] : '');
    if (!$email) return array('skipped' => 'no email');
    $owner = trim((string) (isset($l['owner']) ? $l['owner'] : ''));
    $first = $last = '';
    if ($owner && !preg_match('/team|unknown|n\/a/i', $owner)) {
        $bits = preg_split('/\s+/', preg_replace('/\s*\(.*\)$/', '', $owner), 2);
        $first = $bits[0];
        $last = isset($bits[1]) ? $bits[1] : '';
    }
    $notes = (string) (isset($l['notes']) ? $l['notes'] : '');
    $stage = fwcrm_sheet_stage(isset($l['status']) ? $l['status'] : '');
    $existing = fwcrm_get_contact_by_email($email);
    $cid = fwcrm_upsert_contact(array(
        'email' => $email,
        'first_name' => $first,
        'last_name' => $last,
        'company' => isset($l['business']) ? $l['business'] : '',
        'website' => isset($l['website']) ? $l['website'] : '',
        'niche' => isset($l['niche']) ? $l['niche'] : 'Research peptides',
        'country' => isset($l['country']) && $l['country'] ? $l['country'] : fwcrm_country_from_notes($notes),
        'platform' => isset($l['platform']) ? $l['platform'] : '',
        'problems' => isset($l['problems']) ? $l['problems'] : '',
        'socials' => isset($l['socials']) ? $l['socials'] : '',
        'notes' => $notes,
        'source' => 'scout',
        'stage' => $stage,
    ));
    if (!$cid) return array('skipped' => 'invalid');
    $c = fwcrm_get_contact($cid);
    $upd = array();
    if ($stage !== $c->stage && (in_array($stage, array('won', 'lost'), true) || fwcrm_stage_rank($stage) > fwcrm_stage_rank($c->stage))) $upd['stage'] = $stage;
    if (stripos($notes, 'BOUNCED') !== false) $upd['bounced'] = 1;
    if (stripos($notes, 'unsubscribe') !== false || strtolower(trim((string) $l['status'])) === 'not a fit') $upd['next_followup'] = null;
    $found = fwcrm_parse_sheet_date(isset($l['found']) ? $l['found'] : '');
    if ($found && !$existing) $upd['created'] = $found . ' 12:00:00';

    // The first email they were sent.
    $sent = fwcrm_parse_sheet_date(isset($l['sent']) ? $l['sent'] : '');
    if ($sent) {
        if (!$c->last_contacted || strtotime($c->last_contacted) < strtotime($sent)) $upd['last_contacted'] = $sent . ' 15:00:00';
        $has = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . fwcrm_t('emails') . " WHERE contact_id = %d AND direction = 'out' AND DATE(sent_at) = %s LIMIT 1", $cid, $sent));
        if (!$has && !empty($l['body'])) {
            $wpdb->insert(fwcrm_t('emails'), array(
                'contact_id' => $cid, 'direction' => 'out', 'kind' => 'email',
                'subject' => wp_html_excerpt((string) $l['subject'], 250, ''),
                'body' => (string) $l['body'],
                'snippet' => wp_html_excerpt((string) $l['body'], 240, '…'),
                'from_email' => fwcrm_opt('from_email'), 'to_email' => $email,
                'source' => 'sheet', 'status' => 'sent', 'sent_at' => $sent . ' 15:00:00',
            ));
        }
    }
    // A reply noted in the sheet ("REPLIED Nov 19: wants the video…")
    if (preg_match('/REPLIED\s+([A-Za-z]{3,9}\s+\d{1,2})[^:]*:\s*([^·]+)/i', $notes, $m)) {
        $t = strtotime($m[1] . ' ' . date('Y'));
        if ($t && $t > current_time('timestamp') + DAY_IN_SECONDS) $t = strtotime('-1 year', $t);
        $when = $t ? date('Y-m-d 12:00:00', $t) : fwcrm_now();
        if (!$c->last_reply) {
            $upd['last_reply'] = $when;
            $upd['score'] = max((int) $c->score, 25);
            fwcrm_event($cid, 'reply', array('snippet' => wp_html_excerpt(trim($m[2]), 160, '…'), 'via' => 'sheet'));
        }
    }
    if ($upd) fwcrm_update_contact($cid, $upd);
    return array('id' => $cid, 'new' => !$existing);
}

function fwcrm_rest_import($req) {
    $p = $req->get_json_params();
    $leads = isset($p['leads']) && is_array($p['leads']) ? $p['leads'] : (is_array($p) && isset($p[0]) ? $p : array());
    $res = array('added' => 0, 'updated' => 0, 'skipped' => 0);
    foreach ($leads as $l) {
        $r = fwcrm_import_lead((array) $l);
        if (isset($r['skipped'])) $res['skipped']++;
        elseif (!empty($r['new'])) $res['added']++;
        else $res['updated']++;
    }
    if ($leads) fwcrm_log(sprintf('Imported leads: %d new, %d updated, %d skipped', $res['added'], $res['updated'], $res['skipped']));
    return new WP_REST_Response($res, 200);
}
