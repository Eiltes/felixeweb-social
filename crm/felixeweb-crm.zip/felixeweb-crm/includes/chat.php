<?php
/**
 * Chat-style email conversations (lead page + Inbox messenger).
 */
if (!defined('ABSPATH')) exit;

/** All emails + key activity for one lead, oldest first. */
function fwcrm_chat_items($contact_id) {
    global $wpdb;
    $T = 'fwcrm_t';
    $items = array();
    $emails = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$T('emails')} WHERE contact_id=%d AND kind<>'hub_sync' ORDER BY sent_at ASC, id ASC LIMIT 300", $contact_id));
    foreach ($emails as $e) $items[] = array('t' => strtotime($e->sent_at), 'kind' => 'email', 'o' => $e);
    $events = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$T('events')} WHERE contact_id=%d AND type IN ('open','click','cta_click','stage','note','unsubscribe','sequence_stopped') ORDER BY id ASC LIMIT 200", $contact_id));
    foreach ($events as $e) $items[] = array('t' => strtotime($e->created), 'kind' => 'event', 'o' => $e);
    // Scout emails imported from the sheet only carry a date, so a reply can look older than the email it answers.
    $first_reply = array();
    foreach ($emails as $e) {
        if ($e->direction !== 'in' || $e->kind !== 'reply') continue;
        $k = strtolower(fwcrm_strip_re($e->subject));
        $t = strtotime($e->sent_at);
        if (!isset($first_reply[$k]) || $t < $first_reply[$k]) $first_reply[$k] = $t;
    }
    foreach ($items as &$it) {
        if ($it['kind'] !== 'email') continue;
        $o = $it['o'];
        if ($o->direction !== 'out' || $o->kind !== 'email' || $o->source !== 'sheet') continue;
        $k = strtolower(fwcrm_strip_re($o->subject));
        if (isset($first_reply[$k]) && $it['t'] >= $first_reply[$k]) $it['t'] = $first_reply[$k] - 60;
    }
    unset($it);
    usort($items, function ($a, $b) { return $a['t'] - $b['t']; });
    return $items;
}

function fwcrm_chat_text($o) {
    $t = (string) ($o->body !== null && $o->body !== '' ? $o->body : $o->snippet);
    $t = fwcrm_clean_text($t);
    return $t !== '' ? $t : '(no text)';
}

function fwcrm_chat_day($ts) {
    $d = date_i18n('Y-m-d', $ts);
    if ($d === date_i18n('Y-m-d')) return 'Today';
    if ($d === date_i18n('Y-m-d', current_time('timestamp') - DAY_IN_SECONDS)) return 'Yesterday';
    return date_i18n('l j M Y', $ts);
}

function fwcrm_chat_source($o) {
    if ($o->kind === 'followup') return 'Auto follow-up' . ($o->step ? ' #' . (int) $o->step : '');
    if ($o->source === 'sheet') return 'Scout';
    if ($o->source === 'scout') return preg_match('/^\s*(re|fwd?)\s*:/i', $o->subject) ? 'Gmail' : 'Scout';
    if ($o->source === 'webmail') return 'Webmail';
    return 'CRM';
}

/**
 * Render a chat conversation for a lead.
 * $back: 'contact' (lead page) or 'inbox'.
 */
function fwcrm_render_chat($c, $back = 'contact') {
    $items = fwcrm_chat_items($c->id);
    $last_in = null; $last_out = null; $unread = array();
    foreach ($items as $it) {
        if ($it['kind'] !== 'email') continue;
        $o = $it['o'];
        if ($o->direction === 'in' && $o->kind === 'reply') { $last_in = $o; if (!$o->handled) $unread[] = (int) $o->id; }
        if ($o->direction === 'out' && $o->status === 'sent') $last_out = $o;
    }
    $who = fwcrm_lead_title($c);
    $person = trim($c->first_name . ' ' . $c->last_name);

    echo '<div class="fw-convo" data-fw-chat>';
    // Header
    echo '<div class="fw-chat-h">';
    if ($back === 'inbox') echo '<a class="fw-chat-back" href="' . esc_url(fwcrm_admin_url('fwcrm-inbox', isset($_GET['tab']) ? array('tab' => sanitize_key($_GET['tab'])) : array())) . '" aria-label="Back">←</a>';
    echo '<div class="fw-av">' . esc_html(strtoupper(mb_substr($who, 0, 1))) . '</div><div class="fw-chat-who"><a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $c->id))) . '"><b>' . esc_html($who) . '</b></a><small>' . esc_html($person && $person !== $who ? $person . ' · ' : '') . esc_html($c->email) . '</small></div>';
    echo '<div class="fw-chat-act">' . fwcrm_stage_pill($c->stage) . ($c->website ? fwcrm_site_link($c, 'fw-btn sm') : '');
    if ($unread) echo '<button class="fw-btn sm ghost" data-fw-ajax="fwcrm_handled_all" data-id="' . (int) $c->id . '" title="Already answered (e.g. from Gmail) or nothing to say">Mark handled</button>';
    echo '</div></div>';

    // Messages
    echo '<div class="fw-chat-body">';
    if (!$items) echo '<div class="fw-chat-empty">No messages yet. Write the first one below.</div>';
    $day = '';
    foreach ($items as $it) {
        $o = $it['o'];
        $d = fwcrm_chat_day($it['t']);
        if ($d !== $day) { echo '<div class="fw-chat-day"><span>' . esc_html($d) . '</span></div>'; $day = $d; }
        $time = date_i18n('H:i', $it['t']);
        if ($it['kind'] === 'event') {
            $txt = fwcrm_event_text((object) array_merge((array) $o, array('contact_id' => 0, 'first_name' => $c->first_name, 'last_name' => $c->last_name, 'email' => $c->email)));
            echo '<div class="fw-chat-sys t-' . esc_attr($o->type) . '">' . wp_kses_post($txt) . ' · ' . esc_html($time) . '</div>';
            continue;
        }
        if ($o->direction === 'in' && $o->kind !== 'reply') {
            $lab = $o->kind === 'bounce' ? '⚠ Bounced: this address did not receive the email' : 'Auto-reply';
            echo '<details class="fw-chat-sys warn"><summary>' . esc_html($lab) . ' · ' . esc_html($time) . '</summary><pre>' . esc_html(wp_html_excerpt(fwcrm_chat_text($o), 1200, '…')) . '</pre></details>';
            continue;
        }
        $mine = $o->direction === 'out';
        $meta = esc_html($time);
        if ($mine) {
            $meta = esc_html(fwcrm_chat_source($o)) . ' · ' . $meta;
            if ($o->status === 'failed') $meta .= ' · <span class="fw-flag">failed</span>';
            elseif ($o->source === 'crm') $meta .= $o->opens ? ' · <span class="fw-seen">✓✓ opened</span>' : ' · ✓ sent';
            else $meta .= ' · ✓ sent';
        }
        echo '<div class="fw-bubble ' . ($mine ? 'me' : 'them') . ($o->direction === 'in' && !$o->handled ? ' new' : '') . '">';
        if ($o->subject) echo '<div class="fw-bubble-s">' . esc_html($o->subject) . '</div>';
        echo '<div class="fw-bubble-t">' . nl2br(esc_html(fwcrm_chat_text($o))) . '</div><div class="fw-bubble-m">' . $meta . '</div></div>';
    }
    echo '</div>';

    // Composer
    $base = $last_in ?: $last_out;
    $subject = $base ? 'Re: ' . fwcrm_strip_re($base->subject) : '';
    echo fwcrm_post_form_open('fwcrm_send', 'class="fw-chat-box"') . '<input type="hidden" name="id" value="' . (int) $c->id . '">';
    if ($base && $base->message_id) echo '<input type="hidden" name="thread" value="' . esc_attr($base->message_id) . '">';
    echo '<input type="hidden" name="back" value="' . esc_attr($back) . '">';
    if ($unread) echo '<input type="hidden" name="handled" value="' . (int) end($unread) . '">';
    if (!empty($_GET['tab'])) echo '<input type="hidden" name="tab" value="' . esc_attr(sanitize_key($_GET['tab'])) . '">';
    echo '<input class="fw-chat-subj" name="subject" value="' . esc_attr($subject) . '" placeholder="Subject">';
    if (function_exists('fwcrm_composer_tools')) echo fwcrm_composer_tools($c);
    echo '<div class="fw-chat-row"><textarea name="body" rows="1" placeholder="Message ' . esc_attr($c->first_name ?: $who) . '…" required></textarea><button class="fw-chat-send" aria-label="Send" title="Send (Ctrl + Enter)">➤</button></div>';
    echo '<div class="fw-chat-hint">Sends from hello@felixeweb.com in the same email thread · signature added · Ctrl + Enter to send</div></form>';
    echo '</div>';
}

/** Conversations list for the Inbox messenger. */
function fwcrm_conversations($filter, $q = '') {
    global $wpdb;
    $T = 'fwcrm_t';
    $having = array(
        'waiting' => 'HAVING unread > 0',
        'replied' => 'HAVING replies > 0',
        'all' => '',
    );
    $h = isset($having[$filter]) ? $having[$filter] : $having['waiting'];
    $search = '';
    if ($q !== '') {
        $like = '%' . $wpdb->esc_like($q) . '%';
        $search = $wpdb->prepare(' AND (c.company LIKE %s OR c.email LIKE %s OR c.first_name LIKE %s OR c.website LIKE %s)', $like, $like, $like, $like);
    }
    $rows = $wpdb->get_results("SELECT c.*, MAX(e.sent_at) last_at,
        SUM(e.direction='in' AND e.kind='reply' AND e.handled=0) unread,
        SUM(e.direction='in' AND e.kind='reply') replies
        FROM {$T('contacts')} c JOIN {$T('emails')} e ON e.contact_id=c.id AND e.kind IN ('email','followup','reply') AND (e.direction='in' OR e.status='sent')
        WHERE 1=1 $search GROUP BY c.id $h ORDER BY last_at DESC LIMIT 300");
    if (!$rows) return array();
    $ids = implode(',', array_map('intval', wp_list_pluck($rows, 'id')));
    $last = array();
    foreach ($wpdb->get_results("SELECT contact_id, direction, subject, body, snippet FROM {$T('emails')} WHERE contact_id IN ($ids) AND kind IN ('email','followup','reply') AND (direction='in' OR status='sent') ORDER BY sent_at DESC, id DESC") as $e) {
        if (!isset($last[$e->contact_id])) $last[$e->contact_id] = $e;
    }
    foreach ($rows as $r) $r->last = isset($last[$r->id]) ? $last[$r->id] : null;
    return $rows;
}

/** Remove tracker-sheet copies of emails that were later imported for real from a mailbox. */
function fwcrm_dedupe_sheet_emails() {
    global $wpdb;
    $T = fwcrm_t('emails');
    $rows = $wpdb->get_results("SELECT s.id FROM $T s JOIN $T r ON r.contact_id = s.contact_id AND r.id <> s.id AND r.direction = 'out' AND r.source <> 'sheet' AND LOWER(TRIM(r.subject)) = LOWER(TRIM(s.subject)) WHERE s.source = 'sheet' AND s.direction = 'out'");
    $ids = array_unique(array_map('intval', wp_list_pluck($rows, 'id')));
    if ($ids) $wpdb->query("DELETE FROM $T WHERE id IN (" . implode(',', $ids) . ")");
    return count($ids);
}

/** A reply counts as handled once Felix has sent anything to that lead after it. */
function fwcrm_mark_answered() {
    global $wpdb;
    $T = fwcrm_t('emails');
    $ids = $wpdb->get_col("SELECT i.id FROM $T i WHERE i.direction = 'in' AND i.handled = 0 AND EXISTS (SELECT 1 FROM $T o WHERE o.contact_id = i.contact_id AND o.direction = 'out' AND o.status = 'sent' AND o.source <> 'sheet' AND o.sent_at > i.sent_at)");
    $ids = array_map('intval', $ids);
    if ($ids) $wpdb->query("UPDATE $T SET handled = 1 WHERE id IN (" . implode(',', $ids) . ")");
    return count($ids);
}
