<?php
if (!defined('ABSPATH')) exit;

/**
 * Sync the mailbox:
 *  1. Sent folder → import scouting emails sent from webmail/phone as contacts + outbound emails.
 *  2. INBOX → detect replies, bounces, auto-replies and new inbound leads.
 */
function fwcrm_sync_mailbox($manual = false) {
    $accounts = fwcrm_mail_accounts();
    if (!$accounts) return new WP_Error('fwcrm', 'No mailbox connected');
    $total = array('sent' => 0, 'replies' => 0, 'bounces' => 0, 'inbound' => 0);
    $errors = array();
    foreach ($accounts as $acct) {
        $r = fwcrm_sync_account($acct, $manual);
        if (is_wp_error($r)) { $errors[] = $acct['label'] . ': ' . $r->get_error_message(); continue; }
        foreach ($total as $k => $v) $total[$k] += $r[$k];
    }
    $state = get_option('fwcrm_sync_state', array());
    if (!is_array($state)) $state = array();
    if (empty($state['connected_at'])) {
        $state['connected_at'] = fwcrm_now();
        update_option('fwcrm_sync_state', $state, false);
    }
    if ($errors && count($errors) === count($accounts)) {
        update_option('fwcrm_mailbox_status', array('ok' => 0, 'msg' => implode(' · ', $errors), 'at' => fwcrm_now()), false);
        return new WP_Error('fwcrm', implode(' · ', $errors));
    }
    update_option('fwcrm_mailbox_status', array('ok' => 1, 'msg' => $errors ? 'Partly synced: ' . implode(' · ', $errors) : 'Connected (' . count($accounts) . ' mailbox' . (count($accounts) > 1 ? 'es' : '') . ')', 'at' => fwcrm_now(), 'stats' => $total), false);
    return $total;
}

function fwcrm_sync_account($acct, $manual) {
    $imap = new FWCRM_IMAP();
    if (!$imap->connect($acct['host'], $acct['port'], $acct['user'], $acct['pass'])) {
        fwcrm_log('Mailbox sync failed (' . $acct['label'] . '): ' . $imap->error);
        return new WP_Error('fwcrm', $imap->error);
    }
    $state = get_option('fwcrm_sync_state', array());
    if (!is_array($state)) $state = array();
    $since = current_time('timestamp') - max(1, (int) $acct['days']) * DAY_IN_SECONDS;
    $stats = array('sent' => 0, 'replies' => 0, 'bounces' => 0, 'inbound' => 0);
    $budget = $manual ? 400 : 150;
    $pre = $acct['key'] === 'main' ? '' : $acct['key'] . '_';

    // 1. Sent folder
    if (fwcrm_opt('import_sent')) {
        $sent_folder = $acct['sent_folder'];
        if (!$sent_folder) {
            $sent_folder = $imap->find_sent_folder();
            if ($sent_folder && $acct['key'] === 'main') fwcrm_save_settings(array('sent_folder' => $sent_folder));
        }
        if ($sent_folder) {
            $info = $imap->select($sent_folder);
            if ($info) {
                $key = $pre . 'sent';
                $last = (isset($state[$key]['v']) && $state[$key]['v'] == $info['uidvalidity']) ? (int) $state[$key]['uid'] : 0;
                $first_run = $last === 0;
                $uids = array_slice($imap->search_uids($last, $since), 0, $budget);
                foreach ($imap->fetch_messages($uids) as $uid => $msg) {
                    if (fwcrm_process_sent($msg, $first_run, $acct)) $stats['sent']++;
                    $last = max($last, $uid);
                }
                if (!$uids && $info['uidnext']) $last = max($last, $info['uidnext'] - 1);
                $state[$key] = array('v' => $info['uidvalidity'], 'uid' => $last);
                $budget -= count($uids);
            }
        }
    }

    // 2. Inbox
    $info = $imap->select('INBOX');
    if ($info && $budget > 0) {
        $key = $pre . 'inbox';
        $last = (isset($state[$key]['v']) && $state[$key]['v'] == $info['uidvalidity']) ? (int) $state[$key]['uid'] : 0;
        $first_run = $last === 0;
        $uids = array_slice($imap->search_uids($last, $since), 0, $budget);
        foreach ($imap->fetch_messages($uids) as $uid => $msg) {
            $r = fwcrm_process_inbound($msg, $first_run, $acct);
            if ($r && isset($stats[$r])) $stats[$r]++;
            $last = max($last, $uid);
        }
        if (!$uids && $info['uidnext']) $last = max($last, $info['uidnext'] - 1);
        $state[$key] = array('v' => $info['uidvalidity'], 'uid' => $last);
    }
    $imap->logout();
    $fresh = get_option('fwcrm_sync_state', array());
    if (!is_array($fresh)) $fresh = array();
    foreach ($state as $k => $v) if (strpos($k, $pre . 'sent') === 0 || strpos($k, $pre . 'inbox') === 0) $fresh[$k] = $v;
    update_option('fwcrm_sync_state', $fresh, false);
    return $stats;
}

function fwcrm_msg_basics($msg) {
    $h = fwcrm_parse_headers($msg['header']);
    $date = isset($h['date']) ? strtotime($h['date']) : false;
    return array(
        'h' => $h,
        'from' => fwcrm_addresses(isset($h['from']) ? $h['from'] : ''),
        'from_name' => fwcrm_display_name(isset($h['from']) ? $h['from'] : ''),
        'to' => fwcrm_addresses(isset($h['to']) ? $h['to'] : ''),
        'to_raw' => isset($h['to']) ? $h['to'] : '',
        'subject' => fwcrm_decode_header(isset($h['subject']) ? $h['subject'] : ''),
        'message_id' => isset($h['message-id']) ? trim($h['message-id']) : '',
        'in_reply_to' => isset($h['in-reply-to']) ? trim($h['in-reply-to']) : '',
        'references' => isset($h['references']) ? trim($h['references']) : '',
        'ts' => $date ? $date + (int) (get_option('gmt_offset') * HOUR_IN_SECONDS) : current_time('timestamp'),
        'text' => fwcrm_body_text($h, $msg['body']),
    );
}

function fwcrm_email_exists($message_id) {
    global $wpdb;
    if (!$message_id) return false;
    return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM " . fwcrm_t('emails') . " WHERE message_id = %s LIMIT 1", $message_id));
}

function fwcrm_ignored_address($email) {
    $own = array_filter(array(strtolower(fwcrm_opt('mail_user')), strtolower(fwcrm_opt('from_email')), strtolower(fwcrm_opt('notify_email')), strtolower(fwcrm_opt('gmail_user'))));
    if (in_array($email, $own, true)) return true;
    $domain = substr(strrchr($email, '@'), 1);
    $ignore = array_filter(array_map('trim', preg_split('/[\s,]+/', strtolower((string) fwcrm_opt('ignore_domains')))));
    if (in_array($domain, $ignore, true) || in_array($email, $ignore, true)) return true;
    if (preg_match('/^(no-?reply|do-?not-?reply|mailer-daemon|postmaster|notifications?|bounce|support@hostinger)/i', $email)) return true;
    return false;
}

/** A message found in the Sent folder. Returns true if imported. */
function fwcrm_process_sent($msg, $first_run, $acct = null) {
    if (!$acct) $acct = array('key' => 'main', 'from_filter' => '', 'schedule_followups' => true, 'source' => 'webmail', 'create_inbound' => true);
    global $wpdb;
    $m = fwcrm_msg_basics($msg);
    if (isset($m['h']['x-fwcrm'])) return false;               // sent by the CRM itself
    if ($m['message_id'] && fwcrm_email_exists($m['message_id'])) return false;
    if (!empty($acct['from_filter'])) {
        $from = fwcrm_addresses(isset($m['h']['from']) ? $m['h']['from'] : '');
        if (!in_array($acct['from_filter'], $from, true)) return false;   // e.g. only emails sent as hello@ from Gmail
    }
    $to = '';
    foreach ($m['to'] as $addr) { if (!fwcrm_ignored_address($addr)) { $to = $addr; break; } }
    if (!$to) return false;

    // Is this Felix answering an inbound email? Then mark that reply handled.
    $answered = null;
    if ($m['in_reply_to']) {
        $answered = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('emails') . " WHERE message_id = %s AND direction = 'in'", $m['in_reply_to']));
    }

    $name = fwcrm_display_name($m['to_raw']);
    $first = $last = '';
    if ($name && strpos($name, '@') === false) {
        $bits = preg_split('/\s+/', $name, 2);
        $first = $bits[0];
        $last = isset($bits[1]) ? $bits[1] : '';
    }
    $existing = fwcrm_get_contact_by_email($to);
    $cid = fwcrm_upsert_contact(array('email' => $to, 'first_name' => $first, 'last_name' => $last, 'source' => $existing ? $existing->source : ($acct['source'] === 'scout' ? 'scout' : 'scouting')));
    if (!$cid) return false;

    $sent_at = date('Y-m-d H:i:s', $m['ts']);
    $refs = trim($m['references']);
    $root = $refs ? preg_split('/\s+/', $refs)[0] : ($m['in_reply_to'] ? $m['in_reply_to'] : $m['message_id']);
    // A lead imported from the tracker sheet already has this email logged (without headers): attach the real one.
    $sheet = $wpdb->get_row($wpdb->prepare("SELECT id FROM " . fwcrm_t('emails') . " WHERE contact_id = %d AND source = 'sheet' AND message_id = '' AND DATE(sent_at) = %s ORDER BY id ASC LIMIT 1", $cid, date('Y-m-d', $m['ts'])));
    if ($sheet) {
        $wpdb->update(fwcrm_t('emails'), array('message_id' => $m['message_id'], 'in_reply_to' => $m['in_reply_to'], 'thread_root' => $root, 'subject' => wp_html_excerpt($m['subject'], 250, ''), 'body' => $m['text'], 'source' => $acct['source'], 'sent_at' => $sent_at), array('id' => $sheet->id));
        return true;
    }
    $wpdb->insert(fwcrm_t('emails'), array(
        'contact_id' => $cid,
        'direction' => 'out',
        'kind' => $answered ? 'reply_out' : 'email',
        'subject' => wp_html_excerpt($m['subject'], 250, ''),
        'body' => $m['text'],
        'snippet' => wp_html_excerpt($m['text'], 240, '…'),
        'from_email' => fwcrm_opt('mail_user'),
        'to_email' => $to,
        'message_id' => $m['message_id'],
        'in_reply_to' => $m['in_reply_to'],
        'thread_root' => $root,
        'token' => '',
        'source' => $acct['source'],
        'status' => 'sent',
        'sent_at' => $sent_at,
    ));
    $email_id = (int) $wpdb->insert_id;
    $c = fwcrm_get_contact($cid);
    if (!$c->last_contacted || strtotime($c->last_contacted) < $m['ts']) {
        fwcrm_update_contact($cid, array('last_contacted' => $sent_at));
    }
    fwcrm_bump_stage($cid, 'contacted');
    fwcrm_event($cid, 'sent', array('subject' => $m['subject'], 'via' => $acct['source']), $email_id);

    if ($answered) {
        $wpdb->update(fwcrm_t('emails'), array('handled' => 1), array('id' => $answered->id));
        return true;
    }

    // New outreach with no reply yet → schedule a follow-up (not for the scout mailbox: the scout tasks send their own follow-ups).
    $c = fwcrm_get_contact($cid);
    if (!empty($acct['schedule_followups']) && !$c->last_reply && !$c->unsubscribed) {
        $state = get_option('fwcrm_sync_state', array());
        $connected_at = !empty($state['connected_at']) ? strtotime($state['connected_at']) : current_time('timestamp');
        $seq_id = (int) fwcrm_opt('auto_enroll_seq');
        $is_new = $m['ts'] >= $connected_at - HOUR_IN_SECONDS && !$first_run;
        if ($seq_id && $is_new) {
            fwcrm_enroll($cid, $seq_id);
        } elseif (!$c->next_followup) {
            $due = $m['ts'] + (int) fwcrm_opt('followup_days', 3) * DAY_IN_SECONDS;
            fwcrm_update_contact($cid, array('next_followup' => date('Y-m-d H:i:s', $due)));
        }
    }
    return true;
}

/** A message found in the INBOX. Returns 'replies' | 'bounces' | 'inbound' | null. */
function fwcrm_process_inbound($msg, $first_run, $acct = null) {
    if (!$acct) $acct = array('key' => 'main', 'create_inbound' => true);
    global $wpdb;
    $m = fwcrm_msg_basics($msg);
    if (isset($m['h']['x-fwcrm'])) return null;
    if ($m['message_id'] && fwcrm_email_exists($m['message_id'])) return null;
    $from = isset($m['from'][0]) ? $m['from'][0] : '';
    if (!$from) return null;
    // Gmail: replies forwarded from hello@ arrive "from" the lead or wrapped; try Reply-To / X-Original-From too.
    if (in_array($from, array(strtolower(fwcrm_opt('mail_user')), strtolower(fwcrm_opt('from_email')), strtolower(fwcrm_opt('gmail_user'))), true)) {
        foreach (array('x-original-from', 'reply-to', 'x-forwarded-for') as $hk) {
            if (!empty($m['h'][$hk])) { $alt = fwcrm_addresses($m['h'][$hk]); if ($alt && !fwcrm_ignored_address($alt[0])) { $from = $alt[0]; break; } }
        }
    }
    if (in_array($from, array(strtolower(fwcrm_opt('mail_user')), strtolower(fwcrm_opt('from_email')), strtolower(fwcrm_opt('gmail_user'))), true)) return null;
    $at = date('Y-m-d H:i:s', $m['ts']);

    // Bounces
    $subj = strtolower($m['subject']);
    if (preg_match('/^(mailer-daemon|postmaster)@/i', $from) || preg_match('/undeliver|delivery status notification|mail delivery failed|returned mail|delivery has failed|failure notice/', $subj)) {
        $raw = $msg['header'] . "\n" . $msg['body'];
        $target = null;
        if (preg_match('/(?:Final|Original)-Recipient:\s*rfc822;\s*([^\s]+)/i', $raw, $mm)) $target = fwcrm_get_contact_by_email($mm[1]);
        if (!$target) {
            foreach (fwcrm_addresses($raw) as $addr) {
                if (fwcrm_ignored_address($addr)) continue;
                $target = fwcrm_get_contact_by_email($addr);
                if ($target) break;
            }
        }
        if ($target) {
            fwcrm_update_contact($target->id, array('bounced' => 1, 'next_followup' => null));
            fwcrm_stop_enrollments($target->id, 'bounced');
            $wpdb->insert(fwcrm_t('emails'), array('contact_id' => $target->id, 'direction' => 'in', 'kind' => 'bounce', 'subject' => wp_html_excerpt($m['subject'], 250, ''), 'snippet' => wp_html_excerpt($m['text'], 240, '…'), 'from_email' => $from, 'to_email' => fwcrm_opt('mail_user'), 'message_id' => $m['message_id'], 'source' => 'imap', 'status' => 'received', 'handled' => 1, 'sent_at' => $at));
            fwcrm_event($target->id, 'bounce', array('subject' => $m['subject']));
            return 'bounces';
        }
        return null;
    }

    // Which contact is this about? Thread headers first, then sender address.
    $contact = null;
    $ids = array_filter(array_merge(array($m['in_reply_to']), preg_split('/\s+/', $m['references'])));
    if ($ids) {
        $ph = implode(',', array_fill(0, count($ids), '%s'));
        $cid = $wpdb->get_var($wpdb->prepare("SELECT contact_id FROM " . fwcrm_t('emails') . " WHERE message_id IN ($ph) AND contact_id > 0 ORDER BY id DESC LIMIT 1", $ids));
        if ($cid) $contact = fwcrm_get_contact($cid);
    }
    if (!$contact) $contact = fwcrm_get_contact_by_email($from);

    $h = $m['h'];
    $is_bulk = isset($h['list-unsubscribe']) || isset($h['list-id']) || (isset($h['precedence']) && preg_match('/bulk|list|junk/i', $h['precedence']));
    $is_auto = (isset($h['auto-submitted']) && stripos($h['auto-submitted'], 'no') !== 0) || isset($h['x-autoreply']) || isset($h['x-autorespond']) || preg_match('/^(auto(matic)?[ -]?reply|out of (the )?office|ooo\b|abwesenheit|absence|réponse automatique|respuesta automática)/i', $m['subject']);

    if (!$contact) {
        // Unknown sender: only keep genuine people writing in (new inbound leads), and never from the personal Gmail.
        if (empty($acct['create_inbound'])) return null;
        if ($is_bulk || $is_auto || fwcrm_ignored_address($from)) return null;
        if ($first_run) return null; // don't flood the CRM with old inbox mail on first connect
        $first = $last = '';
        if ($m['from_name']) {
            $bits = preg_split('/\s+/', $m['from_name'], 2);
            $first = $bits[0];
            $last = isset($bits[1]) ? $bits[1] : '';
        }
        $cid = fwcrm_upsert_contact(array('email' => $from, 'first_name' => $first, 'last_name' => $last, 'source' => 'inbound', 'stage' => 'replied'));
        $contact = fwcrm_get_contact($cid);
        $kind = 'reply';
        $type = 'inbound';
    } else {
        $kind = $is_auto ? 'auto_reply' : 'reply';
        $type = $is_auto ? null : 'replies';
    }
    if (!$contact) return null;

    $refs = trim($m['references']);
    $wpdb->insert(fwcrm_t('emails'), array(
        'contact_id' => $contact->id,
        'direction' => 'in',
        'kind' => $kind,
        'subject' => wp_html_excerpt($m['subject'], 250, ''),
        'body' => $m['text'],
        'snippet' => wp_html_excerpt($m['text'], 240, '…'),
        'from_email' => $from,
        'to_email' => fwcrm_opt('mail_user'),
        'message_id' => $m['message_id'],
        'in_reply_to' => $m['in_reply_to'],
        'thread_root' => $refs ? preg_split('/\s+/', $refs)[0] : ($m['in_reply_to'] ? $m['in_reply_to'] : $m['message_id']),
        'source' => 'imap',
        'status' => 'received',
        'handled' => $kind === 'reply' ? 0 : 1,
        'sent_at' => $at,
    ));
    $email_id = (int) $wpdb->insert_id;

    if ($kind === 'auto_reply') {
        fwcrm_event($contact->id, 'auto_reply', array('subject' => $m['subject']), $email_id);
        return null;
    }

    $upd = array('next_followup' => null);
    if (!$contact->last_reply || strtotime($contact->last_reply) < $m['ts']) $upd['last_reply'] = $at;
    fwcrm_update_contact($contact->id, $upd);
    fwcrm_bump_stage($contact->id, 'replied');
    fwcrm_stop_enrollments($contact->id, 'replied');
    fwcrm_add_score($contact->id, 25);
    fwcrm_event($contact->id, 'reply', array('subject' => $m['subject'], 'snippet' => wp_html_excerpt($m['text'], 160, '…')), $email_id);

    if (preg_match('/\b(unsubscribe|remove me|stop emailing|not interested|no thanks|no thank you)\b/i', $m['text'])) {
        fwcrm_event($contact->id, 'negative_reply', array());
    }
    if (!$first_run && fwcrm_opt('notify_reply')) {
        fwcrm_notify(
            ($type === 'inbound' ? 'New inbound email from ' : 'New reply from ') . fwcrm_contact_name($contact),
            array('Subject: ' . $m['subject'], '', wp_html_excerpt($m['text'], 600, '…')),
            fwcrm_admin_url('fwcrm-contacts', array('view' => $contact->id))
        );
    }
    return $type;
}
