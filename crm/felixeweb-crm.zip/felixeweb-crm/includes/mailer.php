<?php
if (!defined('ABSPATH')) exit;

/** Configure PHPMailer only while the CRM is sending. */
add_action('phpmailer_init', function ($mailer) {
    if (empty($GLOBALS['fwcrm_sending'])) return;
    $ctx = $GLOBALS['fwcrm_sending'];
    $mailer->isSMTP();
    $mailer->Host = fwcrm_opt('smtp_host');
    $mailer->Port = (int) fwcrm_opt('smtp_port');
    $mailer->SMTPSecure = fwcrm_opt('smtp_secure') === 'tls' ? 'tls' : 'ssl';
    $mailer->SMTPAuth = true;
    $mailer->Username = fwcrm_opt('mail_user');
    $mailer->Password = fwcrm_mail_pass();
    $mailer->Timeout = 25;
    $mailer->CharSet = 'UTF-8';
    $mailer->setFrom(fwcrm_opt('from_email'), fwcrm_opt('from_name'), false);
    $mailer->Sender = fwcrm_opt('from_email');
    if (!empty($ctx['message_id'])) $mailer->MessageID = $ctx['message_id'];
    if (!empty($ctx['alt'])) $mailer->AltBody = $ctx['alt'];
    $mailer->XMailer = ' ';
    if (defined('FWCRM_INSECURE_TLS') && FWCRM_INSECURE_TLS) {
        $mailer->SMTPOptions = array('ssl' => array('verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true));
    }
}, 99);

add_filter('wp_mail_from', function ($from) {
    return !empty($GLOBALS['fwcrm_sending']) ? fwcrm_opt('from_email') : $from;
}, 99);
add_filter('wp_mail_from_name', function ($name) {
    return !empty($GLOBALS['fwcrm_sending']) ? fwcrm_opt('from_name') : $name;
}, 99);

add_action('wp_mail_failed', function ($err) {
    if (!empty($GLOBALS['fwcrm_sending'])) {
        $GLOBALS['fwcrm_last_error'] = $err->get_error_message();
    }
});

function fwcrm_mail_domain() {
    $from = fwcrm_opt('from_email');
    $d = substr(strrchr($from, '@'), 1);
    return $d ? $d : wp_parse_url(home_url(), PHP_URL_HOST);
}

/**
 * Send one email to a contact.
 * $o: subject, body (plain text with {{vars}}), sequence_id, step, in_reply_to, references, kind, merge (bool)
 * Returns email row id or WP_Error.
 */
function fwcrm_send_email($contact_id, $o) {
    global $wpdb;
    $c = fwcrm_get_contact($contact_id);
    if (!$c) return new WP_Error('fwcrm', 'Contact not found');
    if ($c->unsubscribed) return new WP_Error('fwcrm', 'Contact has unsubscribed');
    if ($c->bounced) return new WP_Error('fwcrm', 'Email address bounced before');
    if (!fwcrm_mailbox_ready()) return new WP_Error('fwcrm', 'Connect your mailbox in CRM → Settings first');

    $merge = !isset($o['merge']) || $o['merge'];
    $subject = $merge ? fwcrm_merge($o['subject'], $c) : $o['subject'];
    $body_txt = $merge ? fwcrm_merge($o['body'], $c) : $o['body'];
    $signature = trim((string) fwcrm_opt('signature'));
    if ($signature !== '' && empty($o['no_signature'])) $body_txt = rtrim($body_txt) . "\n\n" . $signature;
    if (fwcrm_opt('unsub_footer') && empty($o['no_footer'])) $body_txt .= "\n\n" . fwcrm_opt('unsub_text');

    $token = fwcrm_token(20);
    $message_id = '<' . $token . '.fw@' . fwcrm_mail_domain() . '>';

    $html = fwcrm_text_to_html($body_txt, $token, $c);
    $headers = array('Content-Type: text/html; charset=UTF-8', 'X-FWCRM: ' . $token);
    $reply_to = fwcrm_opt('reply_to');
    if ($reply_to) $headers[] = 'Reply-To: ' . $reply_to;
    if (!empty($o['in_reply_to'])) {
        $headers[] = 'In-Reply-To: ' . $o['in_reply_to'];
        $headers[] = 'References: ' . trim((!empty($o['references']) ? $o['references'] . ' ' : '') . $o['in_reply_to']);
    }
    $headers[] = 'List-Unsubscribe: <' . rest_url('fwcrm/v1/u/' . $c->token) . '>, <mailto:' . fwcrm_opt('from_email') . '?subject=unsubscribe>';

    $GLOBALS['fwcrm_sending'] = array('message_id' => $message_id, 'alt' => $body_txt);
    $GLOBALS['fwcrm_last_error'] = '';
    $ok = wp_mail($c->email, $subject, $html, $headers);
    $raw = '';
    if ($ok && isset($GLOBALS['phpmailer']) && method_exists($GLOBALS['phpmailer'], 'getSentMIMEMessage')) {
        $raw = $GLOBALS['phpmailer']->getSentMIMEMessage();
    }
    unset($GLOBALS['fwcrm_sending']);

    $now = fwcrm_now();
    $thread_root = '';
    if (!empty($o['references'])) {
        $parts = preg_split('/\s+/', trim($o['references']));
        $thread_root = $parts[0];
    } elseif (!empty($o['in_reply_to'])) {
        $thread_root = $o['in_reply_to'];
    } else {
        $thread_root = $message_id;
    }

    $wpdb->insert(fwcrm_t('emails'), array(
        'contact_id' => $c->id,
        'direction' => 'out',
        'kind' => isset($o['kind']) ? $o['kind'] : 'email',
        'subject' => $subject,
        'body' => $body_txt,
        'snippet' => wp_html_excerpt($body_txt, 240, '…'),
        'from_email' => fwcrm_opt('from_email'),
        'to_email' => $c->email,
        'message_id' => $message_id,
        'in_reply_to' => isset($o['in_reply_to']) ? $o['in_reply_to'] : '',
        'thread_root' => $thread_root,
        'token' => $token,
        'sequence_id' => isset($o['sequence_id']) ? (int) $o['sequence_id'] : 0,
        'step' => isset($o['step']) ? (int) $o['step'] : 0,
        'source' => 'crm',
        'status' => $ok ? 'sent' : 'failed',
        'error' => $ok ? '' : (string) $GLOBALS['fwcrm_last_error'],
        'sent_at' => $now,
    ));
    $email_id = (int) $wpdb->insert_id;

    if (!$ok) {
        fwcrm_log('Send failed to ' . $c->email . ': ' . $GLOBALS['fwcrm_last_error']);
        fwcrm_event($c->id, 'send_failed', array('error' => $GLOBALS['fwcrm_last_error']), $email_id);
        return new WP_Error('fwcrm', 'Send failed: ' . $GLOBALS['fwcrm_last_error']);
    }

    fwcrm_update_contact($c->id, array('last_contacted' => $now));
    fwcrm_bump_stage($c->id, 'contacted');
    fwcrm_event($c->id, 'sent', array('subject' => $subject, 'seq' => isset($o['sequence_id']) ? (int) $o['sequence_id'] : 0, 'step' => isset($o['step']) ? (int) $o['step'] : 0), $email_id);
    update_option('fwcrm_sent_today', array('d' => current_time('Y-m-d'), 'n' => fwcrm_sent_today() + 1), false);

    if ($raw && fwcrm_opt('save_to_sent')) {
        fwcrm_copy_to_sent($raw);
    }
    return $email_id;
}

function fwcrm_sent_today() {
    $s = get_option('fwcrm_sent_today', array());
    return (is_array($s) && isset($s['d']) && $s['d'] === current_time('Y-m-d')) ? (int) $s['n'] : 0;
}

/** Save a copy of a CRM-sent email into the mailbox's Sent folder so it shows in webmail too. */
function fwcrm_copy_to_sent($raw) {
    $imap = new FWCRM_IMAP();
    if (!$imap->connect(fwcrm_opt('imap_host'), fwcrm_opt('imap_port'), fwcrm_opt('mail_user'), fwcrm_mail_pass())) {
        fwcrm_log('Could not save to Sent: ' . $imap->error);
        return false;
    }
    $folder = fwcrm_opt('sent_folder');
    if (!$folder) {
        $folder = $imap->find_sent_folder();
        if ($folder) fwcrm_save_settings(array('sent_folder' => $folder));
    }
    $ok = $folder ? $imap->append($folder, $raw) : false;
    $imap->logout();
    return $ok;
}

/** Plain text → simple personal-looking HTML, with click + open tracking. */
function fwcrm_text_to_html($text, $token, $contact) {
    $esc = esc_html($text);
    $esc = preg_replace_callback('#\bhttps?://[^\s<>"\']+#i', function ($m) use ($token) {
        $url = html_entity_decode(rtrim($m[0], '.,);:'), ENT_QUOTES);
        $tail = substr($m[0], strlen(rtrim($m[0], '.,);:')));
        $href = fwcrm_opt('track_clicks') ? fwcrm_click_url($token, $url) : $url;
        return '<a href="' . esc_url($href) . '" style="color:#7A5C1C">' . esc_html($url) . '</a>' . $tail;
    }, $esc);
    $esc = nl2br($esc);
    $pixel = fwcrm_opt('track_opens') ? '<img src="' . esc_url(rest_url('fwcrm/v1/o/' . $token)) . '" width="1" height="1" alt="" style="display:block;width:1px;height:1px;border:0;opacity:0">' : '';
    return '<!DOCTYPE html><html><body style="margin:0;padding:0"><div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.55;color:#1a1a1a;max-width:620px">' . $esc . '</div>' . $pixel . '</body></html>';
}

function fwcrm_click_url($token, $url) {
    return add_query_arg(array('u' => rawurlencode(base64_encode($url))), rest_url('fwcrm/v1/c/' . $token));
}

/** Internal notification to Felix (no tracking, normal wp_mail). */
function fwcrm_notify($subject, $lines, $link = '') {
    $to = fwcrm_opt('notify_email');
    if (!$to) return;
    $body = implode("\n", (array) $lines) . ($link ? "\n\nOpen in CRM: " . $link : '');
    if (fwcrm_mailbox_ready()) {
        $GLOBALS['fwcrm_sending'] = array('message_id' => '', 'alt' => '');
        wp_mail($to, '[CRM] ' . $subject, $body);
        unset($GLOBALS['fwcrm_sending']);
    } else {
        wp_mail($to, '[CRM] ' . $subject, $body);
    }
}

function fwcrm_send_daily_digest() {
    global $wpdb;
    $since = date('Y-m-d H:i:s', current_time('timestamp') - DAY_IN_SECONDS);
    $sent = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction='out' AND status='sent' AND sent_at >= %s", $since));
    $replies = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction='in' AND kind='reply' AND sent_at >= %s", $since));
    $visits = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor_id) FROM " . fwcrm_t('visits') . " WHERE created >= %s", $since));
    $due = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('contacts') . " WHERE next_followup IS NOT NULL AND next_followup <= %s AND unsubscribed=0", date('Y-m-d 23:59:59', current_time('timestamp'))));
    $manual = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . fwcrm_t('emails') . " WHERE direction='in' AND kind='reply' AND handled=0");
    if (!$sent && !$replies && !$visits && !$manual) return;
    fwcrm_notify('Your daily summary', array(
        "Last 24 hours:",
        "• Emails sent: $sent",
        "• New replies: $replies",
        "• Website visitors: $visits",
        "• Replies waiting for you: $manual",
        "• Follow-ups scheduled today: $due",
    ), fwcrm_admin_url('fwcrm'));
}
