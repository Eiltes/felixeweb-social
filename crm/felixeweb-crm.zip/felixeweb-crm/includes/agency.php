<?php
/**
 * Agency layer: team members (own logins), projects, task assignment,
 * "My work" for members, public team endpoint, Web / Video lanes.
 */
if (!defined('ABSPATH')) exit;

define('FWCRM_TEAM_ROLE', 'fw_team');

function fwcrm_is_admin_user() { return current_user_can('manage_options'); }
function fwcrm_is_member() { return is_user_logged_in() && !current_user_can('manage_options') && current_user_can('fwcrm_team'); }

/* =========================================================
 * Setup: role, tables, lanes
 * ======================================================= */

function fwcrm_agency_install() {
    if (!get_role(FWCRM_TEAM_ROLE)) add_role(FWCRM_TEAM_ROLE, 'FelixeWeb Team', array('read' => true, 'upload_files' => true, 'fwcrm_team' => true));
    $admin = get_role('administrator');
    if ($admin && !$admin->has_cap('fwcrm_team')) $admin->add_cap('fwcrm_team');
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $cs = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE " . fwcrm_t('projects') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
        title varchar(200) NOT NULL DEFAULT '',
        service varchar(30) NOT NULL DEFAULT 'web',
        status varchar(20) NOT NULL DEFAULT 'brief',
        owner_id bigint(20) unsigned NOT NULL DEFAULT 0,
        due date NULL,
        value decimal(12,2) NOT NULL DEFAULT 0,
        brief text NULL,
        log longtext NULL,
        created datetime NOT NULL,
        updated datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY status (status),
        KEY owner_id (owner_id)
    ) $cs;");
    $T = fwcrm_t('tasks');
    $cols = $wpdb->get_col("SHOW COLUMNS FROM $T", 0);
    if ($cols && !in_array('assigned_to', $cols, true)) $wpdb->query("ALTER TABLE $T ADD assigned_to bigint(20) unsigned NOT NULL DEFAULT 0, ADD project_id bigint(20) unsigned NOT NULL DEFAULT 0, ADD status varchar(20) NOT NULL DEFAULT 'todo', ADD created_by bigint(20) unsigned NOT NULL DEFAULT 0");
    $C = fwcrm_t('contacts');
    $ccols = $wpdb->get_col("SHOW COLUMNS FROM $C", 0);
    if ($ccols && !in_array('lane', $ccols, true)) $wpdb->query("ALTER TABLE $C ADD lane varchar(20) NOT NULL DEFAULT 'web'");
    fwcrm_lanes_backfill();
    update_option('fwcrm_agency_version', '1', false);
}

add_action('admin_init', function () {
    if (get_option('fwcrm_agency_version') !== '1') fwcrm_agency_install();
});

function fwcrm_lanes() { return array('web' => 'Web & stores', 'video' => 'Video', 'book' => 'Books'); }

function fwcrm_lane_for($notes, $tags = '', $problems = '') {
    $s = strtolower($notes . ' ' . $tags . ' ' . $problems);
    if (preg_match('/book formatting|\bkdp\b|\bebooks?\b|e-book|\bauthors?\b|paperback/', $s)) return 'book';
    return (strpos($s, 'healthcare') !== false || strpos($s, 'explainer') !== false || strpos($s, '2d video') !== false || strpos($s, '3d ') !== false) ? 'video' : 'web';
}

function fwcrm_lanes_backfill() {
    global $wpdb;
    $C = fwcrm_t('contacts');
    $wpdb->query("UPDATE $C SET lane = 'video' WHERE lane <> 'video' AND (notes LIKE 'Healthcare%' OR notes LIKE '% Healthcare %' OR tags LIKE '%healthcare%' OR problems LIKE '%explainer%')");
}

/** Imported leads: put healthcare / video ones in the Video lane and tag them. */
add_action('fwcrm_lead_imported', function ($cid, $l) {
    $c = fwcrm_get_contact($cid);
    if (!$c) return;
    $tagged = !empty($l['tag']) ? $l['tag'] : '';
    if (!empty($l['tags']) && is_array($l['tags'])) $tagged .= ' ' . implode(' ', $l['tags']);
    $lane = fwcrm_lane_for((string) $c->notes, $tagged . ' ' . $c->tags, (string) $c->problems);
    $upd = array();
    if ($lane !== $c->lane) $upd['lane'] = $lane;
    if ($lane === 'video' && stripos((string) $c->tags, 'healthcare') === false && stripos($c->notes . $tagged, 'healthcare') !== false) $upd['tags'] = trim(trim((string) $c->tags) . ($c->tags ? ', ' : '') . 'healthcare');
    if ($lane === 'video' && (!$c->niche || $c->niche === 'Research peptides')) $upd['niche'] = 'Healthcare';
    if ($upd) fwcrm_update_contact($cid, $upd);
}, 10, 2);

function fwcrm_lane_chip($c) {
    if (isset($c->lane) && $c->lane === 'book') return '<span class="fw-lane-chip b">Book</span>';
    return (isset($c->lane) && $c->lane === 'video') ? '<span class="fw-lane-chip v">Video</span>' : '';
}

function fwcrm_lane_filter_html($page, $extra = array()) {
    $cur = isset($_GET['lane']) ? sanitize_key($_GET['lane']) : '';
    $o = '<div class="fw-lanes-f">';
    foreach (array('' => 'All', 'web' => 'Web & stores', 'video' => 'Video', 'book' => 'Books') as $k => $l) {
        $o .= '<a class="' . ($cur === $k ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url($page, array_filter(array_merge($extra, array('lane' => $k))))) . '">' . esc_html($l) . '</a>';
    }
    return $o . '</div>';
}

/* =========================================================
 * Team members
 * ======================================================= */

function fwcrm_team_users($public_only = false) {
    $users = get_users(array('role__in' => array('administrator', FWCRM_TEAM_ROLE), 'orderby' => 'display_name'));
    $out = array();
    foreach ($users as $u) {
        if (in_array('administrator', (array) $u->roles, true) && !get_user_meta($u->ID, 'fw_title', true) && $u->ID !== get_current_user_id() && !$public_only) {
            // other admins without a team profile are not shown as team
            continue;
        }
        if ($public_only && !get_user_meta($u->ID, 'fw_public', true)) continue;
        $out[] = $u;
    }
    $ord = function ($u) { $o = get_user_meta($u->ID, 'fw_order', true); return $o === '' ? (user_can($u, 'manage_options') ? 0 : 10) : (int) $o; };
    usort($out, function ($a, $b) use ($ord) { return $ord($a) - $ord($b); });
    return $out;
}

function fwcrm_member_photo($uid, $size = 'medium') {
    $att = (int) get_user_meta($uid, 'fw_photo', true);
    return $att ? wp_get_attachment_image_url($att, $size) : '';
}

function fwcrm_member_avatar($uid, $cls = '') {
    $u = get_userdata($uid);
    if (!$u) return '';
    $ph = fwcrm_member_photo($uid, 'thumbnail');
    $init = strtoupper(mb_substr($u->display_name ?: $u->user_login, 0, 1));
    return '<span class="fw-mav ' . esc_attr($cls) . '" title="' . esc_attr($u->display_name) . '">' . ($ph ? '<img src="' . esc_url($ph) . '" alt="">' : esc_html($init)) . '</span>';
}

function fwcrm_member_options($selected = 0, $none = 'Unassigned') {
    $o = '<option value="0">' . esc_html($none) . '</option>';
    foreach (fwcrm_team_users() as $u) $o .= '<option value="' . (int) $u->ID . '"' . selected($selected, $u->ID, false) . '>' . esc_html($u->display_name . ($u->ID === get_current_user_id() ? ' (you)' : '') . (get_user_meta($u->ID, 'fw_title', true) ? ' · ' . get_user_meta($u->ID, 'fw_title', true) : '')) . '</option>';
    return $o;
}

function fwcrm_page_team() {
    global $wpdb;
    $now = fwcrm_now();
    fwcrm_header('Team', 'Everyone in FelixeWeb. Members log in and see only their own tasks and projects.', '<button class="fw-btn gold" data-fw-open="member">+ Add member</button>');
    $users = fwcrm_team_users();
    $me = wp_get_current_user();
    if (!in_array($me->ID, wp_list_pluck($users, 'ID'), true)) array_unshift($users, $me);
    echo '<div class="fw-team">';
    foreach ($users as $u) {
        $open = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " WHERE done = 0 AND assigned_to = %d", $u->ID));
        $late = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " WHERE done = 0 AND assigned_to = %d AND due IS NOT NULL AND due < %s", $u->ID, $now));
        $proj = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('projects') . " WHERE owner_id = %d AND status <> 'delivered'", $u->ID));
        $ph = fwcrm_member_photo($u->ID);
        $title = get_user_meta($u->ID, 'fw_title', true);
        $isadmin = in_array('administrator', (array) $u->roles, true);
        echo '<div class="fw-tm-card"><div class="fw-tm-photo">' . ($ph ? '<img src="' . esc_url($ph) . '" alt="">' : '<span>' . esc_html(strtoupper(mb_substr($u->display_name, 0, 1))) . '</span>') . '</div>';
        echo '<div class="fw-tm-body"><b>' . esc_html($u->display_name) . '</b><small>' . esc_html($title ?: ($isadmin ? 'Founder' : 'Team member')) . '</small>';
        echo '<div class="fw-tm-stats"><span><b>' . $open . '</b> open tasks</span>' . ($late ? '<span class="late"><b>' . $late . '</b> overdue</span>' : '') . '<span><b>' . $proj . '</b> projects</span></div>';
        echo '<div class="fw-tm-foot">' . (get_user_meta($u->ID, 'fw_public', true) ? '<em class="pub">On website</em>' : '<em>Hidden from website</em>') . '<button class="fw-btn sm" data-fw-open="member-' . (int) $u->ID . '">Edit</button><button class="fw-btn sm gold" data-fw-open="assign-' . (int) $u->ID . '">+ Task</button></div></div></div>';
        echo fwcrm_member_dialog($u);
        echo fwcrm_assign_dialog($u->ID);
    }
    echo '</div>';
    echo fwcrm_member_dialog(null);

    // Team workload: open tasks grouped by person
    $rows = $wpdb->get_results("SELECT t.*, c.company, c.first_name, c.last_name, c.email, p.title ptitle FROM " . fwcrm_t('tasks') . " t LEFT JOIN " . fwcrm_t('contacts') . " c ON c.id = t.contact_id LEFT JOIN " . fwcrm_t('projects') . " p ON p.id = t.project_id WHERE t.done = 0 AND t.assigned_to > 0 ORDER BY (t.due IS NULL), t.due ASC LIMIT 200");
    echo '<div class="fw-card" style="margin-top:18px"><div class="fw-card-h"><h2>What everyone is working on</h2><span class="fw-dim">' . count($rows) . ' open assigned tasks</span></div>';
    if (!$rows) echo '<div class="fw-empty">No tasks assigned yet. Use “+ Task” on a member, or assign from any project or lead.</div>';
    foreach ($rows as $t) echo fwcrm_task_row($t);
    echo '</div>';
    fwcrm_footer();
}

function fwcrm_member_dialog($u) {
    $id = $u ? (int) $u->ID : 0;
    $g = function ($k) use ($id) { return $id ? (string) get_user_meta($id, $k, true) : ''; };
    $ph = $id ? fwcrm_member_photo($id, 'thumbnail') : '';
    $o = '<dialog class="fw-dialog" id="fw-member' . ($id ? '-' . $id : '') . '-dlg"><form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="fwcrm_save_member">' . wp_nonce_field('fwcrm_fwcrm_save_member', '_fwnonce', true, false) . '<input type="hidden" name="uid" value="' . $id . '">';
    $o .= '<h3>' . ($id ? 'Edit ' . esc_html($u->display_name) : 'Add a team member') . '</h3>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Full name</span><input name="name" required value="' . esc_attr($id ? $u->display_name : '') . '"></label><label class="fw-f"><span>Email (their login, optional)</span><input type="email" name="email" placeholder="Add later for a login" value="' . esc_attr($id ? $u->user_email : '') . '"></label></div>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Role / title</span><input name="title" placeholder="e.g. 2D Animator, 3D AI Artist" value="' . esc_attr($g('fw_title')) . '"></label><label class="fw-f"><span>Order on website</span><input type="number" name="order" value="' . esc_attr($g('fw_order') ?: '10') . '"></label></div>';
    $o .= '<label class="fw-f"><span>Short bio (shown on the website)</span><textarea name="bio" rows="3" maxlength="400" placeholder="One or two sentences about what they do best.">' . esc_textarea($g('fw_bio')) . '</textarea></label>';
    $o .= '<label class="fw-f"><span>Skills (comma separated, private)</span><input name="skills" value="' . esc_attr($g('fw_skills')) . '" placeholder="2D animation, After Effects, AI voiceover"></label>';
    $o .= '<label class="fw-f"><span>Photo ' . ($ph ? '(current shown)' : '') . '</span>' . ($ph ? '<img class="fw-dlg-ph" src="' . esc_url($ph) . '" alt="">' : '') . '<input type="file" name="photo" accept="image/*"></label>';
    $o .= '<label class="fw-check"><input type="checkbox" name="public" value="1"' . checked($id ? (bool) $g('fw_public') : true, true, false) . '> Show on the website Team section</label>';
    if (!$id) $o .= '<p class="fw-dim">With an email, they get a link from WordPress to set their own password and see only their own tasks and projects. Without one, they appear on the website only; add their email later to give them a login.</p>';
    $o .= '<div class="fw-btnrow">' . ($id && $id !== get_current_user_id() && !user_can($id, 'manage_options') ? '<button class="fw-btn ghost danger" name="remove" value="1" onclick="return confirm(\'Remove this member? Their login stops working; tasks stay.\')">Remove</button>' : '') . '<button type="button" class="fw-btn ghost" data-fw-close>Cancel</button><button class="fw-btn gold">' . ($id ? 'Save' : 'Add member') . '</button></div></form></dialog>';
    return $o;
}

add_action('admin_post_fwcrm_save_member', function () {
    fwcrm_guard('fwcrm_save_member');
    $p = wp_unslash($_POST);
    $uid = (int) $p['uid'];
    $email = sanitize_email($p['email']);
    $name = sanitize_text_field($p['name']);
    if ($uid && !empty($p['remove'])) {
        if (user_can($uid, 'manage_options')) fwcrm_back('fwcrm-team', array(), 'Admins cannot be removed here.', true);
        $u = new WP_User($uid);
        $u->set_role('');
        update_user_meta($uid, 'fw_public', 0);
        fwcrm_back('fwcrm-team', array(), $name . ' was removed. Their login no longer opens the Hub.');
    }
    $had_email = $uid ? (bool) get_userdata($uid)->user_email : false;
    if (!$uid) {
        if ($email !== '' && !is_email($email)) fwcrm_back('fwcrm-team', array(), 'Enter a valid email, or leave it empty.', true);
        if ($email !== '' && email_exists($email)) {
            $uid = email_exists($email);
            if (!user_can($uid, 'manage_options')) (new WP_User($uid))->set_role(FWCRM_TEAM_ROLE);
        } else {
            $login = sanitize_user(strtolower(preg_replace('/\s+/', '.', $name)), true) ?: sanitize_user(strstr($email, '@', true), true);
            while (username_exists($login)) $login .= wp_rand(1, 9);
            $uid = wp_insert_user(array('user_login' => $login, 'user_email' => $email, 'display_name' => $name, 'first_name' => strtok($name, ' '), 'user_pass' => wp_generate_password(24), 'role' => FWCRM_TEAM_ROLE));
            if (is_wp_error($uid)) fwcrm_back('fwcrm-team', array(), $uid->get_error_message(), true);
            if ($email !== '') wp_new_user_notification($uid, null, 'user');
        }
    } else {
        if ($email !== '' && !is_email($email)) fwcrm_back('fwcrm-team', array(), 'Enter a valid email.', true);
        if ($email !== '' && email_exists($email) && (int) email_exists($email) !== $uid) fwcrm_back('fwcrm-team', array(), 'That email belongs to another account.', true);
        wp_update_user(array('ID' => $uid, 'display_name' => $name, 'user_email' => $email ?: get_userdata($uid)->user_email));
        if (!$had_email && $email !== '') wp_new_user_notification($uid, null, 'user');
    }
    update_user_meta($uid, 'fw_title', sanitize_text_field($p['title']));
    update_user_meta($uid, 'fw_bio', sanitize_textarea_field($p['bio']));
    update_user_meta($uid, 'fw_skills', sanitize_text_field($p['skills']));
    update_user_meta($uid, 'fw_order', (int) $p['order']);
    update_user_meta($uid, 'fw_public', empty($p['public']) ? 0 : 1);
    if (!empty($_FILES['photo']['name'])) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $att = media_handle_upload('photo', 0, array('post_title' => $name . ' — team photo'));
        if (!is_wp_error($att)) update_user_meta($uid, 'fw_photo', $att);
    }
    delete_transient('fwcrm_team_public');
    fwcrm_back('fwcrm-team', array(), (int) $p['uid'] ? 'Saved.' : ($email !== '' ? $name . ' added. They’ll get an email to set their password.' : $name . ' added to the website. Add their email later to give them a login.'));
});

/* =========================================================
 * Task assignment
 * ======================================================= */

function fwcrm_assign_dialog($uid = 0, $cid = 0, $pid = 0) {
    $key = $uid ? 'assign-' . $uid : ($pid ? 'ptask-' . $pid : 'assign');
    $o = '<dialog class="fw-dialog" id="fw-' . esc_attr($key) . '-dlg">' . fwcrm_post_form_open('fwcrm_assign_task') . '<input type="hidden" name="contact_id" value="' . (int) $cid . '"><input type="hidden" name="project_id" value="' . (int) $pid . '"><input type="hidden" name="back" value="' . esc_attr(isset($_GET['page']) ? sanitize_key($_GET['page']) : 'fwcrm-team') . '"><input type="hidden" name="back_id" value="' . (int) (isset($_GET['view']) ? $_GET['view'] : (isset($_GET['p']) ? $_GET['p'] : 0)) . '"><h3>Assign a task</h3>';
    $o .= '<label class="fw-f"><span>Task</span><input name="title" required placeholder="e.g. Storyboard the 60s explainer"></label>';
    $o .= '<label class="fw-f"><span>Details (optional)</span><textarea name="notes" rows="3" placeholder="Links, script, references…"></textarea></label>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Assign to</span><select name="assigned_to">' . fwcrm_member_options($uid) . '</select></label><label class="fw-f"><span>Due</span><input type="datetime-local" name="due" value="' . esc_attr(date('Y-m-d\TH:i', current_time('timestamp') + DAY_IN_SECONDS)) . '"></label></div>';
    $o .= '<label class="fw-check"><input type="checkbox" name="notify" value="1" checked> Email them about this task</label>';
    $o .= '<div class="fw-btnrow"><button type="button" class="fw-btn ghost" data-fw-close>Cancel</button><button class="fw-btn gold">Assign</button></div></form></dialog>';
    return $o;
}

add_action('admin_post_fwcrm_assign_task', function () {
    fwcrm_guard('fwcrm_assign_task');
    $p = wp_unslash($_POST);
    $due = !empty($p['due']) ? date('Y-m-d H:i:s', strtotime(sanitize_text_field($p['due']))) : null;
    $id = fwcrm_task_add((int) $p['contact_id'], 'todo', sanitize_text_field($p['title']), $due);
    global $wpdb;
    $assignee = (int) $p['assigned_to'];
    $wpdb->update(fwcrm_t('tasks'), array('assigned_to' => $assignee, 'project_id' => (int) $p['project_id'], 'created_by' => get_current_user_id(), 'status' => 'todo'), array('id' => $id));
    if (!empty($p['notes'])) $wpdb->update(fwcrm_t('tasks'), array('title' => sanitize_text_field($p['title'])), array('id' => $id));
    if (!empty($p['notes'])) update_option('fwcrm_task_notes_' . $id, sanitize_textarea_field($p['notes']), false);
    if ((int) $p['project_id']) fwcrm_project_log((int) $p['project_id'], 'Task assigned: ' . sanitize_text_field($p['title']) . ($assignee ? ' → ' . get_userdata($assignee)->display_name : ''));
    if ($assignee && $assignee !== get_current_user_id() && !empty($p['notify'])) fwcrm_notify_assignee($id);
    $back = sanitize_key($p['back']);
    $args = array();
    if ($back === 'fwcrm-contacts' && (int) $p['back_id']) $args['view'] = (int) $p['back_id'];
    if ($back === 'fwcrm-projects' && (int) $p['back_id']) $args['p'] = (int) $p['back_id'];
    fwcrm_back($back ?: 'fwcrm-team', $args, 'Task assigned.');
});

function fwcrm_notify_assignee($task_id) {
    global $wpdb;
    $t = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('tasks') . " WHERE id = %d", $task_id));
    if (!$t || !$t->assigned_to) return;
    $u = get_userdata($t->assigned_to);
    if (!$u) return;
    $notes = get_option('fwcrm_task_notes_' . $task_id, '');
    $proj = $t->project_id ? $wpdb->get_var($wpdb->prepare("SELECT title FROM " . fwcrm_t('projects') . " WHERE id = %d", $t->project_id)) : '';
    $body = "Hi " . ($u->first_name ?: $u->display_name) . ",\n\nYou have a new task in the FelixeWeb Hub:\n\n" . $t->title . "\n" . ($proj ? "Project: " . $proj . "\n" : '') . ($t->due ? "Due: " . date_i18n('l j M, H:i', strtotime($t->due)) . "\n" : '') . ($notes ? "\n" . $notes . "\n" : '') . "\nOpen your work: " . admin_url('admin.php?page=fwcrm-my') . "\n\nFelix\nFelixeWeb";
    wp_mail($u->user_email, 'New task: ' . $t->title, $body);
}

/* =========================================================
 * Projects
 * ======================================================= */

function fwcrm_project_services() { return array('web' => 'Website / store', '2d' => '2D explainer', '3d' => '3D animation', 'edit' => 'AI video editing', 'book' => 'Book formatting', 'automation' => 'AI automation', 'app' => 'App', 'other' => 'Other'); }
function fwcrm_project_statuses() { return array('brief' => 'Brief', 'production' => 'In production', 'review' => 'Client review', 'revisions' => 'Revisions', 'delivered' => 'Delivered'); }

function fwcrm_project_log($pid, $line) {
    global $wpdb;
    $log = (string) $wpdb->get_var($wpdb->prepare("SELECT log FROM " . fwcrm_t('projects') . " WHERE id = %d", $pid));
    $who = wp_get_current_user();
    $log = date_i18n('j M H:i') . ' · ' . ($who->ID ? $who->display_name : 'Hub') . ' · ' . $line . "\n" . $log;
    $wpdb->update(fwcrm_t('projects'), array('log' => wp_html_excerpt($log, 20000, ''), 'updated' => fwcrm_now()), array('id' => $pid));
}

function fwcrm_get_project($id) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT p.*, c.company, c.first_name, c.last_name, c.email FROM " . fwcrm_t('projects') . " p LEFT JOIN " . fwcrm_t('contacts') . " c ON c.id = p.contact_id WHERE p.id = %d", $id));
}

function fwcrm_page_projects() {
    if (!empty($_GET['p'])) { fwcrm_page_project((int) $_GET['p']); return; }
    global $wpdb;
    $svc = fwcrm_project_services();
    $filter = isset($_GET['svc']) ? sanitize_key($_GET['svc']) : '';
    fwcrm_header('Projects', 'Paid work in progress, from brief to delivery. Assign a lead person and tasks to each.', '<button class="fw-btn gold" data-fw-open="project">+ New project</button>');
    echo '<div class="fw-lanes-f"><a class="' . (!$filter ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-projects')) . '">All</a>';
    foreach ($svc as $k => $l) echo '<a class="' . ($filter === $k ? 'on' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-projects', array('svc' => $k))) . '">' . esc_html($l) . '</a>';
    echo '</div>';
    $w = $filter ? $wpdb->prepare(' WHERE p.service = %s', $filter) : '';
    $rows = $wpdb->get_results("SELECT p.*, c.company, c.first_name, c.last_name, c.email, (SELECT COUNT(*) FROM " . fwcrm_t('tasks') . " t WHERE t.project_id = p.id AND t.done = 0) open_tasks FROM " . fwcrm_t('projects') . " p LEFT JOIN " . fwcrm_t('contacts') . " c ON c.id = p.contact_id $w ORDER BY (p.due IS NULL), p.due ASC, p.id DESC");
    $by = array();
    foreach ($rows as $r) $by[$r->status][] = $r;
    echo '<div class="fw-board fw-pboard">';
    foreach (fwcrm_project_statuses() as $k => $l) {
        $list = isset($by[$k]) ? $by[$k] : array();
        $sum = array_sum(array_map(function ($x) { return (float) $x->value; }, $list));
        echo '<div class="fw-lane' . (!$list ? ' empty' : '') . '"><div class="fw-lane-h"><span class="fw-stage ps-' . esc_attr($k) . '">' . esc_html($l) . '</span>' . ($sum ? '<em class="fw-lane-sum">' . esc_html(fwcrm_money($sum)) . '</em>' : '') . '<b>' . count($list) . '</b></div><div class="fw-drop">';
        foreach ($list as $p) {
            $late = $p->due && $k !== 'delivered' && strtotime($p->due . ' 23:59') < current_time('timestamp');
            echo '<a class="fw-pcard' . ($late ? ' late' : '') . '" href="' . esc_url(fwcrm_admin_url('fwcrm-projects', array('p' => $p->id))) . '"><span class="fw-svc s-' . esc_attr($p->service) . '">' . esc_html(isset($svc[$p->service]) ? $svc[$p->service] : $p->service) . '</span><b>' . esc_html($p->title) . '</b><small>' . esc_html($p->company ?: ($p->email ?: 'No client linked')) . '</small><div class="fw-pmeta">' . ($p->owner_id ? fwcrm_member_avatar($p->owner_id) : '<span class="fw-mav none">?</span>') . ($p->due ? '<span class="' . ($late ? 'late' : '') . '">Due ' . esc_html(date_i18n('j M', strtotime($p->due))) . '</span>' : '') . ($p->open_tasks ? '<span>' . (int) $p->open_tasks . ' tasks</span>' : '') . ((float) $p->value ? '<span class="fw-val">' . esc_html(fwcrm_money($p->value)) . '</span>' : '') . '</div></a>';
        }
        echo '</div></div>';
    }
    echo '</div>';
    if (!$rows) echo '<div class="fw-card"><div class="fw-empty">No projects yet. When a lead says yes, open them and press “Start project”, or use “+ New project”.</div></div>';
    echo fwcrm_project_dialog();
    fwcrm_footer();
}

function fwcrm_project_dialog($p = null, $cid = 0) {
    $id = $p ? (int) $p->id : 0;
    $c = $cid ? fwcrm_get_contact($cid) : null;
    $o = '<dialog class="fw-dialog" id="fw-project' . ($id ? '-edit' : '') . '-dlg">' . fwcrm_post_form_open('fwcrm_save_project') . '<input type="hidden" name="id" value="' . $id . '"><h3>' . ($id ? 'Edit project' : 'New project') . '</h3>';
    $default_title = $c ? fwcrm_lead_title($c) . ' — ' . ($c->lane === 'video' ? '2D explainer video' : ($c->lane === 'book' ? 'Book formatting' : 'Store work')) : '';
    $o .= '<label class="fw-f"><span>Project name</span><input name="title" required value="' . esc_attr($id ? $p->title : $default_title) . '" placeholder="e.g. NobelPepLab — checkout & COA pages"></label>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Service</span><select name="service">';
    $defsvc = $id ? $p->service : ($c && $c->lane === 'video' ? '2d' : ($c && $c->lane === 'book' ? 'book' : 'web'));
    foreach (fwcrm_project_services() as $k => $l) $o .= '<option value="' . esc_attr($k) . '"' . selected($defsvc, $k, false) . '>' . esc_html($l) . '</option>';
    $o .= '</select></label><label class="fw-f"><span>Lead person</span><select name="owner_id">' . fwcrm_member_options($id ? $p->owner_id : 0, 'Choose…') . '</select></label></div>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Client email (links the lead)</span><input type="email" name="client_email" value="' . esc_attr($id ? $p->email : ($c ? $c->email : '')) . '" placeholder="client@example.com"></label><label class="fw-f"><span>Due date</span><input type="date" name="due" value="' . esc_attr($id && $p->due ? $p->due : date('Y-m-d', current_time('timestamp') + 7 * DAY_IN_SECONDS)) . '"></label></div>';
    $o .= '<div class="fw-row2"><label class="fw-f"><span>Value ($)</span><input inputmode="decimal" name="value" value="' . esc_attr($id && (float) $p->value ? (float) $p->value : ($c && (float) $c->deal_value ? (float) $c->deal_value : '')) . '"></label><label class="fw-f"><span>Status</span><select name="status">';
    foreach (fwcrm_project_statuses() as $k => $l) $o .= '<option value="' . esc_attr($k) . '"' . selected($id ? $p->status : 'brief', $k, false) . '>' . esc_html($l) . '</option>';
    $o .= '</select></label></div><label class="fw-f"><span>Brief</span><textarea name="brief" rows="4" placeholder="What the client wants, links, scripts, deadlines…">' . esc_textarea($id ? $p->brief : '') . '</textarea></label>';
    $o .= '<div class="fw-btnrow">' . ($id ? '<button class="fw-btn ghost danger" name="delete" value="1" onclick="return confirm(\'Delete this project? Its tasks stay.\')">Delete</button>' : '') . '<button type="button" class="fw-btn ghost" data-fw-close>Cancel</button><button class="fw-btn gold">' . ($id ? 'Save' : 'Create project') . '</button></div></form></dialog>';
    return $o;
}

add_action('admin_post_fwcrm_save_project', function () {
    fwcrm_guard('fwcrm_save_project');
    global $wpdb;
    $p = wp_unslash($_POST);
    $id = (int) $p['id'];
    if ($id && !empty($p['delete'])) { $wpdb->delete(fwcrm_t('projects'), array('id' => $id)); fwcrm_back('fwcrm-projects', array(), 'Project deleted.'); }
    $cid = 0;
    if (!empty($p['client_email'])) { $c = fwcrm_get_contact_by_email(sanitize_email($p['client_email'])); $cid = $c ? (int) $c->id : 0; }
    $data = array(
        'title' => sanitize_text_field($p['title']),
        'service' => array_key_exists($p['service'], fwcrm_project_services()) ? $p['service'] : 'other',
        'status' => array_key_exists($p['status'], fwcrm_project_statuses()) ? $p['status'] : 'brief',
        'owner_id' => (int) $p['owner_id'],
        'contact_id' => $cid,
        'due' => !empty($p['due']) ? sanitize_text_field($p['due']) : null,
        'value' => max(0, (float) preg_replace('/[^0-9.]/', '', $p['value'])),
        'brief' => sanitize_textarea_field($p['brief']),
        'updated' => fwcrm_now(),
    );
    if ($id) {
        $old = fwcrm_get_project($id);
        $wpdb->update(fwcrm_t('projects'), $data, array('id' => $id));
        if ($old && $old->status !== $data['status']) fwcrm_project_log($id, 'Status → ' . fwcrm_project_statuses()[$data['status']]);
        if ($old && (int) $old->owner_id !== $data['owner_id'] && $data['owner_id']) fwcrm_project_log($id, 'Lead person → ' . get_userdata($data['owner_id'])->display_name);
    } else {
        $data['created'] = fwcrm_now();
        $wpdb->insert(fwcrm_t('projects'), $data);
        $id = (int) $wpdb->insert_id;
        fwcrm_project_log($id, 'Project created');
        if ($cid) {
            fwcrm_event($cid, 'project', array('title' => $data['title']));
            $c = fwcrm_get_contact($cid);
            if ($c && $c->stage !== 'won') fwcrm_update_contact($cid, array('stage' => 'won') + ((float) $data['value'] && !(float) $c->deal_value ? array('deal_value' => $data['value']) : array()));
        }
        if ($data['owner_id'] && $data['owner_id'] !== get_current_user_id()) {
            $u = get_userdata($data['owner_id']);
            if ($u) wp_mail($u->user_email, 'You are leading a new project: ' . $data['title'], "Hi " . ($u->first_name ?: $u->display_name) . ",\n\nYou're the lead on a new FelixeWeb project:\n\n" . $data['title'] . "\n" . ($data['due'] ? 'Due: ' . date_i18n('l j M', strtotime($data['due'])) . "\n" : '') . ($data['brief'] ? "\nBrief:\n" . $data['brief'] . "\n" : '') . "\nOpen your work: " . admin_url('admin.php?page=fwcrm-my') . "\n\nFelix\nFelixeWeb");
        }
    }
    fwcrm_back('fwcrm-projects', array('p' => $id), 'Project saved.');
});

function fwcrm_page_project($id) {
    global $wpdb;
    $p = fwcrm_get_project($id);
    if (!$p) { fwcrm_header('Project not found'); fwcrm_footer(); return; }
    $svc = fwcrm_project_services();
    $st = fwcrm_project_statuses();
    fwcrm_header($p->title, '<a href="' . esc_url(fwcrm_admin_url('fwcrm-projects')) . '">← All projects</a> · ' . esc_html(isset($svc[$p->service]) ? $svc[$p->service] : $p->service) . ($p->company ? ' · client <a href="' . esc_url(fwcrm_admin_url('fwcrm-contacts', array('view' => $p->contact_id))) . '">' . esc_html($p->company) . '</a>' : ''), '<button class="fw-btn" data-fw-open="project-edit">Edit</button><button class="fw-btn gold" data-fw-open="ptask-' . (int) $p->id . '">+ Task</button>');
    echo '<div class="fw-contact fw-proj"><div class="fw-main">';
    echo '<div class="fw-card"><div class="fw-pstat">';
    foreach ($st as $k => $l) echo '<button class="' . ($p->status === $k ? 'on' : '') . '" data-fw-work="pstatus" data-id="' . (int) $p->id . '" data-v="' . esc_attr($k) . '">' . esc_html($l) . '</button>';
    echo '</div>' . ($p->brief ? '<h3 style="margin-top:16px">Brief</h3><div class="fw-brief">' . nl2br(esc_html($p->brief)) . '</div>' : '<p class="fw-dim" style="margin-top:14px">No brief yet. Press Edit to add one.</p>') . '</div>';
    $tasks = $wpdb->get_results($wpdb->prepare("SELECT t.*, '' company, '' email FROM " . fwcrm_t('tasks') . " t WHERE t.project_id = %d ORDER BY t.done ASC, (t.due IS NULL), t.due ASC", $p->id));
    echo '<div class="fw-card fw-ctasks"><div class="fw-card-h"><h3>Tasks</h3><button class="fw-btn sm" data-fw-open="ptask-' . (int) $p->id . '">+ Task</button></div>';
    if (!$tasks) echo '<p class="fw-dim">No tasks yet. Break the work into steps and assign each one.</p>';
    foreach ($tasks as $t) echo $t->done ? '<div class="fw-trow done"><span class="fw-ticon">✓</span><div class="fw-tmain"><b>' . esc_html($t->title) . '</b><p>' . ($t->assigned_to ? esc_html(get_userdata($t->assigned_to) ? get_userdata($t->assigned_to)->display_name : '') . ' · ' : '') . 'done ' . esc_html(fwcrm_time_ago($t->done_at)) . '</p></div></div>' : fwcrm_task_row($t);
    echo '</div></div><div class="fw-side"><div class="fw-card"><h3>Details</h3><div class="fw-kv2"><div><span>Lead person</span>' . ($p->owner_id && get_userdata($p->owner_id) ? fwcrm_member_avatar($p->owner_id) . ' ' . esc_html(get_userdata($p->owner_id)->display_name) : '—') . '</div><div><span>Due</span>' . ($p->due ? esc_html(date_i18n('D j M Y', strtotime($p->due))) : '—') . '</div><div><span>Value</span>' . ((float) $p->value ? esc_html(fwcrm_money($p->value)) : '—') . '</div><div><span>Client</span>' . esc_html($p->company ?: ($p->email ?: '—')) . '</div></div></div>';
    echo '<div class="fw-card"><h3>Activity</h3>' . fwcrm_post_form_open('fwcrm_project_note', 'class="fw-noteform"') . '<input type="hidden" name="id" value="' . (int) $p->id . '"><input name="note" placeholder="Post an update…"><button class="fw-btn sm">Post</button></form><div class="fw-plog">';
    foreach (array_filter(explode("\n", (string) $p->log)) as $line) echo '<div>' . esc_html($line) . '</div>';
    echo '</div></div></div></div>';
    echo fwcrm_project_dialog($p) . fwcrm_assign_dialog(0, $p->contact_id, $p->id);
    fwcrm_footer();
}

add_action('admin_post_fwcrm_project_note', function () {
    if (!current_user_can('fwcrm_team')) wp_die('Not allowed');
    check_admin_referer('fwcrm_fwcrm_project_note', '_fwnonce');
    $id = (int) $_POST['id'];
    if (!fwcrm_is_admin_user()) {
        global $wpdb;
        $own = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . fwcrm_t('projects') . " p WHERE p.id = %d AND (p.owner_id = %d OR EXISTS (SELECT 1 FROM " . fwcrm_t('tasks') . " t WHERE t.project_id = p.id AND t.assigned_to = %d))", $id, get_current_user_id(), get_current_user_id()));
        if (!$own) wp_die('Not allowed');
    }
    $note = sanitize_text_field(wp_unslash($_POST['note']));
    if ($note !== '') fwcrm_project_log($id, $note);
    if (!fwcrm_is_admin_user() && $note !== '' && function_exists('fwcrm_push')) fwcrm_push('📝 ' . wp_get_current_user()->display_name . ' posted an update', $note, admin_url('admin.php?page=fwcrm-projects&p=' . $id), 'memo');
    wp_safe_redirect(fwcrm_is_admin_user() ? admin_url('admin.php?page=fwcrm-projects&p=' . $id) : admin_url('admin.php?page=fwcrm-my&fwmsg=' . rawurlencode('Update posted.')));
    exit;
});

/* =========================================================
 * "My work" for team members
 * ======================================================= */

function fwcrm_page_my() {
    global $wpdb;
    $me = wp_get_current_user();
    $uid = $me->ID;
    $tasks = $wpdb->get_results($wpdb->prepare("SELECT t.*, p.title ptitle, c.company, c.email FROM " . fwcrm_t('tasks') . " t LEFT JOIN " . fwcrm_t('projects') . " p ON p.id = t.project_id LEFT JOIN " . fwcrm_t('contacts') . " c ON c.id = t.contact_id WHERE t.assigned_to = %d AND t.done = 0 ORDER BY (t.due IS NULL), t.due ASC", $uid));
    $done = $wpdb->get_results($wpdb->prepare("SELECT t.*, p.title ptitle FROM " . fwcrm_t('tasks') . " t LEFT JOIN " . fwcrm_t('projects') . " p ON p.id = t.project_id WHERE t.assigned_to = %d AND t.done = 1 ORDER BY t.done_at DESC LIMIT 8", $uid));
    $projects = $wpdb->get_results($wpdb->prepare("SELECT p.* FROM " . fwcrm_t('projects') . " p WHERE p.status <> 'delivered' AND (p.owner_id = %d OR EXISTS (SELECT 1 FROM " . fwcrm_t('tasks') . " t WHERE t.project_id = p.id AND t.assigned_to = %d)) ORDER BY (p.due IS NULL), p.due ASC", $uid, $uid));
    $late = count(array_filter($tasks, function ($t) { return $t->due && strtotime($t->due) < current_time('timestamp'); }));
    fwcrm_header('Hi ' . ($me->first_name ?: $me->display_name), $tasks ? sprintf('%d task%s on your list%s.', count($tasks), count($tasks) === 1 ? '' : 's', $late ? ', ' . $late . ' overdue' : '') : 'Nothing on your list right now.', '');
    echo '<div class="fw-today"><section class="fw-tsec"><div class="fw-tsec-h"><h2>My tasks</h2><span class="fw-dim">tap the circle when done</span></div>';
    if (!$tasks) echo '<div class="fw-tempty">All done. New tasks from Felix appear here, and you get an email.</div>';
    $st = array('todo' => 'To do', 'doing' => 'Doing');
    foreach ($tasks as $t) {
        $is_late = $t->due && strtotime($t->due) < current_time('timestamp');
        $notes = get_option('fwcrm_task_notes_' . $t->id, '');
        echo '<div class="fw-trow task' . ($is_late ? ' late' : '') . '"><button class="fw-tcheck" data-fw-mine="done" data-id="' . (int) $t->id . '" title="Mark done"></button><div class="fw-tmain"><b>' . esc_html($t->title) . '</b><p>' . ($t->due ? ($is_late ? 'overdue · ' . esc_html(fwcrm_time_ago($t->due)) : 'due ' . esc_html(date_i18n('D j M, H:i', strtotime($t->due)))) : 'no date') . ($t->ptitle ? ' · ' . esc_html($t->ptitle) : '') . '</p>' . ($notes ? '<details class="fw-tnotes"><summary>Details</summary><div>' . nl2br(esc_html($notes)) . '</div></details>' : '') . '</div><button class="fw-btn sm ' . ($t->status === 'doing' ? 'gold' : '') . '" data-fw-mine="doing" data-id="' . (int) $t->id . '">' . ($t->status === 'doing' ? 'Doing' : 'Start') . '</button></div>';
    }
    echo '</section><section class="fw-tsec"><div class="fw-tsec-h"><h2>My projects</h2></div>';
    if (!$projects) echo '<div class="fw-tempty">No active projects.</div>';
    $ss = fwcrm_project_statuses();
    foreach ($projects as $p) {
        echo '<div class="fw-trow"><span class="fw-ticon">🎬</span><div class="fw-tmain"><b>' . esc_html($p->title) . '</b><p>' . esc_html($ss[$p->status]) . ($p->due ? ' · due ' . esc_html(date_i18n('j M', strtotime($p->due))) : '') . ((int) $p->owner_id === $uid ? ' · you lead this' : '') . '</p>' . ($p->brief ? '<details class="fw-tnotes"><summary>Brief</summary><div>' . nl2br(esc_html($p->brief)) . '</div></details>' : '') . fwcrm_post_form_open('fwcrm_project_note', 'class="fw-noteform"') . '<input type="hidden" name="id" value="' . (int) $p->id . '"><input name="note" placeholder="Post an update for Felix…"><button class="fw-btn sm">Post</button></form></div></div>';
    }
    echo '</section><section class="fw-tsec"><div class="fw-tsec-h"><h2>Recently done</h2></div>';
    if (!$done) echo '<div class="fw-tempty">Finished tasks show here.</div>';
    foreach ($done as $t) echo '<div class="fw-trow done"><span class="fw-ticon">✓</span><div class="fw-tmain"><b>' . esc_html($t->title) . '</b><p>' . esc_html(fwcrm_time_ago($t->done_at)) . ($t->ptitle ? ' · ' . esc_html($t->ptitle) : '') . '</p></div></div>';
    echo '</section></div>';
    fwcrm_footer();
}

add_action('wp_ajax_fwcrm_mine', function () {
    if (!current_user_can('fwcrm_team') || !check_ajax_referer('fwcrm', 'nonce', false)) wp_send_json_error('Not allowed');
    global $wpdb;
    $id = (int) $_POST['id'];
    $t = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('tasks') . " WHERE id = %d", $id));
    if (!$t || ((int) $t->assigned_to !== get_current_user_id() && !fwcrm_is_admin_user())) wp_send_json_error('Not your task');
    if ($_POST['do'] === 'done') {
        $wpdb->update(fwcrm_t('tasks'), array('done' => 1, 'done_at' => fwcrm_now(), 'status' => 'done'), array('id' => $id));
        if ($t->project_id) fwcrm_project_log($t->project_id, 'Done: ' . $t->title);
        if (!fwcrm_is_admin_user() && function_exists('fwcrm_push')) fwcrm_push('✅ ' . wp_get_current_user()->display_name . ' finished a task', $t->title, admin_url('admin.php?page=fwcrm-team'), 'white_check_mark');
        wp_send_json_success(array('msg' => 'Done ✓', 'remove' => 1));
    }
    if ($_POST['do'] === 'doing') {
        $new = $t->status === 'doing' ? 'todo' : 'doing';
        $wpdb->update(fwcrm_t('tasks'), array('status' => $new), array('id' => $id));
        if ($t->project_id && $new === 'doing') fwcrm_project_log($t->project_id, 'Started: ' . $t->title);
        wp_send_json_success(array('msg' => $new === 'doing' ? 'Marked as in progress' : 'Back to to-do', 'reload' => 1));
    }
    wp_send_json_error('Unknown');
});

/* Project status quick-change (admin) */
add_action('wp_ajax_fwcrm_work', function () {
    if (!isset($_POST['do']) || $_POST['do'] !== 'pstatus') return;
    if (!current_user_can('manage_options') || !check_ajax_referer('fwcrm', 'nonce', false)) wp_send_json_error('Not allowed');
    global $wpdb;
    $id = (int) $_POST['id'];
    $v = sanitize_key($_POST['v']);
    if (!array_key_exists($v, fwcrm_project_statuses())) wp_send_json_error('Bad status');
    $wpdb->update(fwcrm_t('projects'), array('status' => $v, 'updated' => fwcrm_now()), array('id' => $id));
    fwcrm_project_log($id, 'Status → ' . fwcrm_project_statuses()[$v]);
    wp_send_json_success(array('msg' => 'Status: ' . fwcrm_project_statuses()[$v], 'reload' => 1));
}, 1);

/* =========================================================
 * Keep members inside "My work"
 * ======================================================= */

add_action('admin_init', function () {
    if (!fwcrm_is_member() || wp_doing_ajax()) return;
    global $pagenow;
    $ok = in_array($pagenow, array('admin-post.php', 'profile.php', 'async-upload.php'), true) || ($pagenow === 'admin.php' && isset($_GET['page']) && $_GET['page'] === 'fwcrm-my');
    if (!$ok) { wp_safe_redirect(admin_url('admin.php?page=fwcrm-my')); exit; }
}, 1);

add_filter('login_redirect', function ($to, $req, $user) {
    if ($user instanceof WP_User && !user_can($user, 'manage_options') && user_can($user, 'fwcrm_team')) return admin_url('admin.php?page=fwcrm-my');
    return $to;
}, 10, 3);

add_action('admin_menu', function () {
    add_submenu_page('fwcrm', 'Team', 'Team', 'manage_options', 'fwcrm-team', 'fwcrm_page_team');
    add_submenu_page('fwcrm', 'Projects', 'Projects', 'manage_options', 'fwcrm-projects', 'fwcrm_page_projects');
    if (fwcrm_is_member()) {
        add_menu_page('My work', 'My work', 'fwcrm_team', 'fwcrm-my', 'fwcrm_page_my', 'dashicons-yes-alt', 2);
    }
}, 20);

add_filter('show_admin_bar', function ($show) { return fwcrm_is_member() ? false : $show; });

/* =========================================================
 * Public team endpoint for the website
 * ======================================================= */

add_action('rest_api_init', function () {
    register_rest_route('fwcrm/v1', '/team', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function () {
        $cached = get_transient('fwcrm_team_public');
        if ($cached === false) {
            $cached = array();
            foreach (fwcrm_team_users(true) as $u) {
                $cached[] = array(
                    'name' => $u->display_name,
                    'title' => (string) get_user_meta($u->ID, 'fw_title', true) ?: (user_can($u, 'manage_options') ? 'Founder' : 'Team member'),
                    'bio' => (string) get_user_meta($u->ID, 'fw_bio', true),
                    'photo' => fwcrm_member_photo($u->ID, 'large'),
                );
            }
            set_transient('fwcrm_team_public', $cached, HOUR_IN_SECONDS);
        }
        $r = rest_ensure_response($cached);
        $r->header('Cache-Control', 'public, max-age=600');
        return $r;
    }));
});

add_action('admin_page_access_denied', function () {
    if (fwcrm_is_member()) { wp_safe_redirect(admin_url('admin.php?page=fwcrm-my')); exit; }
});

/* =========================================================
 * Website enquiry form → lead + task + alert
 * ======================================================= */

add_action('rest_api_init', function () {
    register_rest_route('fwcrm/v1', '/enquiry', array('methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'fwcrm_rest_enquiry'));
});

function fwcrm_rest_enquiry($req) {
    $p = $req->get_json_params();
    if (!is_array($p)) $p = $req->get_params();
    if (!empty($p['company_url'])) return new WP_REST_Response(array('ok' => true), 200); // honeypot
    if (empty($p['t']) || (time() - (int) $p['t'] / 1000) < 3) return new WP_REST_Response(array('ok' => false, 'msg' => 'Please try again.'), 400);
    $ip = function_exists('fwcrm_client_ip') ? fwcrm_client_ip() : $_SERVER['REMOTE_ADDR'];
    $rk = 'fwcrm_enq_' . md5($ip);
    $n = (int) get_transient($rk);
    if ($n >= 5) return new WP_REST_Response(array('ok' => false, 'msg' => 'Too many messages. Please email hello@felixeweb.com.'), 429);
    set_transient($rk, $n + 1, HOUR_IN_SECONDS);
    $email = sanitize_email(isset($p['email']) ? $p['email'] : '');
    $name = sanitize_text_field(isset($p['name']) ? $p['name'] : '');
    $msg = sanitize_textarea_field(isset($p['message']) ? $p['message'] : '');
    if (!is_email($email) || $name === '' || mb_strlen($msg) < 10) return new WP_REST_Response(array('ok' => false, 'msg' => 'Please add your name, a valid email and a short message.'), 400);
    $services = array('web' => 'Website or store', 'app' => 'App', '2d' => '2D explainer video', '3d' => '3D animation', 'edit' => 'AI video editing', 'book' => 'Book formatting', 'automation' => 'AI automation', 'other' => 'Something else');
    $svc = isset($p['service']) && isset($services[$p['service']]) ? $p['service'] : 'other';
    $budget = sanitize_text_field(isset($p['budget']) ? $p['budget'] : '');
    $site = esc_url_raw(isset($p['website']) ? $p['website'] : '');
    $parts = preg_split('/\s+/', $name, 2);
    $lane = in_array($svc, array('2d', '3d', 'edit'), true) ? 'video' : ($svc === 'book' ? 'book' : 'web');
    $cid = fwcrm_upsert_contact(array(
        'email' => $email, 'first_name' => $parts[0], 'last_name' => isset($parts[1]) ? $parts[1] : '',
        'company' => sanitize_text_field(isset($p['company']) ? $p['company'] : ''), 'website' => $site,
        'source' => 'website', 'tags' => 'website enquiry', 'stage' => 'replied',
        'notes' => 'Website enquiry · ' . $services[$svc] . ($budget ? ' · budget ' . $budget : ''),
    ));
    if (!$cid) return new WP_REST_Response(array('ok' => false, 'msg' => 'Something went wrong. Please email hello@felixeweb.com.'), 500);
    global $wpdb;
    $wpdb->update(fwcrm_t('contacts'), array('lane' => $lane), array('id' => $cid));
    $wpdb->insert(fwcrm_t('emails'), array(
        'contact_id' => $cid, 'direction' => 'in', 'kind' => 'reply', 'handled' => 0, 'source' => 'website',
        'subject' => 'Website enquiry: ' . $services[$svc], 'snippet' => wp_html_excerpt($msg, 180, '…'), 'body' => $msg . "\n\n— Service: " . $services[$svc] . ($budget ? "\n— Budget: " . $budget : '') . ($site ? "\n— Website: " . $site : ''),
        'from_email' => $email, 'to_email' => fwcrm_opt('from_email'), 'sent_at' => fwcrm_now(), 'status' => 'received',
    ));
    $wpdb->update(fwcrm_t('contacts'), array('last_reply' => fwcrm_now()), array('id' => $cid));
    fwcrm_event($cid, 'inbound', array('subject' => 'Website enquiry'));
    if (function_exists('fwcrm_task_add')) fwcrm_task_add($cid, 'todo', 'Reply to website enquiry: ' . $name, date('Y-m-d H:i:s', current_time('timestamp') + 2 * HOUR_IN_SECONDS));
    $url = fwcrm_admin_url('fwcrm-inbox', array('tab' => 'all', 'c' => $cid));
    if (function_exists('fwcrm_push')) fwcrm_push('📩 New enquiry: ' . $name, $services[$svc] . ' · ' . wp_html_excerpt($msg, 160, '…'), $url, 'envelope');
    fwcrm_notify('New website enquiry from ' . $name, array('From: ' . $name . ' <' . $email . '>', 'Service: ' . $services[$svc], $budget ? 'Budget: ' . $budget : '', $site ? 'Website: ' . $site : '', '', $msg), $url);
    return new WP_REST_Response(array('ok' => true), 200);
}
