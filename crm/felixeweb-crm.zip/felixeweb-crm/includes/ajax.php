<?php
if (!defined('ABSPATH')) exit;

/* ---------- admin-post form handlers ---------- */

function fwcrm_guard($action) {
    if (!current_user_can('manage_options')) wp_die('Not allowed');
    check_admin_referer('fwcrm_' . $action, '_fwnonce');
}

function fwcrm_back($page, $args = array(), $msg = '', $err = false) {
    if ($msg) $args['fwmsg'] = $msg;
    if ($err) $args['fwerr'] = 1;
    wp_safe_redirect(fwcrm_admin_url($page, $args));
    exit;
}

add_action('admin_post_fwcrm_save_settings', function () {
    fwcrm_guard('fwcrm_save_settings');
    $p = wp_unslash($_POST);
    $new = array();
    foreach (array('from_name', 'from_email', 'reply_to', 'smtp_host', 'smtp_secure', 'imap_host', 'mail_user', 'sent_folder', 'notify_email', 'unsub_text', 'gmail_user', 'gmail_from_filter', 'hub_mode', 'remote_hub_url', 'website_url', 'allowed_origins', 'windsor_threads_id', 'windsor_instagram_id', 'schedule_url', 'ai_model', 'api_key') as $k) {
        if (isset($p[$k])) $new[$k] = sanitize_text_field($p[$k]);
    }
    foreach (array('smtp_port', 'imap_port', 'import_days', 'followup_days', 'daily_cap', 'min_gap_minutes', 'window_start', 'window_end', 'auto_enroll_seq', 'gmail_import_days') as $k) {
        if (isset($p[$k])) $new[$k] = (int) $p[$k];
    }
    foreach (array('import_sent', 'save_to_sent', 'unsub_footer', 'track_opens', 'track_clicks', 'track_visitors', 'track_admins', 'notify_reply', 'notify_hot_visit', 'daily_digest', 'gmail_enabled', 'app_frontpage', 'app_mode') as $k) {
        $new[$k] = empty($p[$k]) ? 0 : 1;
    }
    $new['workdays'] = isset($p['workdays']) ? array_map('intval', (array) $p['workdays']) : array();
    $new['signature'] = isset($p['signature']) ? sanitize_textarea_field($p['signature']) : '';
    $new['ignore_domains'] = isset($p['ignore_domains']) ? sanitize_textarea_field($p['ignore_domains']) : '';
    if (isset($p['mail_pass']) && $p['mail_pass'] !== '') {
        $new['mail_pass'] = fwcrm_encrypt($p['mail_pass']);
    }
    foreach (array('gmail_pass', 'windsor_key', 'ai_key') as $k) {
        if (isset($p[$k]) && trim($p[$k]) !== '') $new[$k] = fwcrm_encrypt(trim(str_replace(' ', $k === 'gmail_pass' ? '' : ' ', $p[$k])));
    }
    if (isset($p['ai_about'])) $new['ai_about'] = sanitize_textarea_field($p['ai_about']);
    $had_gmail = fwcrm_gmail_ready();
    $had = fwcrm_mailbox_ready();
    fwcrm_save_settings($new);
    if (!$had && !empty($new['mail_pass'])) {
        // First connection: test and run the first import right away.
        $res = fwcrm_sync_mailbox(true);
        if (is_wp_error($res)) fwcrm_back('fwcrm-settings', array(), 'Saved, but the mailbox could not connect: ' . $res->get_error_message(), true);
        fwcrm_back('fwcrm', array(), sprintf('Mailbox connected. Imported %d sent emails and %d replies.', $res['sent'], $res['replies']));
    }
    if (!$had_gmail && fwcrm_gmail_ready()) {
        $res = fwcrm_sync_mailbox(true);
        if (is_wp_error($res)) fwcrm_back('fwcrm-settings', array(), 'Saved, but Gmail could not connect: ' . $res->get_error_message(), true);
        fwcrm_back('fwcrm', array(), sprintf('Gmail connected. Imported %d scout emails and %d replies.', $res['sent'], $res['replies']));
    }
    if (!empty($new['windsor_key'])) { delete_transient('fwcrm_schedule'); fwcrm_social_refresh(); }
    fwcrm_back('fwcrm-settings', array(), 'Settings saved.');
});

add_action('admin_post_fwcrm_add', function () {
    fwcrm_guard('fwcrm_add');
    $p = wp_unslash($_POST);
    $p['source'] = 'manual';
    $id = fwcrm_upsert_contact($p, true);
    if (!$id) fwcrm_back('fwcrm-contacts', array('add' => 1), 'Please enter a valid email.', true);
    if (!empty($p['enroll'])) fwcrm_enroll($id, (int) $p['enroll']);
    fwcrm_back('fwcrm-contacts', array('view' => $id), 'Lead saved.' . (!empty($p['enroll']) ? ' Automatic emails scheduled.' : ''));
});

add_action('admin_post_fwcrm_import', function () {
    fwcrm_guard('fwcrm_import');
    $text = '';
    if (!empty($_FILES['csv']['tmp_name']) && is_uploaded_file($_FILES['csv']['tmp_name'])) {
        $text = file_get_contents($_FILES['csv']['tmp_name']);
    }
    if (!$text && !empty($_POST['csv_text'])) $text = wp_unslash($_POST['csv_text']);
    $text = preg_replace('/^\xEF\xBB\xBF/', '', (string) $text);
    $lines = array_filter(preg_split('/\r\n|\r|\n/', $text), 'strlen');
    if (count($lines) < 1) fwcrm_back('fwcrm-contacts', array('import' => 1), 'No rows found.', true);
    $first = str_getcsv(array_shift($lines));
    $head = array_map(function ($h) { return strtolower(trim(str_replace(array(' ', '-'), '_', $h))); }, $first);
    $map = array('name' => 'first_name', 'firstname' => 'first_name', 'lastname' => 'last_name', 'brand' => 'company', 'store' => 'company', 'url' => 'website', 'site' => 'website', 'email_address' => 'email', 'e_mail' => 'email');
    $head = array_map(function ($h) use ($map) { return isset($map[$h]) ? $map[$h] : $h; }, $head);
    if (!in_array('email', $head, true)) {
        // No header row: assume the first column is email.
        array_unshift($lines, implode(',', $first));
        $head = array('email', 'first_name', 'company', 'website');
    }
    $seq = !empty($_POST['enroll']) ? (int) $_POST['enroll'] : 0;
    $added = 0;
    foreach ($lines as $line) {
        $cols = str_getcsv($line);
        $row = array();
        foreach ($head as $i => $h) if (isset($cols[$i])) $row[$h] = trim($cols[$i]);
        if (empty($row['email'])) continue;
        $row['source'] = 'import';
        $id = fwcrm_upsert_contact($row);
        if ($id) {
            $added++;
            if ($seq) fwcrm_enroll($id, $seq);
        }
    }
    fwcrm_back('fwcrm-contacts', array(), sprintf('Imported %d leads.%s', $added, $seq ? ' Their emails will go out during your sending hours.' : ''));
});

add_action('admin_post_fwcrm_save_contact', function () {
    fwcrm_guard('fwcrm_save_contact');
    $p = wp_unslash($_POST);
    $id = (int) $p['id'];
    $data = array();
    foreach (array('first_name', 'last_name', 'company', 'website', 'phone', 'niche', 'tags', 'country', 'platform') as $f) $data[$f] = sanitize_text_field(isset($p[$f]) ? $p[$f] : '');
    $data['notes'] = sanitize_textarea_field(isset($p['notes']) ? $p['notes'] : '');
    $data['socials'] = sanitize_textarea_field(isset($p['socials']) ? $p['socials'] : '');
    $email = fwcrm_clean_email(isset($p['email']) ? $p['email'] : '');
    if ($email) $data['email'] = $email;
    fwcrm_update_contact($id, $data);
    fwcrm_back('fwcrm-contacts', array('view' => $id), 'Saved.');
});

add_action('admin_post_fwcrm_delete_contact', function () {
    fwcrm_guard('fwcrm_delete_contact');
    global $wpdb;
    $id = (int) $_POST['id'];
    foreach (array('contacts' => 'id', 'emails' => 'contact_id', 'events' => 'contact_id', 'enrollments' => 'contact_id') as $t => $col) $wpdb->delete(fwcrm_t($t), array($col => $id));
    $wpdb->update(fwcrm_t('visits'), array('contact_id' => 0), array('contact_id' => $id));
    fwcrm_back('fwcrm-contacts', array(), 'Lead deleted.');
});

add_action('admin_post_fwcrm_send', function () {
    fwcrm_guard('fwcrm_send');
    global $wpdb;
    $p = wp_unslash($_POST);
    $id = (int) $p['id'];
    $thread = isset($p['thread']) ? sanitize_text_field($p['thread']) : '';
    $refs = '';
    if ($thread) $refs = (string) $wpdb->get_var($wpdb->prepare("SELECT thread_root FROM " . fwcrm_t('emails') . " WHERE message_id = %s LIMIT 1", $thread));
    if ($refs === $thread) $refs = '';
    $res = fwcrm_send_email($id, array(
        'subject' => sanitize_text_field($p['subject']),
        'body' => sanitize_textarea_field($p['body']),
        'in_reply_to' => $thread,
        'references' => $refs,
        'kind' => 'email',
        'merge' => true,
    ));
    $back = !empty($p['back']) && $p['back'] === 'inbox' ? array('fwcrm-inbox', array('tab' => !empty($p['tab']) ? sanitize_key($p['tab']) : 'all', 'c' => $id)) : array('fwcrm-contacts', array('view' => $id));
    if (is_wp_error($res)) fwcrm_back($back[0], $back[1], $res->get_error_message(), true);
    if (!empty($p['handled'])) $wpdb->update(fwcrm_t('emails'), array('handled' => 1), array('id' => (int) $p['handled']));
    $wpdb->update(fwcrm_t('emails'), array('handled' => 1), array('contact_id' => $id, 'direction' => 'in'));
    fwcrm_back($back[0], $back[1], 'Email sent.');
});

add_action('admin_post_fwcrm_note', function () {
    fwcrm_guard('fwcrm_note');
    $id = (int) $_POST['id'];
    $note = sanitize_text_field(wp_unslash($_POST['note']));
    if ($note !== '') fwcrm_event($id, 'note', array('text' => $note));
    fwcrm_back('fwcrm-contacts', array('view' => $id));
});

add_action('admin_post_fwcrm_bulk', function () {
    fwcrm_guard('fwcrm_bulk');
    global $wpdb;
    $ids = array_map('intval', isset($_POST['ids']) ? (array) $_POST['ids'] : array());
    $act = sanitize_text_field(wp_unslash(isset($_POST['bulk_action']) ? $_POST['bulk_action'] : ''));
    if (!$ids || !$act) fwcrm_back('fwcrm-contacts', array(), 'Select leads and an action.', true);
    $n = 0;
    foreach ($ids as $id) {
        if (strpos($act, 'enroll:') === 0) { if (fwcrm_enroll($id, (int) substr($act, 7))) $n++; }
        elseif (strpos($act, 'stage:') === 0) { fwcrm_update_contact($id, array('stage' => sanitize_key(substr($act, 6)))); fwcrm_event($id, 'stage', array('to' => substr($act, 6))); $n++; }
        elseif ($act === 'stop') { $n += fwcrm_stop_enrollments($id, 'stopped_manual') ? 1 : 0; }
        elseif ($act === 'delete') {
            foreach (array('contacts' => 'id', 'emails' => 'contact_id', 'events' => 'contact_id', 'enrollments' => 'contact_id') as $t => $col) $wpdb->delete(fwcrm_t($t), array($col => $id));
            $n++;
        }
    }
    fwcrm_back('fwcrm-contacts', array(), sprintf('Done for %d lead(s).', $n));
});

add_action('admin_post_fwcrm_save_sequence', function () {
    fwcrm_guard('fwcrm_save_sequence');
    global $wpdb;
    $p = wp_unslash($_POST);
    $steps = array();
    foreach ((array) (isset($p['steps']) ? $p['steps'] : array()) as $st) {
        $body = sanitize_textarea_field(isset($st['body']) ? $st['body'] : '');
        if (trim($body) === '') continue;
        $steps[] = array('delay_days' => max(0, (float) $st['delay_days']), 'subject' => sanitize_text_field($st['subject']), 'body' => $body);
    }
    $data = array('name' => sanitize_text_field($p['name']), 'active' => empty($p['active']) ? 0 : 1, 'steps' => wp_json_encode($steps));
    $id = (int) $p['id'];
    if ($id) $wpdb->update(fwcrm_t('sequences'), $data, array('id' => $id));
    else { $data['created'] = fwcrm_now(); $wpdb->insert(fwcrm_t('sequences'), $data); $id = (int) $wpdb->insert_id; }
    if (!empty($p['auto_enroll'])) fwcrm_save_settings(array('auto_enroll_seq' => $id));
    elseif ((int) fwcrm_opt('auto_enroll_seq') === $id) fwcrm_save_settings(array('auto_enroll_seq' => 0));
    fwcrm_back('fwcrm-sequences', array(), 'Sequence saved.');
});

add_action('admin_post_fwcrm_delete_sequence', function () {
    fwcrm_guard('fwcrm_delete_sequence');
    global $wpdb;
    $id = (int) $_POST['id'];
    $wpdb->delete(fwcrm_t('sequences'), array('id' => $id));
    $wpdb->update(fwcrm_t('enrollments'), array('status' => 'stopped'), array('sequence_id' => $id, 'status' => 'active'));
    if ((int) fwcrm_opt('auto_enroll_seq') === $id) fwcrm_save_settings(array('auto_enroll_seq' => 0));
    fwcrm_back('fwcrm-sequences', array(), 'Sequence deleted.');
});

/* ---------- AJAX ---------- */

add_action('wp_ajax_fwcrm', function () {
    if (!current_user_can('manage_options')) wp_send_json_error('Not allowed', 403);
    check_ajax_referer('fwcrm', 'nonce');
    global $wpdb;
    $do = sanitize_key(isset($_POST['do']) ? $_POST['do'] : '');
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
    switch ($do) {
        case 'fwcrm_stage':
            $stage = sanitize_key($_POST['stage']);
            if (!isset(fwcrm_stages()[$stage])) wp_send_json_error('Bad stage');
            $c = fwcrm_get_contact($id);
            fwcrm_update_contact($id, array('stage' => $stage));
            fwcrm_event($id, 'stage', array('from' => $c ? $c->stage : '', 'to' => $stage));
            if (in_array($stage, array('call', 'proposal', 'won', 'lost'), true)) fwcrm_stop_enrollments($id, 'stage_' . $stage);
            wp_send_json_success(array('msg' => 'Moved to ' . fwcrm_stages()[$stage]));
        case 'fwcrm_enroll':
            $ok = fwcrm_enroll($id, (int) $_POST['seq']);
            $ok ? wp_send_json_success(array('msg' => 'Follow-ups scheduled', 'reload' => 1)) : wp_send_json_error('Could not start: already in a sequence, unsubscribed or bounced');
        case 'fwcrm_stop':
            fwcrm_stop_enrollments($id, 'stopped_manual');
            wp_send_json_success(array('msg' => 'Follow-ups stopped', 'reload' => 1));
        case 'fwcrm_send_next':
            $en = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('enrollments') . " WHERE contact_id=%d AND status='active' LIMIT 1", $id));
            if (!$en) wp_send_json_error('Not in a sequence');
            $ok = fwcrm_process_enrollment($en);
            $ok ? wp_send_json_success(array('msg' => 'Sent', 'reload' => 1)) : wp_send_json_error('Not sent: check the activity log in Settings');
        case 'fwcrm_handled_all':
            $wpdb->update(fwcrm_t('emails'), array('handled' => 1), array('contact_id' => $id, 'direction' => 'in'));
            wp_send_json_success(array('msg' => 'Conversation marked as handled', 'reload' => 1));
        case 'fwcrm_handled':
            $wpdb->update(fwcrm_t('emails'), array('handled' => 1), array('id' => $id));
            wp_send_json_success(array('msg' => 'Marked as handled', 'remove' => 1));
        case 'fwcrm_snooze':
            fwcrm_update_contact($id, array('next_followup' => date('Y-m-d 09:00:00', current_time('timestamp') + 3 * DAY_IN_SECONDS)));
            wp_send_json_success(array('msg' => 'Snoozed 3 days', 'remove' => 1));
        case 'fwcrm_clear_followup':
            fwcrm_update_contact($id, array('next_followup' => null));
            wp_send_json_success(array('msg' => 'Cleared', 'remove' => 1));
        case 'fwcrm_unbounce':
            fwcrm_update_contact($id, array('bounced' => 0));
            wp_send_json_success(array('msg' => 'Marked as valid', 'reload' => 1));
        case 'fwcrm_social_refresh':
            delete_transient('fwcrm_schedule');
            $r = fwcrm_social_refresh();
            $errs = array_filter($r, function ($v) { return $v !== 'ok'; });
            wp_send_json_success(array('msg' => $errs ? 'Updated with issues: ' . implode(' · ', $errs) : 'Social numbers updated', 'reload' => 1));
        case 'fwcrm_ai_clear':
            $wpdb->query("DELETE FROM " . fwcrm_t('ai') . " WHERE thread='main'");
            wp_send_json_success(array('msg' => 'New chat started', 'reload' => 1));
        case 'fwcrm_gmail_diag':
            if (!fwcrm_gmail_ready()) wp_send_json_error('Gmail not ready');
            $acct = null;
            foreach (fwcrm_mail_accounts() as $a) if ($a['key'] === 'gmail') $acct = $a;
            $imap = new FWCRM_IMAP();
            if (!$imap->connect($acct['host'], $acct['port'], $acct['user'], $acct['pass'])) wp_send_json_error('connect: ' . $imap->error);
            $out = array('folders' => array());
            foreach ($imap->list_folders() as $f) $out['folders'][] = $f['name'] . ' ' . $f['flags'];
            $sf = $imap->find_sent_folder();
            $out['sent_folder'] = $sf;
            $info = $sf ? $imap->select($sf) : false;
            $out['info'] = $info;
            $since = current_time('timestamp') - 30 * DAY_IN_SECONDS;
            $uids = $info ? $imap->search_uids(0, $since) : array();
            $out['found'] = count($uids);
            $out['state'] = get_option('fwcrm_sync_state', array());
            $rows = array();
            foreach ($imap->fetch_messages(array_slice($uids, -40)) as $uid => $msg) {
                $m = fwcrm_msg_basics($msg);
                $from = fwcrm_addresses(isset($m['h']['from']) ? $m['h']['from'] : '');
                $rows[] = array('uid' => $uid, 'from' => implode(',', $from), 'to' => implode(',', $m['to']), 'subj' => wp_html_excerpt($m['subject'], 40, ''), 'mid' => $m['message_id'] ? 'y' : 'n', 'exists' => $m['message_id'] && fwcrm_email_exists($m['message_id']) ? 'y' : 'n', 'hdrlen' => strlen($msg['header']));
            }
            $out['rows'] = $rows;
            $imap->logout();
            wp_send_json_success($out);
        case 'fwcrm_gmail_resync':
            $st = get_option('fwcrm_sync_state', array());
            unset($st['gmail_sent'], $st['gmail_inbox']);
            update_option('fwcrm_sync_state', $st, false);
            wp_send_json_success(array('msg' => 'Gmail will re-import on the next sync'));
        case 'fwcrm_sync_now':
            if (!fwcrm_mailbox_ready() && !fwcrm_gmail_ready()) wp_send_json_error('Connect your mailbox in Settings first');
            $r = fwcrm_sync_mailbox(true);
            if (is_wp_error($r)) wp_send_json_error($r->get_error_message());
            wp_send_json_success(array('msg' => sprintf('Synced: %d sent, %d replies, %d bounces, %d new inbound', $r['sent'], $r['replies'], $r['bounces'], $r['inbound']), 'reload' => 1));
        case 'fwcrm_run_now':
            $n = fwcrm_run_automations(true);
            wp_send_json_success(array('msg' => $n ? "Sent $n due email(s)" : 'Nothing due right now', 'reload' => $n ? 1 : 0));
        case 'fwcrm_test_mailbox':
            if (!fwcrm_mailbox_ready()) wp_send_json_error('Save your mailbox password first');
            $imap = new FWCRM_IMAP();
            if (!$imap->connect(fwcrm_opt('imap_host'), fwcrm_opt('imap_port'), fwcrm_opt('mail_user'), fwcrm_mail_pass())) wp_send_json_error('IMAP: ' . $imap->error);
            $sent = $imap->find_sent_folder();
            $imap->logout();
            wp_send_json_success(array('msg' => 'Mailbox OK · Sent folder: ' . ($sent ?: 'not found')));
        case 'fwcrm_test_send':
            if (!fwcrm_mailbox_ready()) wp_send_json_error('Save your mailbox password first');
            $GLOBALS['fwcrm_sending'] = array('message_id' => '', 'alt' => '');
            $GLOBALS['fwcrm_last_error'] = '';
            $ok = wp_mail(fwcrm_opt('notify_email'), 'FelixeWeb CRM test email', "It works! Your CRM can send from " . fwcrm_opt('from_email') . ".");
            unset($GLOBALS['fwcrm_sending']);
            $ok ? wp_send_json_success(array('msg' => 'Test email sent to ' . fwcrm_opt('notify_email'))) : wp_send_json_error('SMTP: ' . $GLOBALS['fwcrm_last_error']);
    }
    wp_send_json_error('Unknown action');
});
