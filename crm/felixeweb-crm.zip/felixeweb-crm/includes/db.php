<?php
if (!defined('ABSPATH')) exit;

function fwcrm_install_tables() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $cs = $wpdb->get_charset_collate();

    dbDelta("CREATE TABLE " . fwcrm_t('contacts') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        email varchar(190) NOT NULL,
        first_name varchar(100) NOT NULL DEFAULT '',
        last_name varchar(100) NOT NULL DEFAULT '',
        company varchar(190) NOT NULL DEFAULT '',
        website varchar(255) NOT NULL DEFAULT '',
        phone varchar(60) NOT NULL DEFAULT '',
        niche varchar(100) NOT NULL DEFAULT '',
        country varchar(80) NOT NULL DEFAULT '',
        platform varchar(60) NOT NULL DEFAULT '',
        problems text NULL,
        socials text NULL,
        source varchar(40) NOT NULL DEFAULT 'manual',
        stage varchar(30) NOT NULL DEFAULT 'new',
        tags varchar(255) NOT NULL DEFAULT '',
        notes longtext NULL,
        score int(11) NOT NULL DEFAULT 0,
        token varchar(32) NOT NULL DEFAULT '',
        last_contacted datetime NULL,
        last_reply datetime NULL,
        last_open datetime NULL,
        last_click datetime NULL,
        last_visit datetime NULL,
        next_followup datetime NULL,
        unsubscribed tinyint(1) NOT NULL DEFAULT 0,
        bounced tinyint(1) NOT NULL DEFAULT 0,
        deal_value decimal(12,2) NOT NULL DEFAULT 0,
        won_at datetime NULL,
        created datetime NOT NULL,
        updated datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY email (email),
        KEY stage (stage),
        KEY token (token),
        KEY next_followup (next_followup)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('emails') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
        direction varchar(4) NOT NULL DEFAULT 'out',
        kind varchar(20) NOT NULL DEFAULT 'email',
        subject varchar(255) NOT NULL DEFAULT '',
        body longtext NULL,
        snippet text NULL,
        from_email varchar(190) NOT NULL DEFAULT '',
        to_email varchar(190) NOT NULL DEFAULT '',
        message_id varchar(255) NOT NULL DEFAULT '',
        in_reply_to varchar(255) NOT NULL DEFAULT '',
        thread_root varchar(255) NOT NULL DEFAULT '',
        token varchar(32) NOT NULL DEFAULT '',
        sequence_id bigint(20) unsigned NOT NULL DEFAULT 0,
        step int(11) NOT NULL DEFAULT 0,
        source varchar(20) NOT NULL DEFAULT 'crm',
        status varchar(20) NOT NULL DEFAULT 'sent',
        error text NULL,
        opens int(11) NOT NULL DEFAULT 0,
        clicks int(11) NOT NULL DEFAULT 0,
        first_open datetime NULL,
        handled tinyint(1) NOT NULL DEFAULT 0,
        sent_at datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY contact_id (contact_id),
        KEY message_id (message_id(191)),
        KEY token (token),
        KEY direction_sent (direction, sent_at)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('sequences') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        name varchar(190) NOT NULL,
        active tinyint(1) NOT NULL DEFAULT 1,
        steps longtext NULL,
        created datetime NOT NULL,
        PRIMARY KEY  (id)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('enrollments') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        contact_id bigint(20) unsigned NOT NULL,
        sequence_id bigint(20) unsigned NOT NULL,
        current_step int(11) NOT NULL DEFAULT 0,
        thread_message_id varchar(255) NOT NULL DEFAULT '',
        thread_subject varchar(255) NOT NULL DEFAULT '',
        next_run datetime NULL,
        status varchar(30) NOT NULL DEFAULT 'active',
        created datetime NOT NULL,
        updated datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY contact_id (contact_id),
        KEY status_next (status, next_run)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('events') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
        email_id bigint(20) unsigned NOT NULL DEFAULT 0,
        type varchar(30) NOT NULL,
        meta text NULL,
        created datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY contact_id (contact_id),
        KEY type_created (type, created)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('visits') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        visitor_id varchar(40) NOT NULL DEFAULT '',
        session_id varchar(40) NOT NULL DEFAULT '',
        contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
        path varchar(255) NOT NULL DEFAULT '',
        title varchar(255) NOT NULL DEFAULT '',
        referrer varchar(255) NOT NULL DEFAULT '',
        ref_host varchar(120) NOT NULL DEFAULT '',
        utm_source varchar(100) NOT NULL DEFAULT '',
        utm_medium varchar(100) NOT NULL DEFAULT '',
        utm_campaign varchar(100) NOT NULL DEFAULT '',
        device varchar(20) NOT NULL DEFAULT '',
        browser varchar(40) NOT NULL DEFAULT '',
        country varchar(8) NOT NULL DEFAULT '',
        ip_hash varchar(64) NOT NULL DEFAULT '',
        duration int(11) NOT NULL DEFAULT 0,
        max_scroll int(11) NOT NULL DEFAULT 0,
        clicked_cta tinyint(1) NOT NULL DEFAULT 0,
        created datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY visitor_id (visitor_id),
        KEY contact_id (contact_id),
        KEY created (created),
        KEY session_id (session_id)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('social') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        platform varchar(20) NOT NULL,
        day date NOT NULL,
        metrics longtext NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY platform_day (platform, day)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('posts') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        platform varchar(20) NOT NULL,
        post_id varchar(80) NOT NULL,
        posted_at datetime NULL,
        text longtext NULL,
        permalink varchar(255) NOT NULL DEFAULT '',
        thumb varchar(500) NOT NULL DEFAULT '',
        media_type varchar(40) NOT NULL DEFAULT '',
        views int(11) NOT NULL DEFAULT 0,
        likes int(11) NOT NULL DEFAULT 0,
        replies int(11) NOT NULL DEFAULT 0,
        reposts int(11) NOT NULL DEFAULT 0,
        shares int(11) NOT NULL DEFAULT 0,
        updated datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY platform_post (platform, post_id)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('ai') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        thread varchar(40) NOT NULL DEFAULT 'main',
        role varchar(20) NOT NULL,
        content longtext NULL,
        created datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY thread (thread)
    ) $cs;");

    dbDelta("CREATE TABLE " . fwcrm_t('tasks') . " (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        contact_id bigint(20) unsigned NOT NULL DEFAULT 0,
        type varchar(20) NOT NULL DEFAULT 'todo',
        title varchar(255) NOT NULL DEFAULT '',
        due datetime NULL,
        done tinyint(1) NOT NULL DEFAULT 0,
        done_at datetime NULL,
        email_id bigint(20) unsigned NOT NULL DEFAULT 0,
        alerted tinyint(1) NOT NULL DEFAULT 0,
        created datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY contact_id (contact_id),
        KEY done_due (done, due)
    ) $cs;");

    update_option('fwcrm_db_version', FWCRM_DB_VERSION);
}

function fwcrm_seed_defaults() {
    global $wpdb;
    $n = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . fwcrm_t('sequences'));
    if ($n > 0) return;
    $steps = array(
        array('delay_days' => 3, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\nJust bumping this up in case it got buried. I'd love to show you what a faster, cleaner store could do for {{company|your brand}}.\n\nWould a quick 15-minute call this week work?"),
        array('delay_days' => 4, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\nQuick one: most stores I build go live in 7–10 days and are built mobile-first, so they start selling from day one. You can see recent work here: https://felixeweb.com/#work\n\nWorth a chat?"),
        array('delay_days' => 7, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\nI don't want to crowd your inbox, so this is my last note. If a new or faster store is ever on the list for {{company|your brand}}, just reply here and I'll pick it up.\n\nWishing you a great week."),
    );
    $cold = array(
        array('delay_days' => 0, 'subject' => 'Quick idea for {{company|your store}}', 'body' => "Hi {{first_name|there}},\n\nI came across {{company|your brand}} and had a quick idea to help the site turn more visitors into orders: a faster, mobile-first store with a cleaner checkout.\n\nI design and launch WordPress & WooCommerce stores in 7–10 days. Recent work: https://felixeweb.com/#work\n\nOpen to a quick 15-minute call this week?"),
        array('delay_days' => 3, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\nJust floating this back to the top of your inbox. Happy to share 2–3 quick wins for {{company|your site}} on a short call, no strings attached."),
        array('delay_days' => 5, 'subject' => '', 'body' => "Hi {{first_name|there}},\n\nLast note from me. If a faster store is on your list this year, just reply \"yes\" and I'll send over a few ideas.\n\nAll the best."),
    );
    $wpdb->insert(fwcrm_t('sequences'), array(
        'name' => 'Cold outreach + 2 follow-ups (new leads)',
        'active' => 1,
        'steps' => wp_json_encode($cold),
        'created' => fwcrm_now(),
    ));
    $wpdb->insert(fwcrm_t('sequences'), array(
        'name' => 'Scouting follow-up (3 touches)',
        'active' => 1,
        'steps' => wp_json_encode($steps),
        'created' => fwcrm_now(),
    ));
}

/* ---------- Contacts ---------- */

function fwcrm_get_contact($id) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('contacts') . " WHERE id = %d", $id));
}

function fwcrm_get_contact_by_email($email) {
    global $wpdb;
    $email = fwcrm_clean_email($email);
    if (!$email) return null;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('contacts') . " WHERE email = %s", $email));
}

function fwcrm_get_contact_by_token($token) {
    global $wpdb;
    if (!$token) return null;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('contacts') . " WHERE token = %s", $token));
}

/** Create or update a contact by email. Only fills empty fields unless $overwrite. */
function fwcrm_upsert_contact($data, $overwrite = false) {
    global $wpdb;
    $email = fwcrm_clean_email(isset($data['email']) ? $data['email'] : '');
    if (!$email) return 0;
    $fields = array('first_name', 'last_name', 'company', 'website', 'phone', 'niche', 'country', 'platform', 'problems', 'socials', 'source', 'tags', 'notes');
    $existing = fwcrm_get_contact_by_email($email);
    if ($existing) {
        $upd = array();
        foreach ($fields as $f) {
            if (!isset($data[$f]) || $data[$f] === '') continue;
            if ($overwrite || (string) $existing->$f === '' || ($f === 'source' && $existing->source === 'manual' && false)) {
                $upd[$f] = in_array($f, array('notes', 'problems', 'socials'), true) ? sanitize_textarea_field($data[$f]) : sanitize_text_field($data[$f]);
            }
        }
        if (isset($data['stage']) && $data['stage']) {
            if ($overwrite || fwcrm_stage_rank($data['stage']) > fwcrm_stage_rank($existing->stage)) $upd['stage'] = $data['stage'];
        }
        if ($upd) {
            $upd['updated'] = fwcrm_now();
            $wpdb->update(fwcrm_t('contacts'), $upd, array('id' => $existing->id));
        }
        return (int) $existing->id;
    }
    $row = array('email' => $email, 'token' => fwcrm_token(16), 'created' => fwcrm_now(), 'updated' => fwcrm_now(), 'stage' => 'new', 'source' => 'manual');
    foreach ($fields as $f) {
        if (isset($data[$f])) $row[$f] = in_array($f, array('notes', 'problems', 'socials'), true) ? sanitize_textarea_field($data[$f]) : sanitize_text_field($data[$f]);
    }
    if (!empty($data['stage']) && isset(fwcrm_stages()[$data['stage']])) $row['stage'] = $data['stage'];
    if (empty($row['company']) || empty($row['website'])) {
        $domain = substr(strrchr($email, '@'), 1);
        if (!fwcrm_is_free_domain($domain)) {
            if (empty($row['website'])) $row['website'] = 'https://' . $domain;
            if (empty($row['company'])) $row['company'] = ucwords(str_replace(array('-', '_'), ' ', preg_replace('/\.[a-z.]+$/', '', $domain)));
        }
    }
    $wpdb->insert(fwcrm_t('contacts'), $row);
    $id = (int) $wpdb->insert_id;
    if ($id) fwcrm_event($id, 'created', array('source' => $row['source']));
    return $id;
}

function fwcrm_is_free_domain($d) {
    return in_array(strtolower($d), array('gmail.com', 'googlemail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'live.com', 'icloud.com', 'me.com', 'aol.com', 'proton.me', 'protonmail.com', 'gmx.com', 'mail.com', 'yandex.com', 'zoho.com', 'msn.com', 'ymail.com'), true);
}

function fwcrm_update_contact($id, $data) {
    global $wpdb;
    $data['updated'] = fwcrm_now();
    if (isset($data['stage'])) {
        if ($data['stage'] === 'won') {
            if (!$wpdb->get_var($wpdb->prepare("SELECT won_at FROM " . fwcrm_t('contacts') . " WHERE id = %d", $id))) $data['won_at'] = fwcrm_now();
        } else {
            $data['won_at'] = null;
        }
    }
    return $wpdb->update(fwcrm_t('contacts'), $data, array('id' => (int) $id));
}

/** Move stage forward automatically (never backwards, never out of won/lost). */
function fwcrm_bump_stage($id, $stage) {
    $c = fwcrm_get_contact($id);
    if (!$c) return;
    if (in_array($c->stage, array('won', 'lost'), true)) return;
    if (fwcrm_stage_rank($stage) > fwcrm_stage_rank($c->stage)) {
        fwcrm_update_contact($id, array('stage' => $stage));
        fwcrm_event($id, 'stage', array('from' => $c->stage, 'to' => $stage, 'auto' => 1));
    }
}

function fwcrm_add_score($id, $pts) {
    global $wpdb;
    $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('contacts') . " SET score = score + %d WHERE id = %d", $pts, $id));
}

function fwcrm_event($contact_id, $type, $meta = array(), $email_id = 0) {
    global $wpdb;
    $wpdb->insert(fwcrm_t('events'), array(
        'contact_id' => (int) $contact_id,
        'email_id' => (int) $email_id,
        'type' => $type,
        'meta' => $meta ? wp_json_encode($meta) : '',
        'created' => fwcrm_now(),
    ));
}

/* ---------- Sequences ---------- */

function fwcrm_get_sequences($active_only = false) {
    global $wpdb;
    $sql = "SELECT * FROM " . fwcrm_t('sequences') . ($active_only ? " WHERE active = 1" : "") . " ORDER BY id ASC";
    $rows = $wpdb->get_results($sql);
    foreach ($rows as $r) {
        $r->steps_arr = json_decode($r->steps, true) ?: array();
    }
    return $rows;
}

function fwcrm_get_sequence($id) {
    global $wpdb;
    $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('sequences') . " WHERE id = %d", $id));
    if ($r) $r->steps_arr = json_decode($r->steps, true) ?: array();
    return $r;
}

/** Enroll a contact. If they already have a CRM/webmail email, follow-ups thread under it. */
function fwcrm_enroll($contact_id, $sequence_id, $start_now = false) {
    global $wpdb;
    $seq = fwcrm_get_sequence($sequence_id);
    $c = fwcrm_get_contact($contact_id);
    if (!$seq || !$c || $c->unsubscribed || $c->bounced) return false;
    $active = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . fwcrm_t('enrollments') . " WHERE contact_id = %d AND status = 'active'", $contact_id));
    if ($active) return false;

    $last_out = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . fwcrm_t('emails') . " WHERE contact_id = %d AND direction = 'out' AND status = 'sent' ORDER BY sent_at DESC LIMIT 1", $contact_id));
    $base = $last_out ? strtotime($last_out->sent_at) : current_time('timestamp');
    $delay = isset($seq->steps_arr[0]['delay_days']) ? (float) $seq->steps_arr[0]['delay_days'] : 0;
    $next = $start_now ? current_time('timestamp') : $base + (int) round($delay * DAY_IN_SECONDS);
    if ($next < current_time('timestamp')) $next = current_time('timestamp');

    $wpdb->insert(fwcrm_t('enrollments'), array(
        'contact_id' => $contact_id,
        'sequence_id' => $sequence_id,
        'current_step' => 0,
        'thread_message_id' => $last_out ? $last_out->message_id : '',
        'thread_subject' => $last_out ? $last_out->subject : '',
        'next_run' => date('Y-m-d H:i:s', $next),
        'status' => 'active',
        'created' => fwcrm_now(),
        'updated' => fwcrm_now(),
    ));
    fwcrm_update_contact($contact_id, array('next_followup' => date('Y-m-d H:i:s', $next)));
    fwcrm_event($contact_id, 'enrolled', array('sequence' => $seq->name));
    return true;
}

function fwcrm_stop_enrollments($contact_id, $reason) {
    global $wpdb;
    $n = $wpdb->query($wpdb->prepare("UPDATE " . fwcrm_t('enrollments') . " SET status = %s, updated = %s WHERE contact_id = %d AND status = 'active'", $reason, fwcrm_now(), $contact_id));
    if ($n) {
        fwcrm_update_contact($contact_id, array('next_followup' => null));
        fwcrm_event($contact_id, 'sequence_stopped', array('reason' => $reason));
    }
    return $n;
}
