<?php
/** Branded FelixeWeb blog template (list, category, tag and single post). */
if (!defined('ABSPATH')) exit;
$cal = 'https://calendar.app.google/zokGimp6miS6uLni7';
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400&display=swap" rel="stylesheet">
<style><?php echo fwcrm_site_part('site.css'); ?>
body{margin:0;background:#0A0A0A}
</style>
</head>
<body <?php body_class('fw-blog'); ?>>
<?php wp_body_open(); ?>
<div class="elementor-widget-html">
<?php echo fwcrm_site_part('header.html'); ?>
<main id="home">
<?php if (is_singular('post')) : while (have_posts()) : the_post();
    $post = get_post();
    $cats = get_the_category();
    $felix = '';
    $admins = get_users(array('role' => 'administrator', 'number' => 1));
    if ($admins && function_exists('fwcrm_member_photo')) $felix = fwcrm_member_photo($admins[0]->ID, 'thumbnail');
?>
<article>
 <header class="post-head">
  <div class="glow"></div>
  <div class="wrap">
   <div class="crumbs rv"><a href="/">Home</a><i>/</i><a href="/blog/">Blog</a><?php if ($cats) : ?><i>/</i><a href="<?php echo esc_url(get_category_link($cats[0])); ?>"><?php echo esc_html($cats[0]->name); ?></a><?php endif; ?></div>
   <h1 class="rv d1"><?php the_title(); ?></h1>
   <div class="meta rv d2">
    <span class="by"><?php if ($felix) : ?><img src="<?php echo esc_url($felix); ?>" alt=""><?php endif; ?>By Felix, founder of FelixeWeb</span>
    <span><?php echo esc_html(get_the_date('j M Y')); ?></span>
    <span><?php echo fwcrm_reading_time($post->post_content); ?> min read</span>
   </div>
  </div>
 </header>
 <?php if (has_post_thumbnail()) : ?><div class="post-feat rv"><?php the_post_thumbnail('full'); ?></div><?php endif; ?>
 <div class="prose"><?php the_content(); ?></div>
 <div class="post-cta rv"><div class="in">
  <h3>Want this done <em style="color:var(--gold);font-weight:300;font-style:italic">for you</em>?</h3>
  <p>FelixeWeb builds stores, apps and videos, and launches most stores in 7–10 days. Book a free 30-minute call and leave with a clear plan.</p>
  <div class="row"><a class="btn btn-gold mag" href="<?php echo esc_url($cal); ?>" target="_blank" rel="noopener">Book a free call <span class="arr">→</span></a><a class="btn btn-ghost mag" href="/services/">See services &amp; prices</a></div>
 </div></div>
 <div class="share">Share:
  <a href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode(get_permalink()); ?>&text=<?php echo rawurlencode(get_the_title()); ?>" target="_blank" rel="noopener">X</a>
  <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo rawurlencode(get_permalink()); ?>" target="_blank" rel="noopener">LinkedIn</a>
  <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode(get_permalink()); ?>" target="_blank" rel="noopener">Facebook</a>
  <a href="https://wa.me/?text=<?php echo rawurlencode(get_the_title() . ' ' . get_permalink()); ?>" target="_blank" rel="noopener">WhatsApp</a>
 </div>
 <?php
 $rel = get_posts(array('post_type' => 'post', 'numberposts' => 3, 'post__not_in' => array(get_the_ID()), 'category__in' => $cats ? array($cats[0]->term_id) : array()));
 if (count($rel) < 3) $rel = array_merge($rel, get_posts(array('post_type' => 'post', 'numberposts' => 3 - count($rel), 'post__not_in' => array_merge(array(get_the_ID()), wp_list_pluck($rel, 'ID')))));
 if ($rel) : ?>
 <section style="padding-top:0"><div class="wrap">
  <div class="sec-head"><div><div class="label rv">Keep reading</div><h2 class="rv d1">More from the <em>blog</em>.</h2></div></div>
  <div class="post-grid"><?php foreach ($rel as $r) echo fwcrm_post_card($r); ?></div>
 </div></section>
 <?php endif; ?>
</article>
<?php endwhile; else :
    $paged = max(1, (int) get_query_var('paged'), (int) get_query_var('page'));
    $is_list_page = is_page(fwcrm_blog_page_id()) || is_home();
    if ($is_list_page) {
        $q = new WP_Query(array('post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 10, 'paged' => $paged));
    } else {
        global $wp_query; $q = $wp_query;
    }
    $term = (is_category() || is_tag()) ? get_queried_object() : null;
    $cats = get_categories(array('hide_empty' => true));
?>
<section class="phero solo">
 <div class="glow"></div>
 <div class="bigword" aria-hidden="true">BLOG</div>
 <div class="wrap phero-grid"><div>
  <div class="crumbs rv"><a href="/">Home</a><i>/</i><?php echo $term ? '<a href="/blog/">Blog</a><i>/</i>' . esc_html($term->name) : 'Blog'; ?></div>
  <h1 class="rv d1"><?php echo $term ? esc_html($term->name) : 'Ideas to help you <em>sell</em> online.'; ?></h1>
  <p class="lead rv d2"><?php echo $term && $term->description ? esc_html($term->description) : 'Practical guides on WordPress and WooCommerce stores, research peptide websites, video, publishing and automation, from the FelixeWeb team.'; ?></p>
 </div></div>
</section>
<section style="padding-top:clamp(50px,6vw,80px)"><div class="wrap">
 <?php if ($cats) : ?><div class="cats rv"><a href="/blog/" class="<?php echo $term ? '' : 'on'; ?>">All</a><?php foreach ($cats as $c) { if ($c->slug === 'uncategorized') continue; echo '<a class="' . ($term && $term->term_id === $c->term_id ? 'on' : '') . '" href="' . esc_url(get_category_link($c)) . '">' . esc_html($c->name) . '</a>'; } ?></div><?php endif; ?>
 <?php if ($q->have_posts()) : ?>
  <div class="post-grid"><?php $i = 0; foreach ($q->posts as $p) { echo fwcrm_post_card($p, $i === 0 && $paged === 1 && !$term); $i++; } ?></div>
  <?php if ($q->max_num_pages > 1) {
      $base = $term ? get_term_link($term) : home_url('/blog/');
      echo '<nav class="pager">';
      for ($n = 1; $n <= $q->max_num_pages; $n++) echo $n === $paged ? '<span class="cur">' . $n . '</span>' : '<a href="' . esc_url($n === 1 ? $base : trailingslashit($base) . 'page/' . $n . '/') . '">' . $n . '</a>';
      echo '</nav>';
  } ?>
 <?php else : ?>
  <div style="text-align:center;padding:60px 0;color:var(--muted)">The first posts are on their way. In the meantime, <a href="/services/" style="color:var(--gold)">see what we do</a>.</div>
 <?php endif; ?>
</div></section>
<?php endif; ?>
</main>
<?php echo fwcrm_site_part('footer.html'); ?>
</div>
<?php echo fwcrm_site_part('site.js'); ?>
<?php wp_footer(); ?>
</body>
</html>
