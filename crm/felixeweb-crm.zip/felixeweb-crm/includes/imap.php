<?php
if (!defined('ABSPATH')) exit;

/**
 * Minimal IMAP client over TLS sockets (no php-imap extension required).
 * Supports: LOGIN, LIST, SELECT, UID SEARCH, UID FETCH (headers + partial body), APPEND, LOGOUT.
 */
class FWCRM_IMAP {
    private $fp;
    private $tag = 0;
    public $error = '';

    public function connect($host, $port, $user, $pass, $timeout = 20) {
        $verify = !(defined('FWCRM_INSECURE_TLS') && FWCRM_INSECURE_TLS);
        $ctx = stream_context_create(array('ssl' => array('verify_peer' => $verify, 'verify_peer_name' => $verify, 'allow_self_signed' => !$verify, 'SNI_enabled' => true)));
        $this->fp = @stream_socket_client('ssl://' . $host . ':' . (int) $port, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $ctx);
        if (!$this->fp) {
            $this->error = "Could not reach $host:$port ($errstr)";
            return false;
        }
        stream_set_timeout($this->fp, $timeout);
        $greet = fgets($this->fp);
        if (strpos((string) $greet, '* OK') !== 0) {
            $this->error = 'Unexpected greeting: ' . trim((string) $greet);
            return false;
        }
        $r = $this->cmd('LOGIN ' . $this->q($user) . ' ' . $this->q($pass));
        if (!$r['ok']) {
            $this->error = 'Login failed: ' . $r['status'];
            return false;
        }
        return true;
    }

    public function q($s) {
        return '"' . str_replace(array('\\', '"'), array('\\\\', '\\"'), $s) . '"';
    }

    /** Send a command; returns ['ok'=>bool,'status'=>string,'lines'=>[], 'literals'=>[]] */
    public function cmd($command, $literal_payload = null) {
        if (!$this->fp) return array('ok' => false, 'status' => 'not connected', 'lines' => array(), 'items' => array());
        $tag = 'A' . (++$this->tag);
        fwrite($this->fp, $tag . ' ' . $command . "\r\n");
        if ($literal_payload !== null) {
            $cont = fgets($this->fp);
            if (strpos((string) $cont, '+') !== 0) {
                return array('ok' => false, 'status' => trim((string) $cont), 'lines' => array(), 'items' => array());
            }
            fwrite($this->fp, $literal_payload . "\r\n");
        }
        $lines = array();
        $items = array();   // each untagged response with its literals assembled
        $current = null;
        while (true) {
            $line = fgets($this->fp);
            if ($line === false) {
                return array('ok' => false, 'status' => 'connection lost', 'lines' => $lines, 'items' => $items);
            }
            if (strpos($line, $tag . ' ') === 0) {
                if ($current !== null) $items[] = $current;
                $status = trim(substr($line, strlen($tag) + 1));
                return array('ok' => stripos($status, 'OK') === 0, 'status' => $status, 'lines' => $lines, 'items' => $items);
            }
            if ($line[0] === '*') {
                if ($current !== null) $items[] = $current;
                $current = array('text' => $line, 'literals' => array());
            } elseif ($current !== null) {
                $current['text'] .= $line;
            }
            $lines[] = $line;
            // Literal: line ends with {n}
            while (preg_match('/\{(\d+)\}\r\n$/', $line, $m)) {
                $len = (int) $m[1];
                $data = '';
                while (strlen($data) < $len) {
                    $chunk = fread($this->fp, $len - strlen($data));
                    if ($chunk === false || $chunk === '') break;
                    $data .= $chunk;
                }
                if ($current !== null) $current['literals'][] = $data;
                $line = fgets($this->fp);
                if ($line === false) break;
                if ($current !== null) $current['text'] .= $line;
            }
        }
    }

    /** Returns list of ['name'=>..., 'flags'=>...] */
    public function list_folders() {
        $r = $this->cmd('LIST "" "*"');
        $out = array();
        foreach ($r['items'] as $it) {
            if (preg_match('/^\* LIST \(([^)]*)\) (?:"[^"]*"|NIL) (.+)$/s', trim($it['text']), $m)) {
                $name = trim($m[2]);
                if (!empty($it['literals'])) $name = $it['literals'][0];
                $name = trim($name, '"');
                $out[] = array('name' => $name, 'flags' => strtolower($m[1]));
            }
        }
        return $out;
    }

    public function find_sent_folder() {
        $folders = $this->list_folders();
        foreach ($folders as $f) if (strpos($f['flags'], '\\sent') !== false) return $f['name'];
        foreach (array('INBOX.Sent', 'Sent', 'Sent Items', 'Sent Messages', 'INBOX.Sent Messages', 'INBOX.Sent Items') as $guess) {
            foreach ($folders as $f) if (strcasecmp($f['name'], $guess) === 0) return $f['name'];
        }
        return '';
    }

    /** Select folder; returns ['uidvalidity'=>int,'uidnext'=>int,'exists'=>int] or false */
    public function select($folder) {
        $r = $this->cmd('SELECT ' . $this->q($folder));
        if (!$r['ok']) {
            $this->error = 'Cannot open folder ' . $folder . ': ' . $r['status'];
            return false;
        }
        $info = array('uidvalidity' => 0, 'uidnext' => 0, 'exists' => 0);
        foreach ($r['lines'] as $l) {
            if (preg_match('/UIDVALIDITY (\d+)/', $l, $m)) $info['uidvalidity'] = (int) $m[1];
            if (preg_match('/UIDNEXT (\d+)/', $l, $m)) $info['uidnext'] = (int) $m[1];
            if (preg_match('/^\* (\d+) EXISTS/', $l, $m)) $info['exists'] = (int) $m[1];
        }
        return $info;
    }

    /** UIDs greater than $after, or since date (d-M-Y) when $after = 0 */
    public function search_uids($after, $since_ts = null) {
        if ($after > 0) {
            $r = $this->cmd('UID SEARCH UID ' . ($after + 1) . ':*');
        } else {
            $r = $this->cmd('UID SEARCH SINCE ' . date('d-M-Y', $since_ts ? $since_ts : time() - 30 * DAY_IN_SECONDS));
        }
        $uids = array();
        foreach ($r['lines'] as $l) {
            if (strpos($l, '* SEARCH') === 0) {
                foreach (preg_split('/\s+/', trim(substr($l, 8))) as $u) {
                    if (ctype_digit($u) && (int) $u > $after) $uids[] = (int) $u;
                }
            }
        }
        sort($uids);
        return $uids;
    }

    /** Fetch headers + first ~8KB of body for a set of UIDs. Returns [uid => ['header'=>raw,'body'=>raw]] */
    public function fetch_messages($uids) {
        $out = array();
        if (!$uids) return $out;
        foreach (array_chunk($uids, 25) as $chunk) {
            $r = $this->cmd('UID FETCH ' . implode(',', $chunk) . ' (UID BODY.PEEK[HEADER] BODY.PEEK[TEXT]<0.8000>)');
            foreach ($r['items'] as $it) {
                if (!preg_match('/UID (\d+)/', $it['text'], $m)) continue;
                $uid = (int) $m[1];
                $header = isset($it['literals'][0]) ? $it['literals'][0] : '';
                $body = isset($it['literals'][1]) ? $it['literals'][1] : '';
                $out[$uid] = array('header' => $header, 'body' => $body);
            }
        }
        return $out;
    }

    /** Full raw body of one message (for long hub-sync emails). */
    public function fetch_full($uid) {
        $r = $this->cmd('UID FETCH ' . (int) $uid . ' (UID BODY.PEEK[TEXT])');
        foreach ($r['items'] as $it) if (isset($it['literals'][0])) return $it['literals'][0];
        return '';
    }

    public function append($folder, $raw_message, $flags = '(\\Seen)') {
        $raw_message = preg_replace("/(?<!\r)\n/", "\r\n", $raw_message);
        $r = $this->cmd('APPEND ' . $this->q($folder) . ' ' . $flags . ' {' . strlen($raw_message) . '}', $raw_message);
        return $r['ok'];
    }

    public function logout() {
        if ($this->fp) {
            @fwrite($this->fp, 'Z LOGOUT' . "\r\n");
            @fclose($this->fp);
            $this->fp = null;
        }
    }
}

/* ---------- MIME helpers ---------- */

function fwcrm_parse_headers($raw) {
    $raw = preg_replace("/\r\n[ \t]+/", ' ', $raw);
    $h = array();
    foreach (preg_split("/\r?\n/", $raw) as $line) {
        if (!preg_match('/^([A-Za-z0-9\-]+):\s*(.*)$/', $line, $m)) continue;
        $k = strtolower($m[1]);
        if (!isset($h[$k])) $h[$k] = $m[2];
    }
    return $h;
}

function fwcrm_decode_header($s) {
    if ($s === '' || strpos($s, '=?') === false) return $s;
    if (function_exists('iconv_mime_decode')) {
        $d = @iconv_mime_decode($s, ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
        if ($d !== false) return $d;
    }
    if (function_exists('mb_decode_mimeheader')) return mb_decode_mimeheader($s);
    return $s;
}

/** Extract all email addresses from a header value. */
function fwcrm_addresses($value) {
    preg_match_all('/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/', (string) $value, $m);
    return array_values(array_unique(array_map('strtolower', $m[0])));
}

function fwcrm_display_name($from) {
    $from = fwcrm_decode_header($from);
    if (preg_match('/^\s*"?([^"<]+?)"?\s*</', $from, $m)) return trim($m[1]);
    return '';
}

/** Turn a (possibly multipart, partial) body into readable plain text. */
function fwcrm_body_text($headers, $body, $clean = true) {
    $ct = isset($headers['content-type']) ? $headers['content-type'] : 'text/plain';
    $cte = isset($headers['content-transfer-encoding']) ? strtolower(trim($headers['content-transfer-encoding'])) : '';
    if (stripos($ct, 'multipart/') !== false && preg_match('/boundary="?([^";]+)"?/i', $ct, $m)) {
        $parts = explode('--' . $m[1], $body);
        $html = '';
        foreach ($parts as $p) {
            $split = preg_split("/\r?\n\r?\n/", $p, 2);
            if (count($split) < 2) continue;
            $ph = fwcrm_parse_headers($split[0]);
            $pct = isset($ph['content-type']) ? $ph['content-type'] : 'text/plain';
            if (stripos($pct, 'multipart/') !== false) {
                $t = fwcrm_body_text($ph, $split[1], $clean);
                if ($t !== '') return $t;
                continue;
            }
            $decoded = fwcrm_decode_part($split[1], isset($ph['content-transfer-encoding']) ? strtolower(trim($ph['content-transfer-encoding'])) : '');
            if (stripos($pct, 'text/plain') !== false) return $clean ? fwcrm_clean_text($decoded) : $decoded;
            if (stripos($pct, 'text/html') !== false && $html === '') $html = $decoded;
        }
        return $html !== '' ? fwcrm_clean_text(wp_strip_all_tags(str_ireplace(array('<br>', '<br/>', '<br />', '</p>', '</div>'), "\n", $html))) : '';
    }
    $decoded = fwcrm_decode_part($body, $cte);
    if (stripos($ct, 'text/html') !== false) {
        $decoded = wp_strip_all_tags(str_ireplace(array('<br>', '<br/>', '<br />', '</p>', '</div>'), "\n", $decoded));
    }
    return $clean ? fwcrm_clean_text($decoded) : $decoded;
}

function fwcrm_decode_part($s, $enc) {
    if ($enc === 'base64') return (string) base64_decode(preg_replace('/[^A-Za-z0-9+\/=]/', '', $s));
    if ($enc === 'quoted-printable') return quoted_printable_decode($s);
    return $s;
}

/** Remove quoted history so we keep just the new reply text. */
function fwcrm_clean_text($t) {
    if (!mb_check_encoding($t, 'UTF-8')) $t = mb_convert_encoding($t, 'UTF-8', 'ISO-8859-1');
    $t = str_replace("\r", '', $t);
    $cut_markers = array('/^On .{5,200}wrote:\s*$/mi', '/^-{2,}\s*Original Message\s*-{2,}/mi', '/^From: .+$/mi', '/^>.*$/m', '/^Le .{5,200}a écrit\s*:/mi', '/^El .{5,200}escribió:/mi', '/^Am .{5,200}schrieb .+:/mi',
        '/\s*On (Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*,?\s[^\n]{3,200}?\s?(\n[^\n]{0,120}?)?wrote:/i',
        '/\s*On \d{1,2}\s[A-Z][a-z]{2,8}\s\d{4}[^\n]{0,160}?(\n[^\n]{0,120}?)?wrote:/',
        '/\s*On [A-Z][a-z]{2,8}\s\d{1,2},\s\d{4}[^\n]{0,160}?(\n[^\n]{0,120}?)?wrote:/',
        '/^Sent from my (iPhone|iPad|Android|Samsung|phone)/mi', '/^Get Outlook for /mi');
    $pos = strlen($t);
    foreach ($cut_markers as $re) {
        if (preg_match($re, $t, $m, PREG_OFFSET_CAPTURE) && $m[0][1] > 0 && $m[0][1] < $pos) $pos = $m[0][1];
    }
    $t = substr($t, 0, $pos);
    $t = preg_replace("/\n{3,}/", "\n\n", $t);
    return trim(html_entity_decode($t, ENT_QUOTES, 'UTF-8'));
}
