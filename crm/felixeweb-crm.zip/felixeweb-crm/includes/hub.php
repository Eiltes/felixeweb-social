<?php
if (!defined('ABSPATH')) exit;

/**
 * Hub vs site mode.
 *  - hub  (crm.felixeweb.com): the full app. Optional: the subdomain's front page opens the app.
 *  - site (felixeweb.com): only the visitor tracker, which reports to the hub.
 */
function fwcrm_is_site_mode() {
    return fwcrm_opt('hub_mode') === 'site' && fwcrm_opt('remote_hub_url');
}

function fwcrm_hub_host() {
    return wp_parse_url(fwcrm_is_site_mode() ? fwcrm_opt('remote_hub_url') : home_url(), PHP_URL_HOST);
}

/** Where the front-end tracker sends visits. */
function fwcrm_track_endpoint() {
    if (fwcrm_is_site_mode()) return trailingslashit(fwcrm_opt('remote_hub_url')) . 'wp-json/fwcrm/v1/v';
    return rest_url('fwcrm/v1/v');
}

/* In app-frontpage mode the subdomain itself is the app: visitors see the login, admins land on the dashboard. */
add_action('template_redirect', function () {
    if (!fwcrm_opt('app_frontpage') || fwcrm_is_site_mode()) return;
    if (is_user_logged_in() && current_user_can('manage_options')) {
        wp_safe_redirect(fwcrm_admin_url('fwcrm'));
    } else {
        wp_safe_redirect(wp_login_url(fwcrm_admin_url('fwcrm')));
    }
    exit;
});

add_filter('login_redirect', function ($to, $requested, $user) {
    if (fwcrm_opt('app_frontpage') && !is_wp_error($user) && user_can($user, 'manage_options') && (empty($requested) || strpos($requested, 'wp-admin/') !== false && strpos($requested, 'page=fwcrm') === false)) {
        return fwcrm_admin_url('fwcrm');
    }
    return $to;
}, 10, 3);

/* Branded login screen (hub only). */
add_action('login_enqueue_scripts', function () {
    if (!fwcrm_opt('app_frontpage')) return;
    ?>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
body.login{background:radial-gradient(ellipse at 50% -10%,rgba(176,138,46,.25),transparent 55%),#0A0A0A;font-family:Montserrat,system-ui,sans-serif}
.login h1 a{background:none!important;text-indent:0!important;width:auto!important;height:auto!important;font-size:0!important;display:flex!important;justify-content:center;align-items:center;gap:12px}
.login h1 a{perspective:500px}


.login .fp-coin{position:relative;display:inline-block;width:52px;height:52px;flex:0 0 52px;transform-style:preserve-3d;animation:fpspin 4s cubic-bezier(.6,0,.4,1) infinite}
.login .fp-coin i,.login .fp-coin .cf{position:absolute;inset:0;border-radius:11px}
.login .fp-coin i{background:#7A5C1C}
.login .fp-coin i:nth-child(2){transform:translateZ(-1px)}.login .fp-coin i:nth-child(3){transform:translateZ(-2px)}.login .fp-coin i:nth-child(4){transform:translateZ(-3px)}.login .fp-coin i:nth-child(5){transform:translateZ(-4px)}.login .fp-coin i:nth-child(6){transform:translateZ(-4.5px)}
.login .fp-coin .cf{background:#B08A2E;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:19px;line-height:1;letter-spacing:-1px;color:#0A0A0A;transform:translateZ(1px);backface-visibility:hidden;-webkit-backface-visibility:hidden}
.login .fp-coin .cf span{color:#F3EEE4}
.login .fp-coin .cb{transform:rotateY(180deg) translateZ(5px)}
@keyframes fpspin{0%{transform:rotateY(0)}35%{transform:rotateY(360deg)}100%{transform:rotateY(360deg)}}
@media (prefers-reduced-motion:reduce){.login .fp-coin{animation:none}}

.login h1 a::after{content:"FELIXEWEB HUB";font-size:15px;font-weight:700;letter-spacing:6px;color:#F3EEE4}
.login form{background:#141414!important;border:1px solid #2a2722!important;border-radius:16px;box-shadow:0 30px 80px rgba(0,0,0,.6)!important}
.login label{color:#cfc8bb!important;font-weight:600}
.login input[type=text],.login input[type=password]{background:#0f0f0f!important;border:1px solid #2a2722!important;color:#F3EEE4!important;border-radius:10px!important}
.login input:focus{border-color:#B08A2E!important;box-shadow:0 0 0 3px rgba(176,138,46,.2)!important}
.wp-core-ui .button-primary{background:#B08A2E!important;border-color:#B08A2E!important;color:#0A0A0A!important;font-weight:700;border-radius:10px!important;padding:2px 22px!important}
.login #nav a,.login #backtoblog a,.login .privacy-policy-link{color:#8f887c!important}
.login #backtoblog,.language-switcher{display:none}
.login .message,.login .notice{background:#141414;color:#cfc8bb;border-left-color:#B08A2E}
</style>
    <?php
});
add_action('login_footer', function () {
    if (!fwcrm_opt('app_frontpage')) return;
    echo '<script>(function(){var a=document.querySelector(".login h1 a");if(!a)return;var c=document.createElement("span");c.className="fp-coin";c.setAttribute("aria-hidden","true");c.innerHTML="<i></i><i></i><i></i><i></i><i></i><i></i><b class=\\"cf\\">F<span>W</span></b><b class=\\"cf cb\\">F<span>W</span></b>";a.insertBefore(c,a.firstChild);})();</script>';
});
add_filter('login_headerurl', function ($u) { return fwcrm_opt('app_frontpage') ? home_url('/') : $u; });
add_filter('login_headertext', function ($t) { return fwcrm_opt('app_frontpage') ? 'FelixeWeb Hub' : $t; });

/* Full-screen app look on hub screens: hide the WordPress chrome. */
add_action('admin_head', function () {
    if (!fwcrm_is_crm_screen() || !fwcrm_opt('app_mode', 1)) return;
    echo '<style>body.fwcrm-screen #adminmenumain,body.fwcrm-screen #wpadminbar{display:none}body.fwcrm-screen #wpcontent,body.fwcrm-screen #wpfooter{margin-left:0!important}html.wp-toolbar{padding-top:0!important}body.fwcrm-screen .fw-top{top:0}.fw-app{margin:0 auto}</style>';
});

/* Visitor beacon from another domain (felixeweb.com → hub): allow CORS for listed origins. */
function fwcrm_allowed_origins() {
    $list = array_filter(array_map('trim', preg_split('/[\s,]+/', (string) fwcrm_opt('allowed_origins'))));
    $site = fwcrm_opt('website_url');
    if ($site) $list[] = untrailingslashit($site);
    $out = array();
    foreach ($list as $o) {
        $h = wp_parse_url($o, PHP_URL_HOST);
        if (!$h) continue;
        $out[] = 'https://' . $h;
        $out[] = 'https://' . (strpos($h, 'www.') === 0 ? substr($h, 4) : 'www.' . $h);
    }
    return array_unique($out);
}

add_filter('rest_pre_serve_request', function ($served, $result, $request) {
    if (strpos($request->get_route(), '/fwcrm/v1/v') !== 0) return $served;
    $origin = get_http_origin();
    if ($origin && in_array(untrailingslashit($origin), fwcrm_allowed_origins(), true)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Vary: Origin');
    }
    return $served;
}, 5, 3);

/* Site mode: hide the CRM menus on the marketing site, keep just Settings. */
add_action('admin_menu', function () {
    if (!fwcrm_is_site_mode()) return;
    foreach (array('fwcrm-contacts', 'fwcrm-pipeline', 'fwcrm-inbox', 'fwcrm-sequences', 'fwcrm-visitors', 'fwcrm-social', 'fwcrm-ai') as $slug) remove_submenu_page('fwcrm', $slug);
}, 99);
