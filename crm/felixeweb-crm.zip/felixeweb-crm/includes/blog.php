<?php
/**
 * Blog & affiliates:
 * - Drafts arrive by [FW-HUB] email ({"type":"blog_post", ...}) and wait for Felix's approval.
 * - Hub page "Blog" to preview, publish or bin drafts and manage affiliate links.
 * - /go/<slug> affiliate redirects with click counts; {{aff:slug}} tokens in posts.
 * - Branded black/gold templates for the blog list, categories and single posts.
 */
if (!defined('ABSPATH')) exit;

/* =========================================================
 * Setup
 * ======================================================= */

add_action('admin_init', function () {
    if (get_option('fwcrm_blog_version') === '1') return;
    $pid = (int) get_option('fwcrm_blog_page');
    if (!$pid || !get_post($pid)) {
        $ex = get_page_by_path('blog');
        $pid = $ex ? $ex->ID : wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Blog', 'post_name' => 'blog', 'post_content' => ''));
        update_option('fwcrm_blog_page', (int) $pid, false);
    }
    foreach (array('Web Design', 'WooCommerce', 'Peptide Stores', 'Video', 'Books & Publishing', 'AI & Automation', 'Hosting & Tools') as $c) {
        if (!term_exists($c, 'category')) wp_insert_term($c, 'category');
    }
    update_option('fwcrm_blog_version', '1', false);
});

function fwcrm_blog_page_id() { return (int) get_option('fwcrm_blog_page'); }

/* =========================================================
 * Affiliate links
 * ======================================================= */

function fwcrm_aff_links() { $l = get_option('fwcrm_aff_links', array()); return is_array($l) ? $l : array(); }

function fwcrm_aff_clicks($slug, $days = 30) {
    $c = get_option('fwcrm_aff_clicks', array());
    if (empty($c[$slug])) return 0;
    $n = 0; $from = date('Y-m-d', current_time('timestamp') - $days * DAY_IN_SECONDS);
    foreach ($c[$slug] as $d => $v) if ($d >= $from) $n += (int) $v;
    return $n;
}

add_action('init', function () {
    $path = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
    if (!$path || !preg_match('#^/go/([a-z0-9-]+)/?$#', $path, $m)) return;
    $links = fwcrm_aff_links();
    $slug = $m[1];
    if (empty($links[$slug]['url'])) { wp_safe_redirect(home_url('/blog/')); exit; }
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    if (!preg_match('/bot|crawl|spider|preview|facebookexternalhit|slurp/i', $ua)) {
        $c = get_option('fwcrm_aff_clicks', array());
        $d = date('Y-m-d', current_time('timestamp'));
        $c[$slug][$d] = (isset($c[$slug][$d]) ? (int) $c[$slug][$d] : 0) + 1;
        foreach ($c as $s => $days) { foreach ($days as $dd => $v) if ($dd < date('Y-m-d', current_time('timestamp') - 120 * DAY_IN_SECONDS)) unset($c[$s][$dd]); }
        update_option('fwcrm_aff_clicks', $c, false);
    }
    header('X-Robots-Tag: noindex, nofollow', true);
    wp_redirect(esc_url_raw($links[$slug]['url']), 302);
    exit;
}, 1);

/** {{aff:slug}} → /go/slug, affiliate links get rel="sponsored", and a disclosure box goes on top. */
function fwcrm_blog_filter_content($html) {
    $html = preg_replace_callback('/\{\{\s*aff:([a-z0-9-]+)\s*\}\}/i', function ($m) { return esc_url(home_url('/go/' . strtolower($m[1]) . '/')); }, $html);
    $has = false;
    $html = preg_replace_callback('/<a\s([^>]*href=["\'][^"\']*\/go\/[a-z0-9-]+\/?["\'][^>]*)>/i', function ($m) use (&$has) {
        $has = true;
        $a = preg_replace('/\s(rel|target)=["\'][^"\']*["\']/i', '', $m[1]);
        return '<a ' . $a . ' rel="sponsored nofollow noopener" target="_blank">';
    }, $html);
    if ($has && strpos($html, 'class="disclosure"') === false) {
        $html = '<p class="disclosure">Some links in this post are affiliate links. If you buy through them, FelixeWeb may earn a commission at no extra cost to you. We only recommend tools we use or would use on client sites.</p>' . $html;
    }
    return $html;
}
add_filter('the_content', function ($c) { return is_singular('post') ? fwcrm_blog_filter_content($c) : $c; }, 20);

/* =========================================================
 * Drafts from the writer ([FW-HUB] email with type blog_post)
 * ======================================================= */

function fwcrm_blog_import($p) {
    $title = sanitize_text_field(isset($p['title']) ? $p['title'] : '');
    $content = isset($p['content_html']) ? (string) $p['content_html'] : '';
    $content = preg_replace('/\{\{\s*aff:([a-z0-9-]+)\s*\}\}/i', '/go/$1/', $content);
    $content = preg_replace('/\{\{\s*aff:([a-z0-9-]+)\s*\}\}/i', '/go/$1/', $content);
    if ($title === '' || strlen(wp_strip_all_tags($content)) < 400) { fwcrm_log('Blog draft skipped: missing title or content'); return 0; }
    $slug = sanitize_title(isset($p['slug']) ? $p['slug'] : $title);
    $dupe = get_posts(array('name' => $slug, 'post_type' => 'post', 'post_status' => array('draft', 'publish', 'pending', 'future'), 'numberposts' => 1));
    if ($dupe) { fwcrm_log('Blog draft skipped (already exists): ' . $title); return (int) $dupe[0]->ID; }
    $cats = array();
    foreach ((array) (isset($p['categories']) ? $p['categories'] : array()) as $c) {
        $c = sanitize_text_field($c); if ($c === '') continue;
        $t = term_exists($c, 'category'); if (!$t) $t = wp_insert_term($c, 'category');
        if (!is_wp_error($t)) $cats[] = (int) (is_array($t) ? $t['term_id'] : $t);
    }
    $id = wp_insert_post(array(
        'post_type' => 'post', 'post_status' => 'draft', 'post_title' => $title, 'post_name' => $slug,
        'post_content' => wp_kses_post($content), 'post_excerpt' => sanitize_text_field(isset($p['excerpt']) ? $p['excerpt'] : ''),
        'post_category' => $cats, 'tags_input' => array_map('sanitize_text_field', (array) (isset($p['tags']) ? $p['tags'] : array())),
        'post_author' => (int) (get_users(array('role' => 'administrator', 'number' => 1, 'fields' => 'ID'))[0] ?? 1),
    ), true);
    if (is_wp_error($id)) { fwcrm_log('Blog draft failed: ' . $id->get_error_message()); return 0; }
    $desc = sanitize_text_field(isset($p['meta_description']) ? $p['meta_description'] : '');
    if ($desc) { update_post_meta($id, '_yoast_wpseo_metadesc', $desc); update_post_meta($id, '_fwcrm_meta_desc', $desc); }
    if (!empty($p['seo_title'])) update_post_meta($id, '_yoast_wpseo_title', sanitize_text_field($p['seo_title']));
    if (!empty($p['focus_keyword'])) update_post_meta($id, '_yoast_wpseo_focuskw', sanitize_text_field($p['focus_keyword']));
    update_post_meta($id, '_fwcrm_writer', 1);
    if (!empty($p['notes'])) update_post_meta($id, '_fwcrm_writer_notes', sanitize_textarea_field($p['notes']));
    $url = admin_url('admin.php?page=fwcrm-blog');
    if (function_exists('fwcrm_push')) fwcrm_push('📝 Blog draft ready: ' . $title, 'Preview it and tap Publish when you are happy.', $url, 'memo');
    if (function_exists('fwcrm_notify')) fwcrm_notify('Blog draft ready: ' . $title, array('A new blog post is waiting for your approval.', '', $title, $desc, '', 'Preview: ' . get_preview_post_link($id)), $url);
    fwcrm_log('Blog draft created: ' . $title);
    return (int) $id;
}

/* =========================================================
 * Hub page: Blog & affiliates
 * ======================================================= */

add_action('admin_menu', function () {
    add_submenu_page('fwcrm', 'Blog', 'Blog', 'manage_options', 'fwcrm-blog', 'fwcrm_page_blog');
}, 21);

function fwcrm_page_blog() {
    $drafts = get_posts(array('post_type' => 'post', 'post_status' => array('draft', 'pending'), 'numberposts' => 30, 'orderby' => 'date', 'order' => 'DESC'));
    $live = get_posts(array('post_type' => 'post', 'post_status' => array('publish', 'future'), 'numberposts' => 15));
    fwcrm_header('Blog', 'New posts arrive here as drafts three times a week. Read, then publish or bin.', '<a class="fw-btn" href="' . esc_url(home_url('/blog/')) . '" target="_blank">View blog ↗</a><a class="fw-btn gold" href="' . esc_url(admin_url('post-new.php')) . '">+ Write a post</a>');
    echo '<div class="fw-today"><section class="fw-tsec"><div class="fw-tsec-h"><h2>Waiting for you</h2><span class="fw-dim">' . count($drafts) . ' draft' . (count($drafts) === 1 ? '' : 's') . '</span></div>';
    if (!$drafts) echo '<div class="fw-tempty">No drafts right now. The writer adds one every Monday, Wednesday and Friday.</div>';
    foreach ($drafts as $p) {
        $words = str_word_count(wp_strip_all_tags($p->post_content));
        $cats = wp_get_post_categories($p->ID, array('fields' => 'names'));
        $aff = preg_match_all('#(?:\{\{\s*aff:|/go/)([a-z0-9-]+)#i', $p->post_content, $am) ? array_unique(array_map('strtolower', $am[1])) : array();
        $missing = array_diff($aff, array_keys(fwcrm_aff_links()));
        echo '<div class="fw-trow task"><span class="fw-ticon">📝</span><div class="fw-tmain"><b>' . esc_html($p->post_title) . '</b><p>' . esc_html(($cats ? implode(', ', $cats) . ' · ' : '') . number_format($words) . ' words · ' . fwcrm_time_ago($p->post_date)) . ($aff ? ' · affiliate: ' . esc_html(implode(', ', $aff)) : '') . '</p>';
        if ($missing) echo '<p style="color:var(--bad)">Add your link for: ' . esc_html(implode(', ', $missing)) . ' (below) before publishing, or those links go to the blog page.</p>';
        $notes = get_post_meta($p->ID, '_fwcrm_writer_notes', true);
        if ($notes) echo '<details class="fw-tnotes"><summary>Writer notes</summary><div>' . nl2br(esc_html($notes)) . '</div></details>';
        echo '</div><a class="fw-btn sm" href="' . esc_url(get_preview_post_link($p->ID)) . '" target="_blank">Preview</a><a class="fw-btn sm" href="' . esc_url(get_edit_post_link($p->ID)) . '">Edit</a>';
        echo fwcrm_post_form_open('fwcrm_blog_action', 'style="display:inline-flex;gap:6px"') . '<input type="hidden" name="id" value="' . (int) $p->ID . '"><button class="fw-btn sm gold" name="do" value="publish">Publish</button><button class="fw-btn sm ghost" name="do" value="trash" onclick="return confirm(\'Move this draft to the bin?\')">Bin</button></form></div>';
    }
    echo '</section><section class="fw-tsec"><div class="fw-tsec-h"><h2>Published</h2></div>';
    if (!$live) echo '<div class="fw-tempty">Nothing published yet.</div>';
    foreach ($live as $p) echo '<div class="fw-trow done"><span class="fw-ticon">✓</span><div class="fw-tmain"><b><a href="' . esc_url(get_permalink($p)) . '" target="_blank">' . esc_html($p->post_title) . '</a></b><p>' . esc_html(($p->post_status === 'future' ? 'scheduled ' : 'published ') . date_i18n('j M Y', strtotime($p->post_date))) . '</p></div><a class="fw-btn sm" href="' . esc_url(get_edit_post_link($p->ID)) . '">Edit</a></div>';
    echo '</section>';

    // Affiliate links
    $links = fwcrm_aff_links();
    echo '<section class="fw-tsec" style="grid-column:1/-1"><div class="fw-tsec-h"><h2>Affiliate links</h2><span class="fw-dim">clicks in the last 30 days</span></div>';
    echo '<p class="fw-dim" style="margin:0 18px 12px">Paste your referral link from each program. Posts use short links like <code>felixeweb.com/go/hostinger</code>, so you can change a link here once and every post updates.</p>';
    foreach ($links as $slug => $l) {
        echo '<div class="fw-trow"><span class="fw-ticon">🔗</span><div class="fw-tmain"><b>' . esc_html($l['name']) . ' <span class="fw-dim">/go/' . esc_html($slug) . '</span></b><p>' . esc_html(wp_html_excerpt($l['url'], 70, '…')) . '</p></div><span class="fw-dim" style="white-space:nowrap"><b>' . fwcrm_aff_clicks($slug) . '</b> clicks</span>';
        echo fwcrm_post_form_open('fwcrm_aff_save', 'style="display:inline"') . '<input type="hidden" name="slug" value="' . esc_attr($slug) . '"><button class="fw-btn sm ghost" name="delete" value="1" onclick="return confirm(\'Remove this link?\')">Remove</button></form></div>';
    }
    echo fwcrm_post_form_open('fwcrm_aff_save', 'class="fw-affform"');
    echo '<label class="fw-f"><span>Program</span><input name="name" placeholder="Hostinger" required></label><label class="fw-f"><span>Short name</span><input name="slug" placeholder="hostinger" pattern="[a-z0-9-]+" required></label><label class="fw-f"><span>Your referral link</span><input name="url" type="url" placeholder="https://…" required></label><button class="fw-btn gold">Save link</button></form>';
    echo '</section></div>';
    fwcrm_footer();
}

add_action('admin_post_fwcrm_blog_action', function () {
    fwcrm_guard('fwcrm_blog_action');
    $id = (int) $_POST['id'];
    $do = sanitize_key($_POST['do']);
    if (!get_post($id)) fwcrm_back('fwcrm-blog', array(), 'Post not found.', true);
    if ($do === 'publish') { wp_publish_post($id); fwcrm_back('fwcrm-blog', array(), 'Published: ' . get_the_title($id)); }
    if ($do === 'trash') { wp_trash_post($id); fwcrm_back('fwcrm-blog', array(), 'Draft moved to the bin.'); }
    fwcrm_back('fwcrm-blog');
});

add_action('admin_post_fwcrm_aff_save', function () {
    fwcrm_guard('fwcrm_aff_save');
    $links = fwcrm_aff_links();
    $slug = sanitize_title(wp_unslash($_POST['slug']));
    if (!empty($_POST['delete'])) { unset($links[$slug]); update_option('fwcrm_aff_links', $links, false); fwcrm_back('fwcrm-blog', array(), 'Link removed.'); }
    $url = esc_url_raw(trim(wp_unslash($_POST['url'])));
    if (!$slug || !$url || !preg_match('#^https://#', $url)) fwcrm_back('fwcrm-blog', array(), 'Enter a short name and an https:// link.', true);
    $links[$slug] = array('name' => sanitize_text_field(wp_unslash($_POST['name'])), 'url' => $url);
    update_option('fwcrm_aff_links', $links, false);
    fwcrm_back('fwcrm-blog', array(), 'Saved. Use {{aff:' . $slug . '}} in posts.');
});

/* =========================================================
 * Public templates (blog list, categories, single post)
 * ======================================================= */

add_filter('template_include', function ($t) {
    if (is_singular('post') || is_page(fwcrm_blog_page_id()) || is_category() || is_tag() || (is_home() && !is_front_page())) {
        return FWCRM_DIR . 'includes/blog-template.php';
    }
    return $t;
}, 99);

add_action('wp_head', function () {
    if (!is_singular('post') || defined('WPSEO_VERSION')) return;
    $d = get_post_meta(get_the_ID(), '_fwcrm_meta_desc', true);
    if ($d) echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
}, 2);

function fwcrm_site_part($f) {
    $p = FWCRM_DIR . 'assets/site/' . $f;
    return file_exists($p) ? file_get_contents($p) : '';
}

function fwcrm_reading_time($content) { return max(1, (int) round(str_word_count(wp_strip_all_tags($content)) / 230)); }

function fwcrm_post_card($p, $lead = false) {
    $cats = get_the_category($p->ID);
    $img = get_the_post_thumbnail_url($p->ID, 'large');
    $word = $cats ? strtoupper(preg_replace('/[^A-Za-z]/', '', strtok($cats[0]->name, ' &'))) : 'BLOG';
    return '<a class="pcard2' . ($lead ? ' lead' : '') . '" href="' . esc_url(get_permalink($p)) . '"><div class="pimg">' . ($img ? '<img src="' . esc_url($img) . '" alt="" loading="lazy">' : '<span class="pw">' . esc_html($word) . '</span>') . '</div><div class="pb">' . ($cats ? '<span class="pc">' . esc_html($cats[0]->name) . '</span>' : '') . '<h3>' . esc_html(get_the_title($p)) . '</h3><p>' . esc_html(wp_html_excerpt(get_the_excerpt($p), $lead ? 220 : 140, '…')) . '</p><div class="pm"><span>' . esc_html(get_the_date('j M Y', $p)) . '</span><span>' . fwcrm_reading_time($p->post_content) . ' min read</span></div></div></a>';
}
