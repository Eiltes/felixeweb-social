<?php
/**
 * FelixeWeb Hub — Security
 *
 * Locks down the site around the Hub: 2-step sign-in, brute-force lockout,
 * hidden usernames, closed XML-RPC, private chat files, security headers,
 * sign-in alerts and a Security page with a live checklist.
 */
if (!defined('ABSPATH')) exit;

define('FWCRM_SEC_VERSION', '1');

/* =========================================================
 * 1. Fewer doors and fingerprints
 * ======================================================= */

remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');
add_filter('xmlrpc_enabled', '__return_false');
add_filter('xmlrpc_methods', function () { return array(); });
add_filter('wp_is_application_passwords_available', '__return_false');
add_filter('wp_headers', function ($h) { unset($h['X-Pingback']); return $h; });
if (!defined('DISALLOW_FILE_EDIT')) define('DISALLOW_FILE_EDIT', true);

/* XML-RPC is a favourite brute-force door. Close it completely. */
add_action('init', function () {
    if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) { status_header(403); header('Content-Type: text/plain'); echo 'Disabled.'; exit; }
}, 0);

/* Usernames stay hidden: no public user API, no author pages, no users sitemap, no author in embeds. */
add_filter('rest_endpoints', function ($e) {
    if (current_user_can('list_users')) return $e;
    foreach (array_keys($e) as $route) if (strpos($route, '/wp/v2/users') === 0) unset($e[$route]);
    return $e;
});
add_action('init', function () {
    if (!is_admin() && isset($_GET['author']) && !current_user_can('list_users')) { wp_safe_redirect(home_url('/'), 301); exit; }
}, 1);
add_action('template_redirect', function () {
    if (is_author() && !current_user_can('list_users')) {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        nocache_headers();
        remove_action('template_redirect', 'redirect_canonical');
    }
}, 1);
add_filter('wp_sitemaps_add_provider', function ($p, $name) { return $name === 'users' ? false : $p; }, 10, 2);
add_filter('oembed_response_data', function ($d) { unset($d['author_name'], $d['author_url']); return $d; });
add_filter('author_link', function ($link) { return current_user_can('list_users') ? $link : home_url('/about/'); });

/* Security headers on every page, including wp-admin, login, Hub and portal. */
function fwcrm_sec_headers() {
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    if (is_ssl()) header('Strict-Transport-Security: max-age=15552000');
}
add_action('send_headers', 'fwcrm_sec_headers');
add_action('admin_init', 'fwcrm_sec_headers');
add_action('login_init', 'fwcrm_sec_headers');

/* =========================================================
 * 2. Brute-force lockout (every login form: /hub, /portal, wp-login)
 * ======================================================= */

function fwcrm_sec_keys($login = '') {
    $remote = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    $fwd = function_exists('fwcrm_client_ip') ? fwcrm_client_ip() : $remote;
    $k = array(
        'ip' => array('fwsec_ip_' . md5($remote . '|' . $fwd), 8, 15),   // one visitor: 8 tries / 15 min
        'net' => array('fwsec_net_' . md5($remote), 40, 15),            // one connection: 40 tries / 15 min (can't be dodged with fake headers)
    );
    if ($login !== '') $k['user'] = array('fwsec_u_' . md5(strtolower(trim($login))), 15, 30); // one account: 15 tries / 30 min
    return $k;
}

function fwcrm_sec_locked($login = '') {
    foreach (fwcrm_sec_keys($login) as $k) if ((int) get_transient($k[0]) >= $k[1]) return true;
    return false;
}

add_filter('authenticate', function ($user, $login) {
    if ($login === '' || $login === null) return $user;
    if (fwcrm_sec_locked((string) $login)) return new WP_Error('fw_locked', 'Too many sign-in attempts. Wait 15 minutes and try again.');
    if (is_wp_error($user) && array_intersect($user->get_error_codes(), array('invalid_username', 'invalid_email', 'incorrect_password'))) {
        return new WP_Error('fw_bad_login', 'That email or password isn’t right.'); // never reveal whether the account exists
    }
    return $user;
}, 99, 2);

add_action('wp_login_failed', function ($login) {
    foreach (fwcrm_sec_keys((string) $login) as $k) set_transient($k[0], (int) get_transient($k[0]) + 1, $k[2] * MINUTE_IN_SECONDS);
    $s = get_option('fwcrm_sec_blocked', array());
    $d = date('Y-m-d', current_time('timestamp'));
    $s[$d] = (isset($s[$d]) ? (int) $s[$d] : 0) + 1;
    $s = array_slice($s, -30, 30, true);
    update_option('fwcrm_sec_blocked', $s, false);
    if (isset($s[$d]) && $s[$d] === 50 && function_exists('fwcrm_push')) fwcrm_push('🛡️ 50 failed sign-ins today', 'Someone is trying passwords on your site. They are being blocked automatically.', admin_url('admin.php?page=fwcrm-security'), 'shield');
});

/* Old wp-login.php sends people to the branded /hub sign-in. Password reset and logout still work. */
add_action('login_init', function () {
    if (!fwcrm_sec_opt('hide_wp_login')) return;
    $a = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : 'login';
    if (in_array($a, array('logout', 'lostpassword', 'retrievepassword', 'rp', 'resetpass', 'postpass', 'confirm_admin_email', 'confirmaction', 'checkemail'), true)) return;
    if (!empty($_REQUEST['interim-login'])) return; // "session expired" popup inside wp-admin
    if (!empty($_GET['checkemail']) || !empty($_GET['password-reset'])) { wp_safe_redirect(home_url('/hub/?reset=1')); exit; }
    wp_safe_redirect(home_url('/hub/'));
    exit;
});
add_filter('login_url', function ($url, $redirect) {
    return fwcrm_sec_opt('hide_wp_login') ? home_url('/hub/') : $url;
}, 10, 2);

function fwcrm_sec_opt($k) {
    $o = get_option('fwcrm_security', array());
    $d = array('hide_wp_login' => 1, 'alerts' => 1);
    return isset($o[$k]) ? $o[$k] : (isset($d[$k]) ? $d[$k] : 0);
}

/* =========================================================
 * 3. 2-step sign-in (authenticator app codes)
 * ======================================================= */

function fwcrm_b32_encode($bin) {
    $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
    foreach (str_split($bin) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    foreach (str_split($bits, 5) as $chunk) $out .= $a[bindec(str_pad($chunk, 5, '0'))];
    return $out;
}
function fwcrm_b32_decode($s) {
    $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
    foreach (str_split(strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $s))) as $c) $bits .= str_pad(decbin(strpos($a, $c)), 5, '0', STR_PAD_LEFT);
    foreach (str_split($bits, 8) as $byte) if (strlen($byte) === 8) $out .= chr(bindec($byte));
    return $out;
}
function fwcrm_totp($secret, $step) {
    $h = hash_hmac('sha1', pack('N*', 0) . pack('N*', $step), fwcrm_b32_decode($secret), true);
    $o = ord($h[19]) & 0xf;
    $n = ((ord($h[$o]) & 0x7f) << 24) | ((ord($h[$o + 1]) & 0xff) << 16) | ((ord($h[$o + 2]) & 0xff) << 8) | (ord($h[$o + 3]) & 0xff);
    return str_pad((string) ($n % 1000000), 6, '0', STR_PAD_LEFT);
}
/** Checks a 6-digit code (±30s) and refuses to accept the same code twice. */
function fwcrm_totp_check($secret, $code, $uid = 0) {
    $code = preg_replace('/\D/', '', (string) $code);
    if (strlen($code) !== 6 || !$secret) return false;
    $now = (int) floor(time() / 30);
    $last = $uid ? (int) get_user_meta($uid, 'fwcrm_2fa_last', true) : 0;
    for ($w = -1; $w <= 1; $w++) {
        $step = $now + $w;
        if ($step <= $last) continue;
        if (hash_equals(fwcrm_totp($secret, $step), $code)) { if ($uid) update_user_meta($uid, 'fwcrm_2fa_last', $step); return true; }
    }
    return false;
}
function fwcrm_2fa_secret($uid) { return fwcrm_decrypt((string) get_user_meta($uid, 'fwcrm_2fa', true)); }
function fwcrm_2fa_on($uid) { return (bool) get_user_meta($uid, 'fwcrm_2fa_on', true) && fwcrm_2fa_secret($uid) !== ''; }

function fwcrm_2fa_new_backup($uid) {
    $codes = array(); $hashes = array();
    for ($i = 0; $i < 8; $i++) { $c = strtolower(wp_generate_password(10, false, false)); $codes[] = substr($c, 0, 5) . '-' . substr($c, 5); $hashes[] = wp_hash_password($c); }
    update_user_meta($uid, 'fwcrm_2fa_backup', $hashes);
    return $codes;
}
function fwcrm_2fa_use_backup($uid, $code) {
    $code = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) $code));
    if (strlen($code) !== 10) return false;
    $hashes = (array) get_user_meta($uid, 'fwcrm_2fa_backup', true);
    foreach ($hashes as $i => $h) if ($h && wp_check_password($code, $h)) { unset($hashes[$i]); update_user_meta($uid, 'fwcrm_2fa_backup', array_values($hashes)); return true; }
    return false;
}

/* "Trust this device for 30 days" — signed cookie, killed by turning 2-step off or "Forget devices". */
function fwcrm_2fa_trust_sig($uid, $exp) {
    return hash_hmac('sha256', $uid . '|' . $exp . '|' . (int) get_user_meta($uid, 'fwcrm_2fa_ver', true) . '|' . substr(md5(fwcrm_2fa_secret($uid)), 0, 12), wp_salt('auth'));
}
function fwcrm_2fa_trusted($uid) {
    $c = isset($_COOKIE['fwcrm_td_' . $uid]) ? (string) $_COOKIE['fwcrm_td_' . $uid] : '';
    if (!preg_match('/^(\d+)\.([a-f0-9]{64})$/', $c, $m) || (int) $m[1] < time()) return false;
    return hash_equals(fwcrm_2fa_trust_sig($uid, (int) $m[1]), $m[2]);
}

/* Right after the password is accepted: if 2-step is on, hold the session until the code is entered. */
add_action('wp_login', function ($login, $user) {
    if (!$user instanceof WP_User) return;
    if (!fwcrm_2fa_on($user->ID) || fwcrm_2fa_trusted($user->ID)) { fwcrm_sec_after_login($user); return; }
    wp_clear_auth_cookie();
    wp_set_current_user(0);
    $tok = wp_generate_password(40, false, false);
    set_transient('fwcrm_2fa_' . hash('sha256', $tok), array('uid' => $user->ID, 'remember' => !empty($_POST['rememberme']), 'tries' => 0), 10 * MINUTE_IN_SECONDS);
    setcookie('fwcrm_2fa_p', $tok, array('expires' => time() + 600, 'path' => '/', 'domain' => COOKIE_DOMAIN ?: '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax'));
    wp_safe_redirect(home_url('/hub/verify/'));
    exit;
}, 1, 2);

add_action('init', function () {
    $path = trim((string) parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH), '/');
    if ($path !== 'hub/verify') return;
    fwcrm_sec_headers();
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow', true);
    $tok = isset($_COOKIE['fwcrm_2fa_p']) ? (string) $_COOKIE['fwcrm_2fa_p'] : '';
    $key = 'fwcrm_2fa_' . hash('sha256', $tok);
    $p = $tok ? get_transient($key) : false;
    if (!$p) { wp_safe_redirect(home_url('/hub/')); exit; }
    $err = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $p['tries']++;
        $uid = (int) $p['uid'];
        $code = isset($_POST['code']) ? (string) wp_unslash($_POST['code']) : '';
        $ok = wp_verify_nonce(isset($_POST['_fw']) ? $_POST['_fw'] : '', 'fwcrm_2fa_verify')
            && (fwcrm_totp_check(fwcrm_2fa_secret($uid), $code, $uid) || fwcrm_2fa_use_backup($uid, $code));
        if ($ok) {
            delete_transient($key);
            setcookie('fwcrm_2fa_p', '', array('expires' => time() - 3600, 'path' => '/', 'domain' => COOKIE_DOMAIN ?: '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax'));
            wp_set_auth_cookie($uid, !empty($p['remember']), is_ssl());
            if (!empty($_POST['trust'])) {
                $exp = time() + 30 * DAY_IN_SECONDS;
                setcookie('fwcrm_td_' . $uid, $exp . '.' . fwcrm_2fa_trust_sig($uid, $exp), array('expires' => $exp, 'path' => '/', 'domain' => COOKIE_DOMAIN ?: '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax'));
            }
            $u = get_userdata($uid);
            fwcrm_sec_after_login($u);
            wp_safe_redirect(function_exists('fwcrm_home_for') ? fwcrm_home_for($uid) : admin_url());
            exit;
        }
        do_action('wp_login_failed', get_userdata($uid) ? get_userdata($uid)->user_login : '');
        if ($p['tries'] >= 5) { delete_transient($key); wp_safe_redirect(home_url('/hub/?locked=1')); exit; }
        set_transient($key, $p, 10 * MINUTE_IN_SECONDS);
        $err = 'That code didn’t work. Check the time on your phone and try the newest code.';
    }
    fwcrm_front_head('2-step sign in');
    echo '<main class="fp-login"><div class="fp-glow"></div><div class="fp-card"><a class="fp-brand fp-brand-coin" href="/"><span class="fp-coin" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><b class="cf">F<span>W</span></b><b class="cf cb">F<span>W</span></b></span><span>FELIXE<b>WEB</b></span></a>';
    echo '<h1>One more <em>step</em></h1><p class="fp-sub">Open your authenticator app and enter the 6-digit code for FelixeWeb Hub.</p>';
    if ($err) echo '<div class="fp-err">' . esc_html($err) . '</div>';
    echo '<form method="post" action="' . esc_url(home_url('/hub/verify/')) . '">' . wp_nonce_field('fwcrm_2fa_verify', '_fw', false, false);
    echo '<label>Code<input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="11" required autofocus class="fp-code" placeholder="123 456"></label>';
    echo '<div class="fp-row"><label class="fp-check"><input type="checkbox" name="trust" value="1"> Trust this device for 30 days</label></div>';
    echo '<button class="fp-btn" type="submit">Verify →</button></form>';
    echo '<div class="fp-foot">Lost your phone? Enter one of your backup codes instead.</div></div></main></body></html>';
    exit;
}, 4);

/* =========================================================
 * 4. Sign-in log and new-device alerts
 * ======================================================= */

function fwcrm_sec_after_login($user) {
    if (!$user instanceof WP_User) return;
    foreach (fwcrm_sec_keys($user->user_login) as $k) delete_transient($k[0]);
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 200) : '';
    list($dev, $br) = function_exists('fwcrm_device_browser') ? fwcrm_device_browser($ua) : array('', '');
    $country = function_exists('fwcrm_country') ? fwcrm_country() : '';
    $log = get_option('fwcrm_login_log', array());
    array_unshift($log, array('uid' => $user->ID, 'ip' => $ip, 'dev' => trim($br . ' · ' . $dev, ' ·'), 'country' => $country, 'at' => current_time('mysql')));
    update_option('fwcrm_login_log', array_slice($log, 0, 50), false);
    $fp = md5($ip . '|' . $br . '|' . $dev);
    $known = (array) get_user_meta($user->ID, 'fwcrm_known_devices', true);
    if (!in_array($fp, $known, true)) {
        $first = !$known;
        $known[] = $fp;
        update_user_meta($user->ID, 'fwcrm_known_devices', array_slice($known, -25));
        if (!$first && user_can($user, 'manage_options') && fwcrm_sec_opt('alerts')) {
            $where = trim($br . ' on ' . $dev . ($country ? ' · ' . $country : '') . ' · IP ' . $ip);
            if (function_exists('fwcrm_push')) fwcrm_push('🔐 New sign-in to your Hub', $where . '. If this wasn’t you, open Security and sign out everywhere.', admin_url('admin.php?page=fwcrm-security'), 'lock');
            if (function_exists('fwcrm_notify')) fwcrm_notify('New sign-in to your FelixeWeb Hub', array('Someone signed in to ' . $user->display_name . '’s account from a new device:', $where, '', 'If this was you, ignore this. If not: open Security → "Sign out everywhere", then change your password.'), admin_url('admin.php?page=fwcrm-security'));
        }
    }
}

/* =========================================================
 * 5. Private chat files (never public, served only to people in that chat)
 * ======================================================= */

function fwcrm_private_dir() {
    $u = wp_upload_dir(null, false);
    $d = trailingslashit($u['basedir']) . 'fwcrm-private';
    if (!is_dir($d)) wp_mkdir_p($d);
    if (!file_exists($d . '/.htaccess')) @file_put_contents($d . '/.htaccess', "# FelixeWeb Hub: private files, never served directly\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\nOptions -Indexes\n");
    if (!file_exists($d . '/index.php')) @file_put_contents($d . '/index.php', "<?php // Silence.\n");
    return $d;
}

/** Saves an uploaded chat file into the private folder under a random name. Returns attachment id or WP_Error. */
function fwcrm_private_store($file, $thread) {
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) return new WP_Error('upload', 'The upload didn’t arrive. Try again.');
    if ((int) $file['size'] > 200 * MB_IN_BYTES) return new WP_Error('upload', 'That file is over 200 MB.');
    $name = sanitize_file_name(wp_basename($file['name']));
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $check = wp_check_filetype_and_ext($file['tmp_name'], $name);
    $mime = $check['type'] ?: 'application/octet-stream';
    $dir = fwcrm_private_dir() . '/' . date('Y');
    wp_mkdir_p($dir);
    $dest = $dir . '/' . bin2hex(random_bytes(16)) . ($ext ? '.' . $ext : '');
    if (!@move_uploaded_file($file['tmp_name'], $dest)) return new WP_Error('upload', 'Couldn’t save the file.');
    @chmod($dest, 0640);
    $id = wp_insert_attachment(array('post_title' => 'Chat file', 'post_status' => 'private', 'post_mime_type' => $mime, 'post_author' => get_current_user_id()), $dest, 0, true);
    if (is_wp_error($id)) { @unlink($dest); return $id; }
    update_post_meta($id, '_fwcrm_thread', $thread);
    update_post_meta($id, '_fwcrm_name', $name);
    return $id;
}

function fwcrm_file_url($id) { return admin_url('admin-ajax.php?action=fwcrm_file&id=' . (int) $id); }
function fwcrm_file_name($id) { $n = get_post_meta($id, '_fwcrm_name', true); return $n ? $n : wp_basename((string) get_attached_file($id)); }

add_action('wp_ajax_fwcrm_file', function () {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    $thread = $id ? (string) get_post_meta($id, '_fwcrm_thread', true) : '';
    if (!$thread || !function_exists('fwcrm_can_thread') || !fwcrm_can_thread(get_current_user_id(), $thread)) { status_header(404); exit('Not found'); }
    $path = get_attached_file($id);
    if (!$path || !is_file($path)) { status_header(404); exit('Not found'); }
    $mime = get_post_mime_type($id) ?: 'application/octet-stream';
    $inline = in_array($mime, array('image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'video/mp4', 'video/quicktime', 'audio/mpeg', 'audio/wav', 'text/plain'), true);
    while (ob_get_level()) ob_end_clean();
    nocache_headers();
    header('Content-Type: ' . $mime);
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox");
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', fwcrm_file_name($id)) . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
});

/* =========================================================
 * 6. One-time upgrade: move old chat files, trim role powers
 * ======================================================= */

add_action('init', function () {
    if (get_option('fwcrm_sec_version') === FWCRM_SEC_VERSION) return;
    foreach (array(defined('FWCRM_TEAM_ROLE') ? FWCRM_TEAM_ROLE : 'fw_team', defined('FWCRM_CLIENT_ROLE') ? FWCRM_CLIENT_ROLE : 'fw_client') as $r) {
        $role = get_role($r);
        if ($role && $role->has_cap('upload_files')) $role->remove_cap('upload_files'); // chat uploads use the private store; no media library access
    }
    $old = get_posts(array('post_type' => 'attachment', 'post_status' => 'any', 'numberposts' => 500, 'meta_key' => '_fwcrm_thread', 'fields' => 'ids'));
    $base = trailingslashit(wp_upload_dir(null, false)['basedir']);
    foreach ($old as $id) {
        $path = get_attached_file($id);
        if (!$path || strpos($path, 'fwcrm-private') !== false || !is_file($path)) continue;
        $dir = fwcrm_private_dir() . '/' . date('Y'); wp_mkdir_p($dir);
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $dest = $dir . '/' . bin2hex(random_bytes(16)) . ($ext ? '.' . $ext : '');
        if (!get_post_meta($id, '_fwcrm_name', true)) update_post_meta($id, '_fwcrm_name', wp_basename($path));
        $meta = wp_get_attachment_metadata($id);
        if (@rename($path, $dest)) {
            if (!empty($meta['sizes'])) foreach ($meta['sizes'] as $s) @unlink(path_join(dirname($path), $s['file']));
            update_attached_file($id, $dest);
            wp_update_attachment_metadata($id, array());
            wp_update_post(array('ID' => $id, 'post_status' => 'private'));
        }
    }
    fwcrm_private_dir();
    update_option('fwcrm_sec_version', FWCRM_SEC_VERSION, false);
}, 20);

/* =========================================================
 * 7. Security page
 * ======================================================= */

add_action('admin_menu', function () {
    if (function_exists('fwcrm_is_member') && fwcrm_is_member()) add_submenu_page('fwcrm-my', 'Security', 'Security', 'fwcrm_team', 'fwcrm-security', 'fwcrm_page_security');
    else add_submenu_page('fwcrm', 'Security', 'Security', 'manage_options', 'fwcrm-security', 'fwcrm_page_security');
}, 30);

function fwcrm_sec_back($msg = '', $err = false) {
    wp_safe_redirect(add_query_arg(array_filter(array('page' => 'fwcrm-security', 'fwmsg' => $msg, 'fwerr' => $err ? 1 : 0)), admin_url('admin.php')));
    exit;
}

add_action('admin_post_fwcrm_sec', function () {
    $uid = get_current_user_id();
    if (!$uid || !(current_user_can('manage_options') || current_user_can('fwcrm_team'))) wp_die('Not allowed');
    check_admin_referer('fwcrm_sec', '_fwnonce');
    $do = isset($_POST['do']) ? sanitize_key($_POST['do']) : '';
    if ($do === 'enable') {
        $secret = fwcrm_decrypt((string) get_user_meta($uid, 'fwcrm_2fa_pending', true));
        if (!fwcrm_totp_check($secret, isset($_POST['code']) ? $_POST['code'] : '')) fwcrm_sec_back('That code didn’t match. Scan the QR code again and enter the newest code.', true);
        update_user_meta($uid, 'fwcrm_2fa', fwcrm_encrypt($secret));
        update_user_meta($uid, 'fwcrm_2fa_on', 1);
        update_user_meta($uid, 'fwcrm_2fa_since', current_time('mysql'));
        delete_user_meta($uid, 'fwcrm_2fa_pending');
        set_transient('fwcrm_2fa_show_' . $uid, fwcrm_2fa_new_backup($uid), 10 * MINUTE_IN_SECONDS);
        fwcrm_sec_back('2-step sign-in is on. Save your backup codes now.');
    }
    if ($do === 'disable') {
        if (!fwcrm_totp_check(fwcrm_2fa_secret($uid), isset($_POST['code']) ? $_POST['code'] : '', $uid)) fwcrm_sec_back('Enter a current code from your app to turn 2-step off.', true);
        foreach (array('fwcrm_2fa', 'fwcrm_2fa_on', 'fwcrm_2fa_backup', 'fwcrm_2fa_since', 'fwcrm_2fa_last') as $k) delete_user_meta($uid, $k);
        update_user_meta($uid, 'fwcrm_2fa_ver', (int) get_user_meta($uid, 'fwcrm_2fa_ver', true) + 1);
        fwcrm_sec_back('2-step sign-in is off.');
    }
    if ($do === 'backup' && fwcrm_2fa_on($uid)) { set_transient('fwcrm_2fa_show_' . $uid, fwcrm_2fa_new_backup($uid), 10 * MINUTE_IN_SECONDS); fwcrm_sec_back('New backup codes made. The old ones no longer work.'); }
    if ($do === 'forget') { update_user_meta($uid, 'fwcrm_2fa_ver', (int) get_user_meta($uid, 'fwcrm_2fa_ver', true) + 1); fwcrm_sec_back('Trusted devices forgotten. Every device will ask for a code next time.'); }
    if ($do === 'signout') {
        WP_Session_Tokens::get_instance($uid)->destroy_others(wp_get_session_token());
        update_user_meta($uid, 'fwcrm_2fa_ver', (int) get_user_meta($uid, 'fwcrm_2fa_ver', true) + 1);
        fwcrm_sec_back('Signed out everywhere except this device.');
    }
    if ($do === 'settings' && current_user_can('manage_options')) {
        update_option('fwcrm_security', array('hide_wp_login' => empty($_POST['hide_wp_login']) ? 0 : 1, 'alerts' => empty($_POST['alerts']) ? 0 : 1), false);
        fwcrm_sec_back('Saved.');
    }
    fwcrm_sec_back();
});

function fwcrm_sec_checks() {
    $uid = get_current_user_id();
    $upd = function_exists('wp_get_update_data') ? wp_get_update_data() : array('counts' => array('plugins' => 0, 'wordpress' => 0, 'themes' => 0));
    $admins = get_users(array('role' => 'administrator', 'fields' => array('display_name', 'user_login')));
    $weak = array_filter($admins, function ($a) { return in_array(strtolower($a->user_login), array('admin', 'administrator', 'root', 'test', 'user'), true); });
    return array(
        array(fwcrm_2fa_on($uid), '2-step sign-in on your account', 'Turn it on below. Even if your password leaks, nobody gets in without your phone.'),
        array(is_ssl(), 'HTTPS (padlock) on every page', 'Turn on Force HTTPS in Hostinger hPanel → Security → SSL.'),
        array(true, 'Wrong-password lockout on every login', 'Locks a visitor out after 8 wrong tries, an account after 15.'),
        array((bool) fwcrm_sec_opt('hide_wp_login'), 'Old wp-login.php page sends people to /hub', 'Bots that hammer wp-login.php get nothing.'),
        array(true, 'Usernames hidden from the public', 'No public user list, author pages or user sitemap.'),
        array(true, 'XML-RPC closed', 'The old remote-publishing door bots use for password guessing.'),
        array(true, 'Chat and client files private', 'Stored in a locked folder with random names; only people in that chat can open them.'),
        array(true, 'Code editor inside WordPress turned off', 'Even with a stolen login, nobody can edit plugin or theme code from wp-admin.'),
        array(!$weak, 'No admin account called "admin"', $weak ? 'Make a new admin with a personal username, log in with it, then delete the "admin" account.' : 'Good: no guessable admin username.'),
        array(count($admins) <= 2, count($admins) . ' admin account' . (count($admins) === 1 ? '' : 's'), 'Only you should be an admin. Team members get the Team role.'),
        array(empty($upd['counts']['wordpress']) && empty($upd['counts']['plugins']) && empty($upd['counts']['themes']), 'WordPress, plugins and theme up to date', 'Most hacked sites run an old plugin. Update in Dashboard → Updates.'),
        array(!(defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY && defined('WP_DEBUG') && WP_DEBUG), 'Error messages hidden from visitors', 'Turn off WP_DEBUG_DISPLAY in wp-config.php.'),
    );
}

function fwcrm_page_security() {
    $uid = get_current_user_id();
    $u = wp_get_current_user();
    $admin = current_user_can('manage_options');
    $on = fwcrm_2fa_on($uid);
    fwcrm_header('Security', $admin ? 'Who can get in, and what they can see.' : 'Protect your account with 2-step sign-in.');
    echo '<div class="fw-sec">';
    if ($admin) {
        $checks = fwcrm_sec_checks();
        $good = count(array_filter($checks, function ($c) { return $c[0]; }));
        $blocked = 0; foreach ((array) get_option('fwcrm_sec_blocked', array()) as $d => $n) if ($d >= date('Y-m-d', current_time('timestamp') - 7 * DAY_IN_SECONDS)) $blocked += (int) $n;
        echo '<section class="fw-card fw-sec-score"><div class="fw-sec-ring" style="--p:' . round($good / count($checks) * 100) . '"><b>' . $good . '/' . count($checks) . '</b><span>checks passed</span></div><div><h3>' . ($good === count($checks) ? 'Everything is locked down.' : 'A few things still need you.') . '</h3><p>' . number_format_i18n($blocked) . ' wrong sign-in attempt' . ($blocked === 1 ? '' : 's') . ' blocked in the last 7 days.</p></div></section>';
        echo '<section class="fw-card"><h3>Checklist</h3><ul class="fw-sec-list">';
        foreach ($checks as $c) echo '<li class="' . ($c[0] ? 'ok' : 'todo') . '"><i>' . ($c[0] ? '✓' : '!') . '</i><div><b>' . esc_html($c[1]) . '</b><p>' . esc_html($c[2]) . '</p></div></li>';
        echo '</ul></section>';
    }

    // 2-step card
    echo '<section class="fw-card" id="twostep"><h3>2-step sign-in</h3>';
    $show = get_transient('fwcrm_2fa_show_' . $uid);
    if ($show) {
        delete_transient('fwcrm_2fa_show_' . $uid);
        echo '<div class="fw-sec-codes"><p><b>Your backup codes.</b> Each works once if you lose your phone. Save them somewhere safe (a password manager or printed). They won’t be shown again.</p><pre>' . esc_html(implode("\n", $show)) . '</pre><button type="button" class="fw-btn sm" onclick="navigator.clipboard.writeText(this.previousElementSibling.textContent);this.textContent=\'Copied\'">Copy codes</button></div>';
    }
    if ($on) {
        $left = count(array_filter((array) get_user_meta($uid, 'fwcrm_2fa_backup', true)));
        echo '<p class="fw-sec-on"><i>✓</i> On since ' . esc_html(mysql2date('j M Y', (string) get_user_meta($uid, 'fwcrm_2fa_since', true))) . '. After your password you’ll be asked for a code from your authenticator app. ' . (int) $left . ' backup code' . ($left === 1 ? '' : 's') . ' left.</p><div class="fw-sec-acts">';
        foreach (array('backup' => 'New backup codes', 'forget' => 'Forget trusted devices') as $k => $lbl) echo fwcrm_sec_form($k) . '<button class="fw-btn sm">' . esc_html($lbl) . '</button></form>';
        echo fwcrm_sec_form('disable') . '<input name="code" inputmode="numeric" maxlength="6" placeholder="Code" required class="fw-sec-code"><button class="fw-btn sm" onclick="return confirm(\'Turn off 2-step sign-in?\')">Turn off</button></form></div>';
    } else {
        $pending = fwcrm_decrypt((string) get_user_meta($uid, 'fwcrm_2fa_pending', true));
        if (!$pending) { $pending = fwcrm_b32_encode(random_bytes(20)); update_user_meta($uid, 'fwcrm_2fa_pending', fwcrm_encrypt($pending)); }
        $uri = 'otpauth://totp/' . rawurlencode('FelixeWeb Hub:' . ($u->user_email ?: $u->display_name)) . '?secret=' . $pending . '&issuer=' . rawurlencode('FelixeWeb Hub') . '&digits=6&period=30';
        echo '<p>Your password plus a 6-digit code from your phone. Takes 2 minutes.</p><div class="fw-sec-setup"><div class="fw-sec-qr" id="fw-qr" data-uri="' . esc_attr($uri) . '"></div><ol>';
        echo '<li>Install <b>Google Authenticator</b> or <b>Microsoft Authenticator</b> on your phone.</li>';
        echo '<li>Tap <b>+</b> and scan this QR code. (Can’t scan? Choose “Enter a setup key” and type <code>' . esc_html(trim(chunk_split($pending, 4, ' '))) . '</code>.)</li>';
        echo '<li>Enter the 6-digit code the app shows:</li></ol>' . fwcrm_sec_form('enable') . '<input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" placeholder="123456" required class="fw-sec-code"><button class="fw-btn gold">Turn on 2-step</button></form></div>';
        echo '<script>' . file_get_contents(FWCRM_DIR . 'assets/qrcode.js') . ';(function(){var el=document.getElementById("fw-qr");if(!el)return;var q=qrcode(0,"M");q.addData(el.dataset.uri);q.make();el.innerHTML=q.createSvgTag({cellSize:5,margin:3,scalable:true});})();</script>';
    }
    echo '</section>';

    echo '<section class="fw-card"><h3>Sessions</h3><p>Lost a phone or used a shared computer? Sign out of every other device.</p>' . fwcrm_sec_form('signout') . '<button class="fw-btn" onclick="return confirm(\'Sign out every other device?\')">Sign out everywhere else</button></form></section>';

    if ($admin) {
        $log = (array) get_option('fwcrm_login_log', array());
        echo '<section class="fw-card"><h3>Recent sign-ins</h3>';
        if (!$log) echo '<p class="fw-muted">Nothing yet.</p>';
        else {
            echo '<div class="fw-sec-log">';
            foreach (array_slice($log, 0, 15) as $l) { $lu = get_userdata($l['uid']); echo '<div><b>' . esc_html($lu ? $lu->display_name : 'Deleted user') . '</b><span>' . esc_html($l['dev'] ?: 'Unknown device') . ($l['country'] ? ' · ' . esc_html($l['country']) : '') . ' · ' . esc_html($l['ip']) . '</span><em>' . esc_html(mysql2date('j M, H:i', $l['at'])) . '</em></div>'; }
            echo '</div>';
        }
        echo '</section>';
        echo '<section class="fw-card"><h3>Settings</h3>' . fwcrm_sec_form('settings');
        echo '<label class="fw-check"><input type="checkbox" name="hide_wp_login" value="1"' . checked(fwcrm_sec_opt('hide_wp_login'), 1, false) . '> Send wp-login.php visitors to the /hub sign-in</label>';
        echo '<label class="fw-check"><input type="checkbox" name="alerts" value="1"' . checked(fwcrm_sec_opt('alerts'), 1, false) . '> Alert me when my account signs in from a new device</label>';
        echo '<button class="fw-btn gold">Save</button></form></section>';
    }
    echo '</div>';
    fwcrm_footer();
}

function fwcrm_sec_form($do) {
    return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="fw-inline"><input type="hidden" name="action" value="fwcrm_sec"><input type="hidden" name="do" value="' . esc_attr($do) . '">' . wp_nonce_field('fwcrm_sec', '_fwnonce', true, false);
}
