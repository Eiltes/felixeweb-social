(function () {
  'use strict';
  if (typeof FWCRM === 'undefined') return;

  window.fwToast = function (m, e) { toast(m, e); };
  function toast(msg, err) {
    var t = document.createElement('div');
    t.className = 'fw-float' + (err ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('on'); });
    setTimeout(function () { t.classList.remove('on'); setTimeout(function () { t.remove(); }, 300); }, 3200);
  }

  function call(data) {
    var fd = new FormData();
    fd.append('action', 'fwcrm');
    fd.append('nonce', FWCRM.nonce);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(FWCRM.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.success) throw new Error((j && j.data) || 'Something went wrong');
        return j.data || {};
      });
  }

  // Generic one-click actions
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-fw-ajax]');
    if (!b) return;
    e.preventDefault();
    b.classList.add('busy');
    var data = { do: b.getAttribute('data-fw-ajax') };
    if (b.dataset.id) data.id = b.dataset.id;
    call(data).then(function (d) {
      toast(d.msg || 'Done');
      if (d.remove) { var row = b.closest('.fw-trow, .fw-item, .fw-msg, details'); if (row && !row.matches('details.fw-mail')) row.remove(); else b.remove(); }
      if (d.reload) setTimeout(function () { location.reload(); }, 700);
    }).catch(function (err) { toast(err.message, true); }).finally(function () { b.classList.remove('busy'); });
  });

  // Stage dropdowns
  document.addEventListener('change', function (e) {
    var s = e.target;
    if (s.matches('[data-fw-stage]')) {
      call({ do: 'fwcrm_stage', id: s.dataset.fwStage, stage: s.value }).then(function (d) { toast(d.msg); }).catch(function (err) { toast(err.message, true); });
    }
    if (s.matches('[data-fw-enroll]') && s.value) {
      call({ do: 'fwcrm_enroll', id: s.dataset.fwEnroll, seq: s.value }).then(function (d) {
        toast(d.msg);
        if (d.reload) setTimeout(function () { location.reload(); }, 700);
      }).catch(function (err) { toast(err.message, true); s.value = ''; });
    }
  });

  // Bulk select
  var all = document.getElementById('fw-all');
  function count() {
    var n = document.querySelectorAll('#fw-bulk input[name="ids[]"]:checked').length;
    var c = document.getElementById('fw-selcount');
    if (c) c.textContent = n;
    var f = document.getElementById('fw-bulk');
    if (f) f.classList.toggle('has-sel', n > 0);
  }
  if (all) {
    all.addEventListener('change', function () {
      document.querySelectorAll('#fw-bulk input[name="ids[]"]').forEach(function (x) { x.checked = all.checked; });
      count();
    });
    document.addEventListener('change', function (e) { if (e.target.name === 'ids[]') count(); });
    var bulk = document.getElementById('fw-bulk');
    bulk.addEventListener('submit', function (e) {
      var v = bulk.querySelector('[name=bulk_action]').value;
      if (v === 'delete' && !confirm('Delete the selected leads and all their history?')) e.preventDefault();
    });
  }

  // Kanban drag & drop
  var dragged = null;
  document.querySelectorAll('.fw-kcard').forEach(function (card) {
    card.addEventListener('dragstart', function (e) { dragged = card; card.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', card.dataset.id); });
    card.addEventListener('dragend', function () { card.classList.remove('dragging'); });
  });
  document.querySelectorAll('.fw-drop').forEach(function (zone) {
    zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('over'); });
    zone.addEventListener('dragleave', function () { zone.classList.remove('over'); });
    zone.addEventListener('drop', function (e) {
      e.preventDefault();
      zone.classList.remove('over');
      if (!dragged) return;
      var from = dragged.closest('.fw-lane');
      zone.prepend(dragged);
      var lane = zone.closest('.fw-lane');
      [from, lane].forEach(function (l) { l.querySelector('.fw-lane-h b').textContent = l.querySelectorAll('.fw-kcard').length; });
      call({ do: 'fwcrm_stage', id: dragged.dataset.id, stage: lane.dataset.stage }).then(function (d) { toast(d.msg); }).catch(function (err) { toast(err.message, true); });
    });
  });

  // Sequence step editor
  var list = document.getElementById('fw-steplist');
  if (list) {
    var renumber = function () {
      list.querySelectorAll('.fw-stepedit').forEach(function (el, i) {
        el.querySelector('.fw-stepno').textContent = i + 1;
        el.querySelectorAll('[name^="steps["]').forEach(function (inp) { inp.name = inp.name.replace(/steps\[[^\]]+\]/, 'steps[' + i + ']'); });
      });
    };
    document.getElementById('fw-addstep').addEventListener('click', function () {
      var tpl = document.getElementById('fw-steptpl');
      list.appendChild(tpl.content.cloneNode(true));
      renumber();
    });
    list.addEventListener('click', function (e) {
      if (e.target.classList.contains('fw-rmstep')) {
        if (list.querySelectorAll('.fw-stepedit').length > 1) { e.target.closest('.fw-stepedit').remove(); renumber(); }
      }
    });
    renumber();
  }

  // ---------- My AI ----------
  var chat = document.getElementById('fw-chat');
  var ask = document.getElementById('fw-ask');
  function scrollChat() { if (chat) chat.scrollTop = chat.scrollHeight; }
  function aiCall(data) {
    var fd = new FormData();
    fd.append('action', 'fwcrm_ai');
    fd.append('nonce', FWCRM.nonce);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(FWCRM.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.success) throw new Error((j && j.data) || 'Something went wrong');
      return j.data;
    });
  }
  function sendQ(q) {
    if (!q || !chat) return;
    var me = document.createElement('div'); me.className = 'fw-msgai me'; me.innerHTML = '<div class="fw-bub"></div>'; me.firstChild.textContent = q; chat.appendChild(me);
    var wait = document.createElement('div'); wait.className = 'fw-msgai ai'; wait.innerHTML = '<div class="fw-bub fw-typing"><i></i><i></i><i></i></div>'; chat.appendChild(wait);
    scrollChat();
    var ta = ask.querySelector('textarea'), btn = ask.querySelector('button');
    ta.value = ''; btn.classList.add('busy');
    aiCall({ do: 'chat', q: q }).then(function (d) {
      wait.remove();
      var tmp = document.createElement('div'); tmp.innerHTML = d.html;
      while (tmp.firstChild) chat.appendChild(tmp.firstChild);
      scrollChat();
    }).catch(function (err) { wait.remove(); toast(err.message, true); }).finally(function () { btn.classList.remove('busy'); ta.focus(); });
  }
  if (ask) {
    scrollChat();
    ask.addEventListener('submit', function (e) { e.preventDefault(); sendQ(ask.querySelector('textarea').value.trim()); });
    ask.querySelector('textarea').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendQ(this.value.trim()); } });
    document.querySelectorAll('[data-fw-ask]').forEach(function (b) { b.addEventListener('click', function () { if (!ask.querySelector('textarea').disabled) sendQ(b.dataset.fwAsk); }); });
  }
  document.addEventListener('click', function (e) {
    var s = e.target.closest('[data-fw-draft-send],[data-fw-draft-discard]');
    if (!s) return;
    var box = s.closest('[data-draft]');
    var send = s.hasAttribute('data-fw-draft-send');
    if (send && !confirm('Send this email now?')) return;
    s.classList.add('busy');
    aiCall({ do: send ? 'send' : 'discard', id: box.dataset.draft, subject: box.querySelector('.fw-subj').value, body: box.querySelector('textarea').value })
      .then(function (d) { toast(d.msg); var t = document.createElement('div'); t.innerHTML = d.html; box.replaceWith(t.firstChild); })
      .catch(function (err) { toast(err.message, true); s.classList.remove('busy'); });
  });

  document.addEventListener('click', function (e) {
    var l = e.target.closest('[data-fw-href]');
    if (!l) return;
    e.preventDefault(); e.stopPropagation();
    window.open(l.dataset.fwHref, '_blank', 'noopener');
  }, true);
})();

/* Chat conversations */
(function () {
    function init() {
        document.querySelectorAll('[data-fw-chat]').forEach(function (chat) {
            var body = chat.querySelector('.fw-chat-body');
            if (body) body.scrollTop = body.scrollHeight;
            var ta = chat.querySelector('.fw-chat-row textarea');
            var form = chat.querySelector('.fw-chat-box');
            if (!ta || !form) return;
            var grow = function () { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 220) + 'px'; };
            ta.addEventListener('input', grow);
            ta.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); if (ta.value.trim()) form.requestSubmit ? form.requestSubmit() : form.submit(); }
            });
            form.addEventListener('submit', function () { var b = form.querySelector('.fw-chat-send'); if (b) { b.disabled = true; b.textContent = '…'; } });
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();


/* ===== Work layer: search, tasks, saved replies, deal values, app ===== */
(function () {
  'use strict';
  if (typeof FWCRM === 'undefined') return;
  var toast = function (m, e) { if (window.fwToast) window.fwToast(m, e); };
  function work(data) {
    var fd = new FormData();
    fd.append('action', 'fwcrm_work');
    fd.append('nonce', FWCRM.nonce);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(FWCRM.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.success) throw new Error((j && j.data) || 'Something went wrong');
      return j.data || {};
    });
  }

  // ---- Quick search (Ctrl/Cmd + K) ----
  var dlg = document.getElementById('fw-search');
  var input = dlg ? dlg.querySelector('input') : null;
  var res = dlg ? dlg.querySelector('.fw-search-res') : null;
  var sel = 0, items = [], timer = null;
  function openSearch() {
    if (!dlg) return;
    if (!dlg.open) dlg.showModal();
    input.value = ''; res.innerHTML = ''; items = []; input.focus();
  }
  function render() {
    res.innerHTML = '';
    items.forEach(function (it, i) {
      var a = document.createElement('a');
      a.href = it.u; a.className = 'fw-sr' + (i === sel ? ' on' : '');
      a.innerHTML = '<b></b><small></small><em></em>';
      a.querySelector('b').textContent = it.t;
      a.querySelector('small').textContent = it.s;
      a.querySelector('em').textContent = it.st;
      res.appendChild(a);
    });
    if (input.value.trim() && !items.length) res.innerHTML = '<div class="fw-sr-empty">No leads match.</div>';
  }
  if (input) {
    input.addEventListener('input', function () {
      clearTimeout(timer);
      var q = input.value.trim();
      if (!q) { items = []; render(); return; }
      timer = setTimeout(function () {
        work({ do: 'search', q: q }).then(function (d) { items = d.items || []; sel = 0; render(); }).catch(function () {});
      }, 160);
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); render(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); render(); }
      if (e.key === 'Enter' && items[sel]) { e.preventDefault(); location.href = items[sel].u; }
    });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
  }
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); openSearch(); }
    if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); openSearch(); }
  });

  document.addEventListener('click', function (e) {
    var b;
    if ((b = e.target.closest('[data-fw-search]'))) { e.preventDefault(); openSearch(); return; }
    if ((b = e.target.closest('[data-fw-open]'))) {
      e.preventDefault();
      var d = document.getElementById('fw-' + b.getAttribute('data-fw-open') + '-dlg');
      if (d) { d.showModal(); var f = d.querySelector('input:not([type=hidden])'); if (f) f.focus(); }
      return;
    }
    if ((b = e.target.closest('[data-fw-close]'))) { var dd = b.closest('dialog'); if (dd) dd.close(); return; }
    if (e.target.matches && e.target.matches('dialog.fw-sheet, dialog.fw-dialog')) { e.target.close(); return; }
    if ((b = e.target.closest('[data-fw-work]'))) {
      e.preventDefault(); b.classList.add('busy');
      work({ do: b.getAttribute('data-fw-work') }).then(function (d) { toast(d.msg || 'Done'); }).catch(function (err) { toast(err.message, true); }).finally(function () { b.classList.remove('busy'); });
      return;
    }
    // Composer tools
    if ((b = e.target.closest('.fw-tool[data-tool]'))) {
      e.preventDefault();
      var tools = b.closest('.fw-tools'), menu = tools.querySelector('.fw-tool-menu');
      var form = b.closest('form'), ta = form.querySelector('textarea[name=body]');
      var kind = b.getAttribute('data-tool');
      if (kind === 'book') { insert(ta, tools.getAttribute('data-book')); return; }
      var list = JSON.parse(tools.getAttribute(kind === 'snip' ? 'data-snips' : 'data-vids') || '[]');
      if (!menu.hidden && menu.getAttribute('data-kind') === kind) { menu.hidden = true; return; }
      menu.innerHTML = ''; menu.setAttribute('data-kind', kind);
      if (!list.length) {
        var em = document.createElement('div'); em.className = 'fw-tm-empty';
        em.textContent = kind === 'video' ? 'No videos yet. Add them under Replies → Video library.' : 'No saved replies yet.';
        menu.appendChild(em);
      }
      list.forEach(function (it) {
        var o = document.createElement('button'); o.type = 'button'; o.className = 'fw-tm';
        o.innerHTML = '<b></b><small></small>';
        o.querySelector('b').textContent = it.t;
        o.querySelector('small').textContent = kind === 'snip' ? it.b.replace(/\s+/g, ' ').slice(0, 110) + '…' : 'Inserts a tracked link for this lead';
        o.addEventListener('click', function () {
          if (kind === 'snip') { if (!ta.value.trim()) ta.value = it.b; else insert(ta, it.b); }
          else insert(ta, it.u);
          ta.dispatchEvent(new Event('input')); menu.hidden = true; ta.focus();
        });
        menu.appendChild(o);
      });
      menu.hidden = false;
      return;
    }
    if (!e.target.closest('.fw-tools')) document.querySelectorAll('.fw-tool-menu').forEach(function (m) { m.hidden = true; });
  });
  function insert(ta, text) {
    if (!ta) return;
    var s = ta.selectionStart || ta.value.length, en = ta.selectionEnd || ta.value.length;
    var before = ta.value.slice(0, s), after = ta.value.slice(en);
    var pad = before && !/\s$/.test(before) ? ' ' : '';
    ta.value = before + pad + text + after;
    ta.selectionStart = ta.selectionEnd = (before + pad + text).length;
    ta.dispatchEvent(new Event('input')); ta.focus();
  }

  // Deal value
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t.matches('[data-fw-deal]')) work({ do: 'deal', id: t.getAttribute('data-fw-deal'), v: t.value }).then(function (d) { toast(d.msg); }).catch(function (err) { toast(err.message, true); });
    if (t.matches('select[name=bulk_action]')) { var tg = t.form.querySelector('.fw-bulktag'); if (tg) { tg.hidden = t.value !== 'tag'; if (!tg.hidden) tg.focus(); } }
  });

  // Installable app
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () { navigator.serviceWorker.register(FWCRM.ajax + '?action=fwcrm_sw').catch(function () {}); });
  }
})();
