(function () {
  'use strict';
  if (typeof FWCRM === 'undefined') return;

  function toast(msg, err) {
    var t = document.createElement('div');
    t.className = 'fw-float' + (err ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('on'); });
    setTimeout(function () { t.classList.remove('on'); setTimeout(function () { t.remove(); }, 300); }, 3200);
  }

  function call(data) {
    var fd = new FormData();
    fd.append('action', 'fwcrm');
    fd.append('nonce', FWCRM.nonce);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(FWCRM.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.success) throw new Error((j && j.data) || 'Something went wrong');
        return j.data || {};
      });
  }

  // Generic one-click actions
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-fw-ajax]');
    if (!b) return;
    e.preventDefault();
    b.classList.add('busy');
    var data = { do: b.getAttribute('data-fw-ajax') };
    if (b.dataset.id) data.id = b.dataset.id;
    call(data).then(function (d) {
      toast(d.msg || 'Done');
      if (d.remove) { var row = b.closest('.fw-item, .fw-msg, details'); if (row && !row.matches('details.fw-mail')) row.remove(); else b.remove(); }
      if (d.reload) setTimeout(function () { location.reload(); }, 700);
    }).catch(function (err) { toast(err.message, true); }).finally(function () { b.classList.remove('busy'); });
  });

  // Stage dropdowns
  document.addEventListener('change', function (e) {
    var s = e.target;
    if (s.matches('[data-fw-stage]')) {
      call({ do: 'fwcrm_stage', id: s.dataset.fwStage, stage: s.value }).then(function (d) { toast(d.msg); }).catch(function (err) { toast(err.message, true); });
    }
    if (s.matches('[data-fw-enroll]') && s.value) {
      call({ do: 'fwcrm_enroll', id: s.dataset.fwEnroll, seq: s.value }).then(function (d) {
        toast(d.msg);
        if (d.reload) setTimeout(function () { location.reload(); }, 700);
      }).catch(function (err) { toast(err.message, true); s.value = ''; });
    }
  });

  // Bulk select
  var all = document.getElementById('fw-all');
  function count() {
    var n = document.querySelectorAll('#fw-bulk input[name="ids[]"]:checked').length;
    var c = document.getElementById('fw-selcount');
    if (c) c.textContent = n;
  }
  if (all) {
    all.addEventListener('change', function () {
      document.querySelectorAll('#fw-bulk input[name="ids[]"]').forEach(function (x) { x.checked = all.checked; });
      count();
    });
    document.addEventListener('change', function (e) { if (e.target.name === 'ids[]') count(); });
    var bulk = document.getElementById('fw-bulk');
    bulk.addEventListener('submit', function (e) {
      var v = bulk.querySelector('[name=bulk_action]').value;
      if (v === 'delete' && !confirm('Delete the selected leads and all their history?')) e.preventDefault();
    });
  }

  // Kanban drag & drop
  var dragged = null;
  document.querySelectorAll('.fw-kcard').forEach(function (card) {
    card.addEventListener('dragstart', function (e) { dragged = card; card.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', card.dataset.id); });
    card.addEventListener('dragend', function () { card.classList.remove('dragging'); });
  });
  document.querySelectorAll('.fw-drop').forEach(function (zone) {
    zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('over'); });
    zone.addEventListener('dragleave', function () { zone.classList.remove('over'); });
    zone.addEventListener('drop', function (e) {
      e.preventDefault();
      zone.classList.remove('over');
      if (!dragged) return;
      var from = dragged.closest('.fw-lane');
      zone.prepend(dragged);
      var lane = zone.closest('.fw-lane');
      [from, lane].forEach(function (l) { l.querySelector('.fw-lane-h b').textContent = l.querySelectorAll('.fw-kcard').length; });
      call({ do: 'fwcrm_stage', id: dragged.dataset.id, stage: lane.dataset.stage }).then(function (d) { toast(d.msg); }).catch(function (err) { toast(err.message, true); });
    });
  });

  // Sequence step editor
  var list = document.getElementById('fw-steplist');
  if (list) {
    var renumber = function () {
      list.querySelectorAll('.fw-stepedit').forEach(function (el, i) {
        el.querySelector('.fw-stepno').textContent = i + 1;
        el.querySelectorAll('[name^="steps["]').forEach(function (inp) { inp.name = inp.name.replace(/steps\[[^\]]+\]/, 'steps[' + i + ']'); });
      });
    };
    document.getElementById('fw-addstep').addEventListener('click', function () {
      var tpl = document.getElementById('fw-steptpl');
      list.appendChild(tpl.content.cloneNode(true));
      renumber();
    });
    list.addEventListener('click', function (e) {
      if (e.target.classList.contains('fw-rmstep')) {
        if (list.querySelectorAll('.fw-stepedit').length > 1) { e.target.closest('.fw-stepedit').remove(); renumber(); }
      }
    });
    renumber();
  }

  // ---------- My AI ----------
  var chat = document.getElementById('fw-chat');
  var ask = document.getElementById('fw-ask');
  function scrollChat() { if (chat) chat.scrollTop = chat.scrollHeight; }
  function aiCall(data) {
    var fd = new FormData();
    fd.append('action', 'fwcrm_ai');
    fd.append('nonce', FWCRM.nonce);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(FWCRM.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.success) throw new Error((j && j.data) || 'Something went wrong');
      return j.data;
    });
  }
  function sendQ(q) {
    if (!q || !chat) return;
    var me = document.createElement('div'); me.className = 'fw-msgai me'; me.innerHTML = '<div class="fw-bub"></div>'; me.firstChild.textContent = q; chat.appendChild(me);
    var wait = document.createElement('div'); wait.className = 'fw-msgai ai'; wait.innerHTML = '<div class="fw-bub fw-typing"><i></i><i></i><i></i></div>'; chat.appendChild(wait);
    scrollChat();
    var ta = ask.querySelector('textarea'), btn = ask.querySelector('button');
    ta.value = ''; btn.classList.add('busy');
    aiCall({ do: 'chat', q: q }).then(function (d) {
      wait.remove();
      var tmp = document.createElement('div'); tmp.innerHTML = d.html;
      while (tmp.firstChild) chat.appendChild(tmp.firstChild);
      scrollChat();
    }).catch(function (err) { wait.remove(); toast(err.message, true); }).finally(function () { btn.classList.remove('busy'); ta.focus(); });
  }
  if (ask) {
    scrollChat();
    ask.addEventListener('submit', function (e) { e.preventDefault(); sendQ(ask.querySelector('textarea').value.trim()); });
    ask.querySelector('textarea').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendQ(this.value.trim()); } });
    document.querySelectorAll('[data-fw-ask]').forEach(function (b) { b.addEventListener('click', function () { if (!ask.querySelector('textarea').disabled) sendQ(b.dataset.fwAsk); }); });
  }
  document.addEventListener('click', function (e) {
    var s = e.target.closest('[data-fw-draft-send],[data-fw-draft-discard]');
    if (!s) return;
    var box = s.closest('[data-draft]');
    var send = s.hasAttribute('data-fw-draft-send');
    if (send && !confirm('Send this email now?')) return;
    s.classList.add('busy');
    aiCall({ do: send ? 'send' : 'discard', id: box.dataset.draft, subject: box.querySelector('.fw-subj').value, body: box.querySelector('textarea').value })
      .then(function (d) { toast(d.msg); var t = document.createElement('div'); t.innerHTML = d.html; box.replaceWith(t.firstChild); })
      .catch(function (err) { toast(err.message, true); s.classList.remove('busy'); });
  });

  document.addEventListener('click', function (e) {
    var l = e.target.closest('[data-fw-href]');
    if (!l) return;
    e.preventDefault(); e.stopPropagation();
    window.open(l.dataset.fwHref, '_blank', 'noopener');
  }, true);
})();

/* Chat conversations */
(function () {
    function init() {
        document.querySelectorAll('[data-fw-chat]').forEach(function (chat) {
            var body = chat.querySelector('.fw-chat-body');
            if (body) body.scrollTop = body.scrollHeight;
            var ta = chat.querySelector('.fw-chat-row textarea');
            var form = chat.querySelector('.fw-chat-box');
            if (!ta || !form) return;
            var grow = function () { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 220) + 'px'; };
            ta.addEventListener('input', grow);
            ta.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); if (ta.value.trim()) form.requestSubmit ? form.requestSubmit() : form.submit(); }
            });
            form.addEventListener('submit', function () { var b = form.querySelector('.fw-chat-send'); if (b) { b.disabled = true; b.textContent = '…'; } });
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
