(function(){
 function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
 function link(s){return esc(s).replace(/(https?:\/\/[^\s<]+)/g,'<a href="$1" target="_blank" rel="noopener">$1</a>').replace(/\n/g,'<br>')}
 function post(data){var fd=data instanceof FormData?data:new FormData();if(!(data instanceof FormData))for(var k in data)fd.append(k,data[k]);fd.append('action','fwcrm_chat');fd.append('nonce',FWCHAT.nonce);
  return fetch(FWCHAT.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){if(!j||!j.success)throw new Error((j&&j.data)||'Something went wrong');return j.data})}
 function init(root){
  var cur='',last=0,timer=null,busy=false;
  var msgs=root.querySelector('.fwc-msgs'),title=root.querySelector('.fwc-title'),form=root.querySelector('.fwc-form'),ta=form.querySelector('textarea'),fileIn=form.querySelector('input[type=file]'),fileBox=root.querySelector('.fwc-file');
  function bubble(m){var d=document.createElement('div');d.className='fwc-m'+(m.mine?' me':'');d.dataset.id=m.id;
   var f='';if(m.file){f=m.file.image?'<a class="fwc-img" href="'+esc(m.file.url)+'" target="_blank" rel="noopener"><img src="'+esc(m.file.image)+'" alt=""></a>':'<a class="fwc-doc" href="'+esc(m.file.url)+'" target="_blank" rel="noopener">📎 '+esc(m.file.name)+'</a>'}
   var av=m.photo?'<img src="'+esc(m.photo)+'" alt="">':esc((m.name||'?').charAt(0));
   d.innerHTML=(m.mine?'':'<span class="fwc-mav">'+av+'</span>')+'<div class="fwc-b">'+(m.mine?'':'<b>'+esc(m.name)+'</b>')+(m.body?'<p>'+link(m.body)+'</p>':'')+f+'<time>'+esc(m.at)+'</time></div>';return d}
  function add(list,scroll){var near=msgs.scrollHeight-msgs.scrollTop-msgs.clientHeight<120;list.forEach(function(m){if(msgs.querySelector('[data-id="'+m.id+'"]'))return;msgs.appendChild(bubble(m));last=Math.max(last,m.id)});if(scroll||near)msgs.scrollTop=msgs.scrollHeight}
  function open(t,user){if(!t)return;cur=t;last=0;root.classList.add('show-pane');
   root.querySelectorAll('.fwc-t').forEach(function(b){b.classList.toggle('on',b.dataset.thread===t);if(b.dataset.thread===t){var i=b.querySelector('.fwc-badge');if(i)i.remove()}});
   msgs.innerHTML='<div class="fwc-hint">Loading…</div>';
   post({do:'load',thread:t}).then(function(d){title.textContent=d.title;msgs.innerHTML=d.messages.length?'':'<div class="fwc-hint">No messages yet. Say hello.</div>';add(d.messages,true)}).catch(function(e){msgs.innerHTML='<div class="fwc-hint">'+esc(e.message)+'</div>'});
   try{history.replaceState(null,'','#'+t)}catch(e){}
   clearInterval(timer);timer=setInterval(poll,6000);if(user&&window.innerWidth>700)ta.focus({preventScroll:true})}
  function poll(){if(!cur||busy||document.hidden)return;busy=true;post({do:'load',thread:cur,after:last}).then(function(d){if(d.messages.length){var h=msgs.querySelector('.fwc-hint');if(h)h.remove();add(d.messages)}}).catch(function(){}).finally(function(){busy=false})}
  root.querySelectorAll('.fwc-t').forEach(function(b){b.addEventListener('click',function(){open(b.dataset.thread,true)})});
  root.querySelector('.fwc-back').addEventListener('click',function(){root.classList.remove('show-pane')});
  fileIn.addEventListener('change',function(){fileBox.innerHTML=fileIn.files.length?'📎 '+esc(fileIn.files[0].name)+' <button type="button">✕</button>':'';var x=fileBox.querySelector('button');if(x)x.onclick=function(){fileIn.value='';fileBox.innerHTML=''}});
  ta.addEventListener('input',function(){ta.style.height='auto';ta.style.height=Math.min(ta.scrollHeight,160)+'px'});
  ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>700){e.preventDefault();form.requestSubmit()}});
  form.addEventListener('submit',function(e){e.preventDefault();if(!cur)return;var body=ta.value.trim();if(!body&&!fileIn.files.length)return;
   var fd=new FormData();fd.append('do','send');fd.append('thread',cur);fd.append('body',body);if(fileIn.files.length)fd.append('file',fileIn.files[0]);
   var btn=form.querySelector('.fwc-send');btn.disabled=true;
   post(fd).then(function(d){ta.value='';ta.style.height='auto';fileIn.value='';fileBox.innerHTML='';var h=msgs.querySelector('.fwc-hint');if(h)h.remove();add([d.message],true)}).catch(function(e){alert(e.message)}).finally(function(){btn.disabled=false;ta.focus({preventScroll:true})})});
  var want=root.dataset.open||(location.hash||'').replace('#','');
  if(want&&root.querySelector('.fwc-t[data-thread="'+want+'"]'))open(want);
  else if(root.dataset.single||window.innerWidth>900){var f=root.querySelector('.fwc-t');if(f)open(f.dataset.thread)}
 }
 function boot(){document.querySelectorAll('.fwc').forEach(init)}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
