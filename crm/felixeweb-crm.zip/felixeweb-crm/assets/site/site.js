<script>
(function(){
 var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 function $(s){return document.querySelector(s)}function $$(s){return document.querySelectorAll(s)}
 function ready(){var l=$('#loader');if(l)l.classList.add('done');document.body.classList.add('ready')}
 window.addEventListener('load',function(){setTimeout(ready,reduce?0:450)});setTimeout(ready,2200);
 var hd=$('#top');function onScroll(){if(hd)hd.classList.toggle('scrolled',window.scrollY>30)}
 window.addEventListener('scroll',onScroll,{passive:true});onScroll();
 var bg=$('#burger');if(bg){bg.addEventListener('click',function(){var o=document.body.classList.toggle('menu-open');bg.setAttribute('aria-expanded',o)});
 $$('#mobile-menu a').forEach(function(a){a.addEventListener('click',function(){document.body.classList.remove('menu-open');bg.setAttribute('aria-expanded',false)})})}
 var tr=$('#track');if(tr)tr.innerHTML+=tr.innerHTML;
 var els=$$('.rv,#proc');
 if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -40px 0px'});els.forEach(function(el){io.observe(el)})}else els.forEach(function(el){el.classList.add('in')});
 $$('.filters button').forEach(function(b){b.addEventListener('click',function(){
  $$('.filters button').forEach(function(x){x.classList.remove('on')});b.classList.add('on');
  var f=b.dataset.f;$$('#grid .card').forEach(function(c){var show=f==='all'||c.dataset.c===f;c.classList.toggle('hide',!show);c.classList.toggle('wide',show&&c.hasAttribute('data-wide')&&(f==='all'||f==='digital'))});
 })});
 $$('.q button').forEach(function(b){b.addEventListener('click',function(){var q=b.parentElement,o=q.classList.toggle('open');b.setAttribute('aria-expanded',o)})});
 // video testimonials
 (function(){var fr=document.querySelectorAll('.vt-frame');fr.forEach(function(f){var v=f.querySelector('video');f.addEventListener('click',function(e){if(f.classList.contains('playing')&&e.target===v)return;fr.forEach(function(o){if(o!==f){var ov=o.querySelector('video');ov.pause();}});v.controls=true;v.muted=false;v.play();f.classList.add('playing')});v.addEventListener('pause',function(){if(v.ended||v.currentTime===0)f.classList.remove('playing')});v.addEventListener('ended',function(){f.classList.remove('playing');v.controls=false;v.load()})})})();
 // team
 var g=$('#tmGrid');if(g&&window.fetch){fetch('/wp-json/fwcrm/v1/team').then(function(r){return r.json()}).then(function(list){
  if(!Array.isArray(list)||!list.length)return;g.innerHTML='';
  list.forEach(function(m){var c=document.createElement('div');c.className='tm';var ph=document.createElement('div');ph.className='tm-ph';
   if(m.photo){var i=document.createElement('img');i.src=m.photo;i.alt=m.name+', '+m.title+' at FelixeWeb';i.loading='lazy';ph.appendChild(i)}else{var n=document.createElement('div');n.className='ini';n.textContent=(m.name||'?').charAt(0);ph.appendChild(n)}
   var b=document.createElement('div');b.className='tm-b';var h=document.createElement('h3');h.textContent=m.name;var s=document.createElement('span');s.textContent=m.title;b.appendChild(h);b.appendChild(s);
   if(m.bio){var p=document.createElement('p');p.textContent=m.bio;b.appendChild(p)}c.appendChild(ph);c.appendChild(b);g.appendChild(c)})}).catch(function(){})}
 // enquiry form
 var fm=$('#enq');if(fm){var t0=Date.now();var pre=(location.search.match(/[?&]service=([a-z0-9]+)/)||[])[1];if(pre&&fm.service)fm.service.value=pre;
  fm.addEventListener('submit',function(e){e.preventDefault();var m=fm.querySelector('.msg'),btn=fm.querySelector('button');m.className='msg';btn.disabled=true;btn.style.opacity=.6;
   var d={t:t0};['name','email','company','website','service','budget','message','company_url'].forEach(function(k){if(fm[k])d[k]=fm[k].value});
   fetch('/wp-json/fwcrm/v1/enquiry',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}).then(function(r){return r.json()}).then(function(j){
    if(j&&j.ok){m.className='msg ok';m.textContent='Thank you. Your message is in. Felix will reply within one working day.';fm.reset()}else{m.className='msg err';m.textContent=(j&&j.msg)||'Something went wrong. Please email hello@felixeweb.com.'}
   }).catch(function(){m.className='msg err';m.textContent='Something went wrong. Please email hello@felixeweb.com.'}).finally(function(){btn.disabled=false;btn.style.opacity=1})})}
 if(reduce)return;
 var cur=$('#cur'),mx=0,my=0,cx=0,cy=0;
 if(cur){window.addEventListener('mousemove',function(e){mx=e.clientX;my=e.clientY});
 (function loop(){cx+=(mx-cx)*.2;cy+=(my-cy)*.2;cur.style.transform='translate('+cx+'px,'+cy+'px) translate(-50%,-50%)';requestAnimationFrame(loop)})();
 $$('a,button').forEach(function(el){el.addEventListener('mouseenter',function(){cur.classList.add(el.classList.contains('card')?'view':'big')});el.addEventListener('mouseleave',function(){cur.classList.remove('big','view')})})}
 $$('.mag').forEach(function(b){b.addEventListener('mousemove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.25)+'px,'+((e.clientY-r.top-r.height/2)*.35)+'px)'});b.addEventListener('mouseleave',function(){b.style.transform=''})});
 var gl=$('#heroGlow'),hs=$('.hero');if(gl&&hs)hs.addEventListener('mousemove',function(e){var x=(e.clientX/window.innerWidth-.5)*80,y=(e.clientY/window.innerHeight-.5)*80;gl.style.transform='translate('+x+'px,calc(-50% + '+y+'px))'});
 $$('.card').forEach(function(c){c.addEventListener('mousemove',function(e){var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform='perspective(1200px) rotateY('+(x*4)+'deg) rotateX('+(-y*4)+'deg)'});c.addEventListener('mouseleave',function(){c.style.transform=''})});
 var bws=$$('.hero .bigword,.phero .bigword');window.addEventListener('scroll',function(){var y=window.scrollY;bws.forEach(function(b){b.style.transform='translateX('+(-y*.25)+'px)'})},{passive:true});
})();
</script>