<?php
/**
 * Plugin Name: FelixeWeb CRM
 * Description: Leads, pipeline, email outreach with automatic follow-ups, reply tracking and website visitor analytics, all inside WordPress.
 * Version: 1.0.0
 * Author: FelixeWeb
 * Author URI: https://felixeweb.com
 * Requires PHP: 7.4
 * Text Domain: felixeweb-crm
 */

if (!defined('ABSPATH')) exit;

define('FWCRM_VERSION', '1.0.0');
define('FWCRM_DB_VERSION', '1.0.0');
define('FWCRM_FILE', __FILE__);
define('FWCRM_DIR', plugin_dir_path(__FILE__));
define('FWCRM_URL', plugin_dir_url(__FILE__));

require_once FWCRM_DIR . 'includes/helpers.php';
require_once FWCRM_DIR . 'includes/db.php';
require_once FWCRM_DIR . 'includes/imap.php';
require_once FWCRM_DIR . 'includes/mailer.php';
require_once FWCRM_DIR . 'includes/sync.php';
require_once FWCRM_DIR . 'includes/automations.php';
require_once FWCRM_DIR . 'includes/tracking.php';
require_once FWCRM_DIR . 'includes/admin.php';
require_once FWCRM_DIR . 'includes/ajax.php';

register_activation_hook(__FILE__, 'fwcrm_activate');
register_deactivation_hook(__FILE__, 'fwcrm_deactivate');

function fwcrm_activate() {
    fwcrm_install_tables();
    fwcrm_seed_defaults();
    if (!wp_next_scheduled('fwcrm_tick')) {
        wp_schedule_event(time() + 60, 'fwcrm_5min', 'fwcrm_tick');
    }
    if (!wp_next_scheduled('fwcrm_daily')) {
        wp_schedule_event(time() + 300, 'daily', 'fwcrm_daily');
    }
}

function fwcrm_deactivate() {
    wp_clear_scheduled_hook('fwcrm_tick');
    wp_clear_scheduled_hook('fwcrm_daily');
}

add_filter('cron_schedules', function ($s) {
    $s['fwcrm_5min'] = array('interval' => 300, 'display' => 'Every 5 minutes (FelixeWeb CRM)');
    return $s;
});

add_action('plugins_loaded', function () {
    if (get_option('fwcrm_db_version') !== FWCRM_DB_VERSION) {
        fwcrm_install_tables();
    }
    if (!wp_next_scheduled('fwcrm_tick')) {
        wp_schedule_event(time() + 60, 'fwcrm_5min', 'fwcrm_tick');
    }
});

/** Main heartbeat: sync mailbox, then run automations. */
add_action('fwcrm_tick', 'fwcrm_run_tick');
function fwcrm_run_tick() {
    if (get_transient('fwcrm_tick_lock')) return;
    set_transient('fwcrm_tick_lock', 1, 240);
    try {
        if (fwcrm_mailbox_ready()) {
            fwcrm_sync_mailbox();
        }
        fwcrm_run_automations();
        update_option('fwcrm_last_tick', current_time('mysql'), false);
    } catch (\Throwable $e) {
        fwcrm_log('Tick error: ' . $e->getMessage());
    }
    delete_transient('fwcrm_tick_lock');
}

add_action('fwcrm_daily', 'fwcrm_daily_maintenance');
function fwcrm_daily_maintenance() {
    global $wpdb;
    $days = max(30, (int) fwcrm_opt('visit_retention_days', 180));
    $wpdb->query($wpdb->prepare("DELETE FROM " . fwcrm_t('visits') . " WHERE contact_id = 0 AND created < %s", gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS)));
    if (fwcrm_opt('daily_digest', 1)) {
        fwcrm_send_daily_digest();
    }
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('admin.php?page=fwcrm')) . '">Dashboard</a>', '<a href="' . esc_url(admin_url('admin.php?page=fwcrm-settings')) . '">Settings</a>');
    return $links;
});
